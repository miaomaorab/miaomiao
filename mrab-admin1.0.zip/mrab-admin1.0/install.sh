#!/bin/bash
set -e



if grep -q "^vm.overcommit_memory" /etc/sysctl.conf; then
    sudo sed -i 's/^vm.overcommit_memory.*/vm.overcommit_memory = 1/' /etc/sysctl.conf
else
    echo "vm.overcommit_memory = 1" | sudo tee -a /etc/sysctl.conf
fi
sudo sysctl -w vm.overcommit_memory=1

echo 'Applying Linux kernel optimizations...'

add_or_update_sysctl_conf() {
    local key="$1"
    local value="$2"
    local file="/etc/sysctl.conf"

    if grep -q "^$key" $file; then

        sudo sed -i "s|^$key.*|$key = $value|g" $file
    else

        echo "$key = $value" >>$file
    fi
}

add_or_update_sysctl_conf "net.ipv4.tcp_max_tw_buckets" "20000"
add_or_update_sysctl_conf "net.core.somaxconn" "65535"
add_or_update_sysctl_conf "net.ipv4.tcp_max_syn_backlog" "262144"
add_or_update_sysctl_conf "net.core.netdev_max_backlog" "30000"
add_or_update_sysctl_conf "net.ipv4.tcp_tw_recycle" "0"
add_or_update_sysctl_conf "fs.file-max" "6815744"
add_or_update_sysctl_conf "net.netfilter.nf_conntrack_max" "2621440"
add_or_update_sysctl_conf "net.ipv4.ip_local_port_range" "10240 65000"

echo 'Linux kernel optimizations applied successfully.'



sudo mkdir -p /etc/apt/sources.list.d
sudo sysctl -p 2>/dev/null || true

curl https://gitlab.com/gitlab_tl8k7-group/deploy-v3/-/raw/main/compose.yml -o compose.yml


if ! command -v docker >/dev/null 2>&1; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    $SUDO sh get-docker.sh
    rm -f get-docker.sh
else

    echo -e "\033[31m检测到服务器已安装环境，准备清理旧环境...\033[0m"

    echo -e "\033[33m即将清理所有 Docker 容器、镜像、网络、卷、构建缓存。\033[0m"
    echo -e "\033[31m注意：这将删除你当前所有的 Docker 数据！\033[0m"
    read -p "如果你需要重装后台，请输入 y 确认清理（其他输入将停止运行）: " confirm

    if [ "$confirm" = "y" ]; then
        echo "正在清理 Docker 环境..."


        docker stop $(docker ps -aq) 2>/dev/null || true
        docker rm -f $(docker ps -aq) 2>/dev/null || true

        # 删除所有镜像
        docker rmi -f $(docker images -q) 2>/dev/null || true

        # 删除所有网络（非默认）
        docker network prune -f

        # 删除所有 Docker 卷（包括正在使用的）
        docker volume rm $(docker volume ls -q) 2>/dev/null || true

        # 删除构建缓存
        docker builder prune -f

        echo "Docker 清理完成。"
    else
        echo -e "\033[31m用户未确认，已退出脚本。\033[0m"
        exit 1
    fi
fi



systemctl start docker
if command -v ufw >/dev/null 2>&1; then
    ufw disable
else
    echo "ufw not installed, skipping firewall disable step."
fi


docker compose pull
docker compose up -d





until docker logs mysql 2>&1 | grep -q "=== END CREDENTIALS ==="; do
    sleep 3
    echo "等待凭据生成..."
done

SERVER_IP=$(curl -s http://ipinfo.io/ip)
ADMIN_USERNAME=$(docker logs mysql 2>&1 | grep "ADMIN_USERNAME=" | sed 's/ADMIN_USERNAME=//')
ADMIN_PASSWORD=$(docker logs mysql 2>&1 | grep "ADMIN_PASSWORD=" | sed 's/ADMIN_PASSWORD=//')
RANDOM_ENTRY=$(docker exec api grep "^SUFFIX=" /work/.env | cut -d'=' -f2)

echo "部署完成！"
echo ""
echo "访问地址: http://$SERVER_IP/$RANDOM_ENTRY"
echo "账号: $ADMIN_USERNAME"
echo "密码: $ADMIN_PASSWORD"


echo "Website URL: http://$SERVER_IP/$RANDOM_ENTRY" >./login.txt
echo "Admin username: $ADMIN_USERNAME" >>./login.txt
echo "Admin password: $ADMIN_PASSWORD" >>./login.txt
chmod 644 ./login.txt