<script setup lang="ts">
import { useTheme } from 'vuetify'
import AuthProvider from '@/views/pages/authentication/AuthProvider.vue'

import logo from '@images/logo.svg?raw'
import authV1MaskDark from '@images/pages/auth-v1-mask-dark.png'
import authV1MaskLight from '@images/pages/auth-v1-mask-light.png'
import authV1Tree2 from '@images/pages/auth-v1-tree-2.png'
import authV1Tree from '@images/pages/auth-v1-tree.png'

const form = ref({
  account: '',
  password: '',
  remember: false,
})

const vuetifyTheme = useTheme()

const authThemeMask = computed(() => {
  return vuetifyTheme.global.name.value === 'light'
    ? authV1MaskLight
    : authV1MaskDark
})

const isPasswordVisible = ref(false)
</script>

<template>
  <!-- eslint-disable vue/no-v-html -->

  <div class="auth-wrapper d-flex align-center justify-center pa-4">
    <VCard
      class="auth-card pa-4 pt-7"
      max-width="448"
    >
      <VCardItem class="justify-center">
        <RouterLink
          to="/"
          class="d-flex align-center gap-3"
        >
          <!-- eslint-disable vue/no-v-html -->
          <div
            class="d-flex"
            v-html="logo"
          />
          <h2 class="font-weight-medium text-2xl text-uppercase">
            T3
          </h2>
        </RouterLink>
      </VCardItem>

      <VCardText class="auth-header-text pt-2">
        <h4 class="auth-title text-h4 mb-1">
          欢迎回来！👋🏻
        </h4>
        <p class="auth-subtitle mb-0">
          请登录您的账号，开始您的旅程
        </p>
      </VCardText>

      <VCardText class="auth-form-content">
        <VForm @submit.prevent="() => {}">
          <VRow>
            <!-- account -->
            <VCol cols="12">
              <VTextField
                v-model="form.account"
                label="账号"
                variant="outlined"
                density="default"
                hide-details
                class="auth-input"
              />
            </VCol>

            <!-- password -->
            <VCol cols="12">
              <VTextField
                v-model="form.password"
                label="密码"
                placeholder="············"
                variant="outlined"
                density="default"
                :type="isPasswordVisible ? 'text' : 'password'"
                autocomplete="password"
                :append-inner-icon="isPasswordVisible ? 'ri-eye-off-line' : 'ri-eye-line'"
                hide-details
                class="auth-input"
                @click:append-inner="isPasswordVisible = !isPasswordVisible"
              />

              <!-- remember me checkbox -->
              <div class="auth-options d-flex align-center justify-space-between flex-wrap my-6">
                <VCheckbox
                  v-model="form.remember"
                  label="记住我"
                  density="compact"
                  hide-details
                  class="remember-checkbox"
                />

                <a
                  class="forgot-password-link text-primary text-decoration-none"
                  href="javascript:void(0)"
                >
                  忘记密码？
                </a>
              </div>

              <!-- login button -->
              <VBtn
                block
                type="submit"
                color="primary"
                variant="elevated"
                size="large"
                class="login-btn"
                to="/"
              >
                登录
              </VBtn>
            </VCol>

            <!-- create account -->
            <VCol
              cols="12"
              class="auth-footer-link text-center text-base"
            >
              <span class="footer-text">新用户？</span>
              <RouterLink
                class="text-primary ms-2 text-decoration-none"
                to="/register"
              >
                创建账号
              </RouterLink>
            </VCol>

            <VCol
              cols="12"
              class="auth-divider d-flex align-center"
            >
              <VDivider />
              <span class="divider-text mx-4">或</span>
              <VDivider />
            </VCol>

            <!-- auth providers -->
            <VCol
              cols="12"
              class="auth-providers text-center"
            >
              <AuthProvider />
            </VCol>
          </VRow>
        </VForm>
      </VCardText>
    </VCard>

    <VImg
      class="auth-footer-start-tree d-none d-md-block"
      :src="authV1Tree"
      :width="250"
    />

    <VImg
      :src="authV1Tree2"
      class="auth-footer-end-tree d-none d-md-block"
      :width="350"
    />

    <!-- bg img -->
    <VImg
      class="auth-footer-mask d-none d-md-block"
      :src="authThemeMask"
    />
  </div>
</template>

<style lang="scss" scoped>
.auth-wrapper {
  min-height: 100vh;
  position: relative;
  overflow: hidden;
}

.auth-card {
  border-radius: 0.75rem;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
  z-index: 1;
  position: relative;
  background: rgba(var(--v-theme-surface), 1);
  backdrop-filter: blur(10px);

  .auth-header-text {
    padding-block-end: 0.5rem;

    .auth-title {
      font-size: 1.5rem;
      font-weight: 600;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      line-height: 2rem;
    }

    .auth-subtitle {
      font-size: 0.875rem;
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      line-height: 1.25rem;
    }
  }

  .auth-form-content {
    padding-block-start: 0.5rem;

    .auth-input {
      :deep(.v-field) {
        font-size: 0.875rem;
        border-radius: 0.5rem;
      }

      :deep(.v-label) {
        font-size: 0.875rem;
      }

      :deep(.v-field__input) {
        padding-block: 0.75rem;
      }
    }

    .auth-options {
      .remember-checkbox {
        :deep(.v-label) {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        }
      }

      .forgot-password-link {
        font-size: 0.875rem;
        font-weight: 500;
        transition: opacity 0.2s ease-in-out;

        &:hover {
          opacity: 0.8;
        }
      }
    }

    .login-btn {
      font-size: 0.875rem;
      font-weight: 500;
      padding-block: 0.875rem;
      border-radius: 0.5rem;
      text-transform: none;
      letter-spacing: 0;
      transition: all 0.2s ease-in-out;

      &:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(var(--v-theme-primary), 0.3);
      }
    }

    .auth-footer-link {
      padding-block-start: 1rem;

      .footer-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }

      a {
        font-size: 0.875rem;
        font-weight: 500;
        transition: opacity 0.2s ease-in-out;

        &:hover {
          opacity: 0.8;
        }
      }
    }

    .auth-divider {
      padding-block: 1rem;

      .divider-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }
    }

    .auth-providers {
      padding-block-start: 0.5rem;
    }
  }
}

.auth-footer-start-tree,
.auth-footer-end-tree {
  position: fixed;
  z-index: 0;
  pointer-events: none;
}

.auth-footer-start-tree {
  bottom: 0;
  left: 0;
}

.auth-footer-end-tree {
  bottom: 0;
  right: 0;
}

.auth-footer-mask {
  position: fixed;
  inset-block-end: 0;
  inset-inline-start: 0;
  z-index: 0;
  pointer-events: none;
  width: 100%;
  height: 300px;
}
</style>

<style lang="scss">
@use "@core/scss/template/pages/page-auth";
</style>
