<script setup lang="ts">
const expireTime = ref('')
const authCode = ref('')
const showAuthCode = ref(false)

const handleSave = () => {
  // 保存逻辑
  // TODO: 实现保存功能
}

const handleReset = () => {
  expireTime.value = ''
  authCode.value = ''
}
</script>

<template>
  <div>
    <VCard class="activation-card">
      <VCardTitle class="activation-title">
        激活 & 续费
      </VCardTitle>
      <VCardText class="activation-content">
        <div class="form-section">
          <VTextField
            v-model="expireTime"
            label="到期时间"
            variant="outlined"
            class="mb-4"
            disabled
          />
          <VTextField
            v-model="authCode"
            label="授权码"
            variant="outlined"
            :type="showAuthCode ? 'text' : 'password'"
            class="mb-4"
          >
            <template #append-inner>
              <IconBtn @click="showAuthCode = !showAuthCode">
                <VIcon
                  :icon="showAuthCode ? 'ri-eye-line' : 'ri-eye-off-line'"
                  size="20"
                />
              </IconBtn>
            </template>
          </VTextField>
        </div>

        <div class="notice-section">
          <h6 class="notice-title">
            激活须知 :
          </h6>
          <VList class="notice-list">
            <VListItem class="notice-item">
              <template #prepend>
                <VIcon
                  icon="ri-error-warning-line"
                  color="error"
                  size="20"
                />
              </template>
              <VListItemTitle class="notice-text">
                注意: 当授权码剩余有效期不足5天时，使用新授权码激活会自动将剩余时长叠加到新授权码的有效期上
              </VListItemTitle>
            </VListItem>
            <VListItem class="notice-item">
              <template #prepend>
                <VIcon
                  icon="ri-error-warning-line"
                  color="error"
                  size="20"
                />
              </template>
              <VListItemTitle class="notice-text">
                授权码同时只能在一台服务器上使用，在新服务器激活后，原服务器上的授权将自动失效
              </VListItemTitle>
            </VListItem>
            <VListItem class="notice-item">
              <template #prepend>
                <VIcon
                  icon="ri-error-warning-line"
                  color="error"
                  size="20"
                />
              </template>
              <VListItemTitle class="notice-text">
                如果恶意激活，该服务器IP将被永久列入黑名单
              </VListItemTitle>
            </VListItem>
          </VList>
        </div>

        <div class="action-section">
          <VBtn
            color="primary"
            variant="elevated"
            size="default"
            class="action-btn"
            @click="handleSave"
          >
            保存
          </VBtn>
          <VBtn
            variant="outlined"
            size="default"
            class="action-btn"
            @click="handleReset"
          >
            重置
          </VBtn>
        </div>
      </VCardText>
    </VCard>
  </div>
</template>

<style lang="scss" scoped>
.activation-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .activation-title {
    font-size: 1.25rem;
    font-weight: 600;
    color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
    padding: 1.5rem 1.5rem 0;
  }

  .activation-content {
    padding: 1.5rem;

    .form-section {
      margin-block-end: 2rem;

      :deep(.v-field) {
        font-size: 0.875rem;
      }

      :deep(.v-label) {
        font-size: 0.875rem;
      }
    }

    .notice-section {
      margin-block-end: 2rem;

      .notice-title {
        font-size: 1rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
        margin-block-end: 1rem;
      }

      .notice-list {
        padding: 0;

        .notice-item {
          padding-block: 0.75rem;
          padding-inline: 0;
          align-items: flex-start;

          :deep(.v-list-item__prepend) {
            margin-inline-end: 0.75rem;
            margin-block-start: 0.125rem;
          }

          .notice-text {
            font-size: 0.875rem;
            line-height: 1.5;
            color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
            white-space: normal;
          }
        }
      }
    }

    .action-section {
      display: flex;
      gap: 1rem;

      .action-btn {
        font-size: 0.875rem;
        font-weight: 500;
        padding-inline: 1.5rem;
        padding-block: 0.625rem;
        border-radius: 0.375rem;
        min-width: 100px;
        transition: all 0.2s ease-in-out;

        &:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
        }
      }
    }
  }
}
</style>
