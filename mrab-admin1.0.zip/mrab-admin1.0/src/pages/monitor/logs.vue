<script setup lang="ts">
import { paginationMeta } from '@/utils/paginationMeta'

interface LogItem {
  id: string
  api: string
  type: string
  user: string
  ip: string
  userAgent: string
  createTime: string
}

const logs = ref<LogItem[]>([])
const selectedLogs = ref<string[]>([])
const isViewDialogOpen = ref(false)
const currentLog = ref<LogItem | null>(null)

const filterForm = ref({
  type: '全部',
  dateRange: '',
  user: '',
})

const dateRangeMenu = ref(false)
const dateRange = ref<string[]>([])

const itemsPerPage = ref(10)
const page = ref(1)
const totalItems = ref(0)

const headers = [
  { title: 'ID', key: 'id' },
  { title: 'API', key: 'api' },
  { title: '类型', key: 'type' },
  { title: '后台账号', key: 'user' },
  { title: 'IP', key: 'ip' },
  { title: 'User-Agent', key: 'userAgent' },
  { title: '创建时间', key: 'createTime' },
]

const typeOptions = ['全部', '操作日志列表', '前台列表', '数据中心', '角色列表', '角色详情', '账号列表', '账号详情', '获取配置信息', '卡头备注列表']

const search = () => {
  // 查询逻辑
}

const reset = () => {
  filterForm.value = {
    type: '全部',
    dateRange: '',
    user: '',
  }
  dateRange.value = []
}

const clearLogs = () => {
  logs.value = []
}
</script>

<template>
  <div>
    <!-- 筛选区域 -->
    <VCard class="filter-card mb-4">
      <VCardText class="filter-content">
        <VRow class="filter-row">
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VSelect
              v-model="filterForm.type"
              :items="typeOptions"
              label="类型"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VMenu
              v-model="dateRangeMenu"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template #activator="{ props }">
                <VTextField
                  v-bind="props"
                  :model-value="dateRange.length > 0 ? `${dateRange[0]} ~ ${dateRange[1] || dateRange[0]}` : ''"
                  label="日期范围"
                  placeholder="选择日期范围"
                  variant="outlined"
                  density="compact"
                  readonly
                  hide-details
                  class="filter-input"
                  clearable
                  @click:clear="dateRange = []"
                />
              </template>
              <VDatePicker
                v-model="dateRange"
                range
              />
            </VMenu>
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.user"
              label="后台账号"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-actions"
          >
            <div class="d-flex gap-3">
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                class="filter-btn"
                @click="search"
              >
                <VIcon
                  icon="ri-search-line"
                  start
                  size="20"
                />
                查询
              </VBtn>
              <VBtn
                variant="outlined"
                size="default"
                class="filter-btn"
                @click="reset"
              >
                重置
              </VBtn>
            </div>
          </VCol>
        </VRow>
      </VCardText>
    </VCard>

    <!-- 操作栏 -->
    <VCard class="action-bar-card mb-4">
      <VCardText class="action-bar-content">
        <div class="d-flex align-center justify-space-between flex-wrap gap-4">
          <div class="d-flex align-center gap-2 action-left">
            <span class="action-label">每页显示</span>
            <VSelect
              v-model="itemsPerPage"
              :items="[10, 20, 50, 100]"
              variant="outlined"
              density="compact"
              hide-details
              class="items-per-page-select"
            />
          </div>
          <div class="d-flex align-center gap-3 action-right">
            <VBtn
              color="error"
              variant="outlined"
              size="default"
              class="action-btn"
              @click="clearLogs"
            >
              <VIcon
                icon="ri-delete-bin-line"
                start
                size="20"
              />
              一键清空
            </VBtn>
          </div>
        </div>
      </VCardText>
    </VCard>

    <!-- 日志列表 -->
    <VCard class="logs-table-card">
      <VDataTable
        v-model="selectedLogs"
        :headers="headers"
        :items="logs"
        :items-per-page="itemsPerPage"
        :page="page"
        class="logs-table text-no-wrap"
      >
        <template #item.userAgent="{ item }">
          <span class="user-agent text-truncate d-inline-block">
            {{ item.userAgent }}
          </span>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-file-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无数据
            </p>
          </div>
        </template>
        <template #bottom>
          <div class="table-footer">
            <div class="pagination-info">
              {{ paginationMeta({ page, itemsPerPage }, totalItems) }}
            </div>
            <VPagination
              v-model="page"
              :length="Math.ceil(totalItems / itemsPerPage)"
              :total-visible="5"
              density="comfortable"
            />
          </div>
        </template>
      </VDataTable>
    </VCard>
  </div>
</template>

<style lang="scss" scoped>
.filter-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .filter-content {
    padding: 1.5rem;

    .filter-row {
      .filter-col {
        margin-block-end: 0.75rem;
      }

      .filter-input {
        :deep(.v-field) {
          font-size: 0.875rem;
        }

        :deep(.v-label) {
          font-size: 0.875rem;
        }
      }

      .filter-actions {
        margin-block-start: 0.5rem;
        padding-block-start: 0.5rem;

        .filter-btn {
          font-size: 0.875rem;
          font-weight: 500;
          padding-inline: 1.25rem;
          padding-block: 0.625rem;
          border-radius: 0.375rem;
          min-width: 100px;
          transition: all 0.2s ease-in-out;

          &:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
          }
        }
      }
    }
  }
}

.logs-table-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;

  .logs-table {
    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 1rem;
          padding-inline: 1rem;
        }
      }
    }

    .user-agent {
      max-width: 300px;
      font-size: 0.875rem;
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem 1.5rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .pagination-info {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }
    }
  }
}

.action-bar-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .action-bar-content {
    padding: 1rem 1.5rem;

    .action-left {
      .action-label {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }

      .items-per-page-select {
        width: 90px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }
      }
    }

    .action-right {
      .action-btn {
        font-size: 0.875rem;
        font-weight: 500;
        padding-inline: 1rem;
        padding-block: 0.625rem;
        border-radius: 0.375rem;
        min-width: auto;
        transition: all 0.2s ease-in-out;

        &:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
        }
      }
    }
  }
}
</style>
