<script setup lang="ts">
import PanelSettings from '@/components/PanelSettings.vue'

const panelSettingsOpen = ref(false)
const operationMenuMode = ref<'hover' | 'click'>('hover')

const openPanelSettings = () => {
  panelSettingsOpen.value = true
}

const refreshOnline = () => {
  // 刷新在线数据
}

const visitors = ref([])
const hasVisitors = computed(() => visitors.value.length > 0)
</script>

<template>
  <div class="access-control-page">
    <!-- 访问控制卡片（包含按钮和实时访客监控） -->
    <VCard class="access-control-card">
      <!-- 操作按钮栏（右上角） -->
      <VCardText class="action-bar-content">
        <div class="d-flex align-center justify-end gap-3">
          <VBtn
            color="primary"
            variant="elevated"
            size="default"
            class="action-btn"
            @click="refreshOnline"
          >
            <VIcon
              icon="ri-refresh-line"
              start
              size="20"
            />
            刷新在线
          </VBtn>
          <VBtn
            variant="outlined"
            size="default"
            class="action-btn"
            @click="operationMenuMode = operationMenuMode === 'hover' ? 'click' : 'hover'"
          >
            <VIcon
              icon="ri-menu-line"
              start
              size="20"
            />
            操作菜单方式 ({{ operationMenuMode === 'hover' ? '悬停显示' : '点击显示' }})
          </VBtn>
          <VBtn
            variant="outlined"
            size="default"
            class="action-btn"
            @click="openPanelSettings"
          >
            <VIcon
              icon="ri-settings-3-line"
              start
              size="20"
            />
            面板设置
          </VBtn>
        </div>
        <VDivider class="action-divider" />
      </VCardText>

      <!-- 实时访客监控面板 -->
      <VCardText class="card-content">
        <div
          v-if="!hasVisitors"
          class="empty-state"
        >
          <VIcon
            icon="ri-inbox-line"
            size="64"
            color="disabled"
            class="empty-icon mb-4"
          />
          <p class="empty-text">
            暂无前台访客信息，如果没有显示请检查您的面板设置的过滤设置
          </p>
        </div>
        <div
          v-else
          class="visitor-list"
        >
          <!-- 访客列表 -->
          <VList class="visitor-list-content">
            <VListItem
              v-for="(visitor, index) in visitors"
              :key="index"
              class="visitor-item"
            >
              <VListItemTitle class="visitor-title">
                访客 {{ index + 1 }}
              </VListItemTitle>
            </VListItem>
          </VList>
        </div>
      </VCardText>
    </VCard>

    <!-- 面板设置侧边栏 -->
    <PanelSettings v-model="panelSettingsOpen" />
  </div>
</template>

<style lang="scss" scoped>
.access-control-page {
  padding-block-end: 0.5rem;
}

.access-control-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  width: 100%;
  min-height: calc(100vh - 200px);
  display: flex;
  flex-direction: column;

  .action-bar-content {
    padding: 1rem 1.5rem 0;
    flex-shrink: 0;

    .action-btn {
      font-size: 0.875rem;
      font-weight: 500;
      letter-spacing: 0.025em;
      min-width: auto;
      padding-inline: 1rem;
      padding-block: 0.625rem;
      border-radius: 0.375rem;
      transition: all 0.2s ease-in-out;

      &:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
      }
    }

    .action-divider {
      margin-block-start: 1rem;
      margin-inline: 0;
    }
  }

  .card-content {
    padding: 0.5rem 1.5rem 1rem;
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
      padding-block: 6rem;
      text-align: center;

      .empty-icon {
        opacity: 0.5;
      }

      .empty-text {
        font-size: 0.875rem;
        line-height: 1.5rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        max-width: 500px;
        margin: 0;
      }
    }

    .visitor-list {
      flex: 1;
      overflow-y: auto;
      min-height: 0;

      .visitor-list-content {
        padding: 0;

        .visitor-item {
          padding-block: 0.875rem;
          padding-inline: 1rem;
          border-radius: 0.375rem;
          margin-block-end: 0.5rem;
          background-color: rgba(var(--v-theme-surface), 1);
          border: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
          transition: all 0.2s ease-in-out;

          &:hover {
            background-color: rgba(var(--v-theme-surface-variant), 0.5);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
          }

          .visitor-title {
            font-size: 0.875rem;
            font-weight: 500;
            color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          }
        }
      }
    }
  }
}
</style>
