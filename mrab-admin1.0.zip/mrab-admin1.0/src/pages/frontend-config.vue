<script setup lang="ts">
import { paginationMeta } from '@/utils/paginationMeta'

interface FrontendItem {
  id: string
  name: string
  version: string
  logo?: string
  country?: string
  countryCode?: string
  website?: string
  description?: string
  previewImage?: string
  downloadTime?: string
  updateTime?: string
}

const activeTab = ref('downloaded')
const downloadedItems = ref<FrontendItem[]>([])
const sourceList = ref<FrontendItem[]>([])
const searchKeyword = ref('')
const itemsPerPage = ref(10)
const page = ref(1)
const totalItems = computed(() => {
  return activeTab.value === 'downloaded' ? downloadedItems.value.length : sourceList.value.length
})

const sourceHeaders = [
  { title: 'logo', key: 'logo', sortable: false },
  { title: '国家', key: 'country' },
  { title: '官网', key: 'website' },
  { title: '描述', key: 'description' },
  { title: '站点预览图', key: 'previewImage', sortable: false },
  { title: '更新时间', key: 'updateTime' },
  { title: '操作', key: 'actions', sortable: false },
]

const download = (item: FrontendItem) => {
  // 下载逻辑
  downloadedItems.value.push({
    id: item.id,
    name: item.name,
    version: item.version,
    logo: item.logo,
    country: item.country,
    countryCode: item.countryCode,
    website: item.website,
    description: item.description,
    previewImage: item.previewImage,
    downloadTime: new Date().toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).replace(/\//g, '-'),
  })
}

const deleteItem = (id: string) => {
  const index = downloadedItems.value.findIndex(item => item.id === id)
  if (index !== -1)
    downloadedItems.value.splice(index, 1)
}

const handleSearch = () => {
  // 搜索逻辑
  // TODO: 实现搜索功能
}

const handleReset = () => {
  searchKeyword.value = ''
}
</script>

<template>
  <div>
    <!-- Tab切换 -->
    <VCard class="tab-card mb-4">
      <VTabs
        v-model="activeTab"
        class="config-tabs"
      >
        <VTab value="downloaded">
          已下载
        </VTab>
        <VTab value="source">
          源码列表
        </VTab>
      </VTabs>
    </VCard>

    <!-- 已下载标签页 -->
    <VCard
      v-if="activeTab === 'downloaded'"
      class="downloaded-card"
    >
      <VCardText>
        <div
          v-if="downloadedItems.length === 0"
          class="empty-state"
        >
          <h4 class="empty-title">
            空空如也 👨🏻‍💻
          </h4>
          <p class="empty-text">
            前往源码列表下载源代码！
          </p>
        </div>
        <div
          v-else
          class="downloaded-grid"
        >
          <VCard
            v-for="item in downloadedItems"
            :key="item.id"
            class="downloaded-item-card"
          >
            <VCardText>
              <div class="item-header">
                <div class="item-logo">
                  <VIcon
                    v-if="!item.logo"
                    icon="ri-file-code-line"
                    size="32"
                    color="primary"
                  />
                  <img
                    v-else
                    :src="item.logo"
                    :alt="item.name"
                    class="logo-image"
                  >
                </div>
                <div class="item-info">
                  <h6 class="item-name">
                    {{ item.name }}
                  </h6>
                  <p class="item-version">
                    版本: {{ item.version }}
                  </p>
                </div>
              </div>
              <div class="item-footer">
                <span class="item-time">
                  下载时间: {{ item.downloadTime }}
                </span>
                <IconBtn
                  size="small"
                  color="error"
                  class="delete-btn"
                  @click="deleteItem(item.id)"
                >
                  <VIcon
                    icon="ri-delete-bin-line"
                    size="20"
                  />
                </IconBtn>
              </div>
            </VCardText>
          </VCard>
        </div>
      </VCardText>
    </VCard>

    <!-- 源码列表标签页 -->
    <VCard
      v-if="activeTab === 'source'"
      class="source-card"
    >
      <!-- 搜索栏 -->
      <VCardText class="search-section">
        <div class="d-flex align-center gap-3 flex-wrap">
          <VTextField
            v-model="searchKeyword"
            placeholder="Search Code"
            variant="outlined"
            density="compact"
            hide-details
            class="search-input"
          />
          <VBtn
            color="primary"
            variant="elevated"
            size="default"
            class="search-btn"
            @click="handleSearch"
          >
            <VIcon
              icon="ri-search-line"
              start
              size="20"
            />
            查询
          </VBtn>
          <VBtn
            variant="outlined"
            size="default"
            class="reset-btn"
            @click="handleReset"
          >
            重置
          </VBtn>
          <VSpacer />
          <VBtn
            color="primary"
            variant="elevated"
            size="default"
            class="install-btn"
          >
            <VIcon
              icon="ri-install-line"
              start
              size="20"
            />
            手动安装
          </VBtn>
        </div>
      </VCardText>

      <VDivider />

      <!-- 提示信息 -->
      <VCardText class="info-section">
        <VAlert
          type="error"
          variant="tonal"
          class="info-alert"
        >
          下载后请测试源码是否正常，如有问题请及时与我联系，我会第一时间进行修复如果遇到任何错误
        </VAlert>
      </VCardText>

      <VDivider />

      <!-- 表格列表 -->
      <VDataTable
        :headers="sourceHeaders"
        :items="sourceList"
        :items-per-page="itemsPerPage"
        :page="page"
        class="source-table text-no-wrap"
      >
        <template #item.logo="{ item }">
          <div class="logo-cell">
            <VIcon
              v-if="!item.logo"
              icon="ri-file-code-line"
              size="24"
              color="primary"
            />
            <img
              v-else
              :src="item.logo"
              :alt="item.name"
              class="logo-image-small"
            >
          </div>
        </template>
        <template #item.country="{ item }">
          <div class="country-cell">
            {{ item.country }} {{ item.countryCode }}
          </div>
        </template>
        <template #item.website="{ item }">
          <a
            v-if="item.website"
            :href="item.website"
            target="_blank"
            class="website-link"
          >
            {{ item.website }}
          </a>
          <span v-else>-</span>
        </template>
        <template #item.description="{ item }">
          <div class="description-cell">
            {{ item.description || '-' }}
          </div>
        </template>
        <template #item.previewImage="{ item }">
          <div class="preview-cell">
            <VIcon
              v-if="!item.previewImage"
              icon="ri-image-line"
              size="24"
              color="disabled"
            />
            <img
              v-else
              :src="item.previewImage"
              :alt="item.name"
              class="preview-image"
            >
          </div>
        </template>
        <template #item.actions="{ item }">
          <VBtn
            color="primary"
            variant="elevated"
            size="small"
            class="install-action-btn"
            @click="download(item)"
          >
            <VIcon
              icon="ri-download-line"
              start
              size="18"
            />
            安装
          </VBtn>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-inbox-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无源码数据
            </p>
          </div>
        </template>
        <template #bottom>
          <div class="table-footer">
            <div class="pagination-info">
              {{ paginationMeta({ page, itemsPerPage }, totalItems) }}
            </div>
            <VPagination
              v-model="page"
              :length="Math.ceil(totalItems / itemsPerPage)"
              :total-visible="5"
              density="comfortable"
            />
          </div>
        </template>
      </VDataTable>
    </VCard>
  </div>
</template>

<style lang="scss" scoped>
.tab-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .config-tabs {
    :deep(.v-tab) {
      font-size: 0.875rem;
      font-weight: 500;
      text-transform: none;
      min-width: 120px;
    }
  }
}

.downloaded-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding-block: 6rem;
    text-align: center;

    .empty-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      margin-block-end: 1rem;
    }

    .empty-text {
      font-size: 0.875rem;
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      margin: 0;
    }
  }

  .downloaded-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 1.5rem;
    padding: 1.5rem;

    .downloaded-item-card {
      border-radius: 0.5rem;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
      transition: all 0.2s ease-in-out;

      &:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
        transform: translateY(-2px);
      }

      .item-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-block-end: 1rem;

        .item-logo {
          flex-shrink: 0;

          .logo-image {
            width: 48px;
            height: 48px;
            object-fit: contain;
            border-radius: 0.375rem;
          }
        }

        .item-info {
          flex: 1;
          min-width: 0;

          .item-name {
            font-size: 1rem;
            font-weight: 600;
            color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
            margin: 0;
            margin-block-end: 0.25rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .item-version {
            font-size: 0.8125rem;
            color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
            margin: 0;
          }
        }
      }

      .item-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-block-start: 1rem;
        border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

        .item-time {
          font-size: 0.8125rem;
          color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        }

        .delete-btn {
          color: rgba(var(--v-theme-error), 1);
          transition: color 0.2s ease-in-out;

          &:hover {
            color: rgba(var(--v-theme-error), 0.8);
          }
        }
      }
    }
  }
}

.source-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;

  .search-section {
    padding: 1rem 1.5rem;

    .search-input {
      flex: 1;
      min-width: 200px;
      max-width: 400px;

      :deep(.v-field) {
        font-size: 0.875rem;
      }
    }

    .search-btn,
    .reset-btn,
    .install-btn {
      font-size: 0.875rem;
      font-weight: 500;
      padding-inline: 1rem;
      padding-block: 0.625rem;
      border-radius: 0.375rem;
      min-width: auto;
      transition: all 0.2s ease-in-out;

      &:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
      }
    }
  }

  .info-section {
    padding: 1rem 1.5rem;

    .info-alert {
      font-size: 0.875rem;
      line-height: 1.5;
    }
  }

  .source-table {
    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 1rem;
          padding-inline: 1rem;
        }
      }
    }

    .logo-cell {
      display: flex;
      align-items: center;
      justify-content: center;

      .logo-image-small {
        width: 32px;
        height: 32px;
        object-fit: contain;
        border-radius: 0.25rem;
      }
    }

    .country-cell {
      font-size: 0.875rem;
      font-weight: 500;
    }

    .website-link {
      font-size: 0.875rem;
      color: rgba(var(--v-theme-primary), 1);
      text-decoration: none;
      transition: color 0.2s ease-in-out;

      &:hover {
        color: rgba(var(--v-theme-primary), 0.8);
        text-decoration: underline;
      }
    }

    .description-cell {
      font-size: 0.875rem;
      max-width: 300px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .preview-cell {
      display: flex;
      align-items: center;
      justify-content: center;

      .preview-image {
        width: 60px;
        height: 100px;
        object-fit: cover;
        border-radius: 0.375rem;
        border: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
      }
    }

    .install-action-btn {
      font-size: 0.8125rem;
      padding-inline: 0.75rem;
      padding-block: 0.5rem;
      border-radius: 0.375rem;
      min-width: auto;
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem 1.5rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .pagination-info {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }
    }
  }
}
</style>
