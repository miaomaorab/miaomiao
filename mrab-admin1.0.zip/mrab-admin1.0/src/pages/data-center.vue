<script setup lang="ts">
import { paginationMeta } from '@/utils/paginationMeta'

interface DataItem {
  id: string
  clientInfo: string
  loginInfo: string
  data: string
  recordTime: string
}

const filterForm = ref({
  cardFilter: '全部',
  domain: '',
  frontend: '',
  cardNumber: '',
  createTimeStart: '',
  createTimeEnd: '',
  updateTimeStart: '',
  updateTimeEnd: '',
})

const createTimeMenu = ref(false)
const updateTimeMenu = ref(false)
const createTimeRange = ref<string[]>([])
const updateTimeRange = ref<string[]>([])

const itemsPerPage = ref(10)
const page = ref(1)
const totalItems = ref(0)
const dataList = ref<DataItem[]>([])
const selectedItems = ref<string[]>([])
const searchId = ref('')

const headers = [
  { title: '客户端信息', key: 'clientInfo' },
  { title: '登录信息', key: 'loginInfo' },
  { title: '数据', key: 'data' },
  { title: '记录时间', key: 'recordTime' },
  { title: '操作', key: 'actions', sortable: false },
]

const search = () => {
  // 查询逻辑
}

const reset = () => {
  filterForm.value = {
    cardFilter: '全部',
    domain: '',
    frontend: '',
    cardNumber: '',
    createTimeStart: '',
    createTimeEnd: '',
    updateTimeStart: '',
    updateTimeEnd: '',
  }
  createTimeRange.value = []
  updateTimeRange.value = []
}

const exportData = () => {
  // 导出逻辑
}

const clearAll = () => {
  // 清空逻辑
}
</script>

<template>
  <div class="data-center-page">
    <!-- 筛选区域 -->
    <VCard class="filter-card mb-4">
      <VCardText class="filter-content">
        <VRow class="filter-row">
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VSelect
              v-model="filterForm.cardFilter"
              :items="['全部', '已填卡', '未填卡']"
              label="填卡筛选"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.domain"
              label="域名"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.frontend"
              label="前台"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.cardNumber"
              label="卡号"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="6"
            class="filter-col"
          >
            <VMenu
              v-model="createTimeMenu"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template #activator="{ props }">
                <VTextField
                  v-bind="props"
                  :model-value="createTimeRange.length > 0 ? `${createTimeRange[0]} ~ ${createTimeRange[1] || createTimeRange[0]}` : ''"
                  label="创建时间"
                  placeholder="选择日期范围"
                  variant="outlined"
                  density="compact"
                  readonly
                  hide-details
                  class="filter-input"
                  clearable
                  @click:clear="createTimeRange = []"
                />
              </template>
              <VDatePicker
                v-model="createTimeRange"
                range
                @update:model-value="(val) => {
                  if (val && Array.isArray(val) && val.length === 2) {
                    filterForm.createTimeStart = val[0]
                    filterForm.createTimeEnd = val[1]
                  }
                }"
              />
            </VMenu>
          </VCol>
          <VCol
            cols="12"
            md="6"
            class="filter-col"
          >
            <VMenu
              v-model="updateTimeMenu"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template #activator="{ props }">
                <VTextField
                  v-bind="props"
                  :model-value="updateTimeRange.length > 0 ? `${updateTimeRange[0]} ~ ${updateTimeRange[1] || updateTimeRange[0]}` : ''"
                  label="更新时间"
                  placeholder="选择日期范围"
                  variant="outlined"
                  density="compact"
                  readonly
                  hide-details
                  class="filter-input"
                  clearable
                  @click:clear="updateTimeRange = []"
                />
              </template>
              <VDatePicker
                v-model="updateTimeRange"
                range
                @update:model-value="(val) => {
                  if (val && Array.isArray(val) && val.length === 2) {
                    filterForm.updateTimeStart = val[0]
                    filterForm.updateTimeEnd = val[1]
                  }
                }"
              />
            </VMenu>
          </VCol>
          <VCol
            cols="12"
            class="filter-actions"
          >
            <div class="d-flex gap-3">
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                class="filter-btn"
                @click="search"
              >
                <VIcon
                  icon="ri-search-line"
                  start
                  size="20"
                />
                查询
              </VBtn>
              <VBtn
                variant="outlined"
                size="default"
                class="filter-btn"
                @click="reset"
              >
                重置
              </VBtn>
            </div>
          </VCol>
        </VRow>
      </VCardText>
    </VCard>

    <!-- 数据表格（包含操作栏） -->
    <VCard class="data-table-card">
      <VDataTable
        v-model="selectedItems"
        :headers="headers"
        :items="dataList"
        :items-per-page="itemsPerPage"
        :page="page"
        show-select
        class="data-table text-no-wrap"
      >
        <template #top>
          <div class="action-bar-content">
            <div class="d-flex align-center justify-space-between flex-wrap gap-4">
              <div class="d-flex align-center gap-3 action-left">
                <span class="action-label">每页显示</span>
                <VSelect
                  v-model="itemsPerPage"
                  :items="[10, 20, 50, 100]"
                  variant="outlined"
                  density="compact"
                  hide-details
                  class="items-per-page-select"
                />
              </div>
              <div class="d-flex align-center gap-3 action-right">
                <VTextField
                  v-model="searchId"
                  placeholder="输入编号"
                  variant="outlined"
                  density="compact"
                  hide-details
                  class="search-id-input"
                />
                <VBtn
                  variant="outlined"
                  size="default"
                  class="action-btn"
                  @click="exportData"
                >
                  <VIcon
                    icon="ri-download-line"
                    start
                    size="20"
                  />
                  导出查询结果
                </VBtn>
                <VBtn
                  color="error"
                  variant="outlined"
                  size="default"
                  class="action-btn"
                  @click="clearAll"
                >
                  <VIcon
                    icon="ri-delete-bin-line"
                    start
                    size="20"
                  />
                  一键清空
                </VBtn>
              </div>
            </div>
          </div>
        </template>
        <template #item.actions>
          <IconBtn
            size="small"
            class="action-icon-btn"
          >
            <VIcon
              icon="ri-more-2-line"
              size="20"
            />
          </IconBtn>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-database-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无数据
            </p>
          </div>
        </template>
        <template #bottom>
          <div class="table-footer">
            <div class="pagination-info">
              {{ paginationMeta({ page, itemsPerPage }, totalItems) }}
            </div>
            <VPagination
              v-model="page"
              :length="Math.ceil(totalItems / itemsPerPage)"
              :total-visible="5"
              density="comfortable"
            />
          </div>
        </template>
      </VDataTable>
    </VCard>
  </div>
</template>

<style lang="scss" scoped>
.data-center-page {
  padding-block-end: 0;
}

.filter-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .filter-content {
    padding: 0.75rem 1.5rem;

    .filter-row {
      .filter-col {
        margin-block-end: 0.375rem;
      }

      .filter-input {
        :deep(.v-field) {
          font-size: 0.875rem;
        }

        :deep(.v-label) {
          font-size: 0.875rem;
        }
      }

      .filter-actions {
        margin-block-start: 0.125rem;
        padding-block-start: 0.125rem;

        .filter-btn {
          font-size: 0.875rem;
          font-weight: 500;
          padding-inline: 1.25rem;
          padding-block: 0.625rem;
          border-radius: 0.375rem;
          min-width: 100px;
          transition: all 0.2s ease-in-out;

          &:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
          }
        }
      }
    }
  }
}

.data-table-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  min-height: calc(100vh - 400px);
  display: flex;
  flex-direction: column;

  .action-bar-content {
    padding: 0.75rem 1.5rem 0.5rem;
    border-block-end: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

    .action-left {
      .action-label {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }

      .items-per-page-select {
        width: 90px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }
      }
    }

    .action-right {
      .search-id-input {
        width: 160px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }

        :deep(input::placeholder) {
          font-size: 0.875rem;
        }
      }

      .action-btn {
        font-size: 0.875rem;
        font-weight: 500;
        padding-inline: 1rem;
        padding-block: 0.625rem;
        border-radius: 0.375rem;
        min-width: auto;
        transition: all 0.2s ease-in-out;

        &:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
        }
      }
    }
  }

  .data-table {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;

    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }

      .v-data-table__tr {
        .v-data-table-header__th {
          padding-block: 0.5rem;
        }
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 0.75rem;
          padding-inline: 1rem;
        }
      }
    }

    .action-icon-btn {
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      transition: color 0.2s ease-in-out;

      &:hover {
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.5rem 1.5rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .pagination-info {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }
    }
  }
}
</style>
