<script setup lang="ts">
import { useTheme } from 'vuetify'
import { hexToRgb } from '@layouts/utils'

const vuetifyTheme = useTheme()

const cpuCores = ref(2)
const cpuUsage = ref(55.78)
const networkSpeed = ref(0)
const memoryTotal = ref(3913)
const memoryUsed = ref(1064)
const memoryAvailable = ref(2672)
const memoryBuffer = ref(56)
const memoryCache = ref(757)
const memoryUsagePercent = computed(() => Math.round((memoryUsed.value / memoryTotal.value) * 100))

// Helper function to get RGB string from color
const getRgbString = (color: string | undefined): string => {
  if (!color)
    return '0, 0, 0'
  const colorStr = String(color)

  // If already in rgb format (e.g., "rgb(140, 87, 255)" or "140, 87, 255")
  if (colorStr.includes(','))
    return colorStr.replace(/^rgb\(|\)$/g, '').trim()

  // If hex format, convert it
  const rgb = hexToRgb(colorStr)

  return rgb || '0, 0, 0'
}

const cpuChartOptions = computed(() => {
  const currentTheme = vuetifyTheme.current.value.colors
  const variableTheme = vuetifyTheme.current.value.variables

  const onSurfaceColor = currentTheme?.['on-surface'] || currentTheme?.onSurface || '#000000'
  const onSurfaceRgb = getRgbString(onSurfaceColor)

  return {
    chart: {
      type: 'radialBar',
      sparkline: { enabled: true },
    },
    plotOptions: {
      radialBar: {
        hollow: { size: '60%' },
        track: {
          background: `rgba(${onSurfaceRgb},${variableTheme['disabled-opacity'] || 0.12})`,
          strokeWidth: '100%',
        },
        dataLabels: {
          name: { show: false },
          value: {
            offsetY: 5,
            fontSize: '16px',
            fontWeight: 600,
            color: `rgba(${onSurfaceRgb},${variableTheme['high-emphasis-opacity'] || 0.87})`,
          },
        },
      },
    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        shadeIntensity: 0.5,
        gradientToColors: [currentTheme.primary],
        inverseColors: false,
        opacityFrom: 1,
        opacityTo: 0.8,
        stops: [0, 100],
      },
    },
    stroke: {
      lineCap: 'round',
      curve: 'smooth',
    },
    colors: [currentTheme.primary],
    labels: [`${cpuUsage.value}%`],
  }
})

const memoryChartOptions = computed(() => {
  const currentTheme = vuetifyTheme.current.value.colors
  const variableTheme = vuetifyTheme.current.value.variables

  const onSurfaceColor = currentTheme?.['on-surface'] || currentTheme?.onSurface || '#000000'
  const onSurfaceRgb = getRgbString(onSurfaceColor)

  return {
    chart: {
      type: 'radialBar',
      sparkline: { enabled: true },
    },
    plotOptions: {
      radialBar: {
        hollow: { size: '60%' },
        track: {
          background: `rgba(${onSurfaceRgb},${variableTheme['disabled-opacity'] || 0.12})`,
          strokeWidth: '100%',
        },
        dataLabels: {
          name: { show: false },
          value: {
            offsetY: 5,
            fontSize: '16px',
            fontWeight: 600,
            color: `rgba(${onSurfaceRgb},${variableTheme['high-emphasis-opacity'] || 0.87})`,
          },
        },
      },
    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        shadeIntensity: 0.5,
        gradientToColors: [currentTheme.success],
        inverseColors: false,
        opacityFrom: 1,
        opacityTo: 0.8,
        stops: [0, 100],
      },
    },
    stroke: {
      lineCap: 'round',
      curve: 'smooth',
    },
    colors: [currentTheme.success],
    labels: [`${memoryUsagePercent.value}%`],
  }
})

const cpuSeries = computed(() => [cpuUsage.value])
const memorySeries = computed(() => [memoryUsagePercent.value])
</script>

<template>
  <VCard class="system-monitor-card">
    <VCardTitle class="card-title">
      系统监控
    </VCardTitle>
    <VCardText>
      <VRow>
        <!-- CPU使用率 -->
        <VCol
          cols="12"
          md="4"
        >
          <VCard class="monitor-item-card">
            <VCardText class="monitor-item-content">
              <div class="d-flex align-center justify-space-between mb-3">
                <div class="monitor-item-info">
                  <h5 class="monitor-item-value">
                    {{ cpuCores }} 核心
                  </h5>
                  <div class="monitor-item-label">
                    核心数
                  </div>
                </div>
                <VueApexCharts
                  type="radialBar"
                  height="100"
                  width="100"
                  :options="cpuChartOptions"
                  :series="cpuSeries"
                />
              </div>
              <div class="monitor-item-title">
                CPU使用率
              </div>
            </VCardText>
          </VCard>
        </VCol>

        <!-- 流量 -->
        <VCol
          cols="12"
          md="4"
        >
          <VCard class="monitor-item-card">
            <VCardText class="monitor-item-content">
              <div class="d-flex align-center justify-space-between">
                <div class="monitor-item-info">
                  <h5 class="monitor-item-value">
                    流量
                  </h5>
                  <div class="monitor-item-label">
                    KB/s
                  </div>
                  <div class="monitor-item-number mt-2">
                    {{ networkSpeed }}
                  </div>
                </div>
                <VIcon
                  icon="ri-wifi-line"
                  size="64"
                  color="info"
                  class="monitor-icon"
                />
              </div>
            </VCardText>
          </VCard>
        </VCol>

        <!-- 内存使用率 -->
        <VCol
          cols="12"
          md="4"
        >
          <VCard class="monitor-item-card">
            <VCardText class="monitor-item-content">
              <div class="d-flex align-center justify-space-between">
                <div class="monitor-item-info flex-grow-1">
                  <div class="monitor-item-title mb-2">
                    内存使用率
                  </div>
                  <div class="monitor-item-label mb-3">
                    {{ memoryUsed }} / {{ memoryTotal }} (MB)
                  </div>
                  <h4 class="monitor-item-value mb-2">
                    {{ memoryTotal }}
                  </h4>
                  <div class="monitor-item-label mb-3">
                    总内存
                  </div>
                  <VList class="monitor-list">
                    <VListItem class="monitor-list-item">
                      <VListItemTitle class="monitor-list-title">
                        可用内存
                      </VListItemTitle>
                      <template #append>
                        <span class="monitor-list-value">{{ memoryAvailable }} MB</span>
                      </template>
                    </VListItem>
                    <VListItem class="monitor-list-item">
                      <VListItemTitle class="monitor-list-title">
                        缓冲
                      </VListItemTitle>
                      <template #append>
                        <span class="monitor-list-value">{{ memoryBuffer }} MB</span>
                      </template>
                    </VListItem>
                    <VListItem class="monitor-list-item">
                      <VListItemTitle class="monitor-list-title">
                        缓存
                      </VListItemTitle>
                      <template #append>
                        <span class="monitor-list-value">{{ memoryCache }} MB</span>
                      </template>
                    </VListItem>
                  </VList>
                </div>
                <VueApexCharts
                  type="radialBar"
                  height="100"
                  width="100"
                  :options="memoryChartOptions"
                  :series="memorySeries"
                />
              </div>
            </VCardText>
          </VCard>
        </VCol>
      </VRow>
    </VCardText>
  </VCard>
</template>

<style lang="scss" scoped>
.system-monitor-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .card-title {
    font-size: 1.125rem;
    font-weight: 500;
    padding: 1.5rem 1.5rem 0.75rem;
  }
}

.monitor-item-card {
  border-radius: 0.5rem;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.06);
  height: 100%;

  .monitor-item-content {
    padding: 1.25rem;
  }

  .monitor-item-info {
    flex: 1;
    min-width: 0;

    .monitor-item-value {
      font-size: 1.25rem;
      font-weight: 600;
      line-height: 1.75rem;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      margin-block-end: 0.25rem;
    }

    .monitor-item-label {
      font-size: 0.875rem;
      line-height: 1.25rem;
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
    }

    .monitor-item-title {
      font-size: 0.875rem;
      line-height: 1.25rem;
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
    }

    .monitor-item-number {
      font-size: 1.5rem;
      font-weight: 600;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
    }
  }

  .monitor-icon {
    opacity: 0.7;
  }

  .monitor-list {
    padding: 0;

    .monitor-list-item {
      padding-block: 0.5rem;
      padding-inline: 0;
      min-height: auto;

      .monitor-list-title {
        font-size: 0.875rem;
        line-height: 1.25rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        font-weight: 400;
      }

      .monitor-list-value {
        font-size: 0.875rem;
        line-height: 1.25rem;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
        font-weight: 500;
      }
    }
  }
}
</style>
