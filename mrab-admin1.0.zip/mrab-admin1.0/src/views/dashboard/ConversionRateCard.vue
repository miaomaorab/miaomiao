<script setup lang="ts">
const conversionRate = ref(0)
</script>

<template>
  <VCard class="conversion-rate-card">
    <VCardText class="card-content">
      <div class="d-flex align-center justify-space-between">
        <div class="card-text-content">
          <h6 class="card-title">
            Congratulations admin! 🎉
          </h6>
          <p class="card-subtitle">
            当日转化率
          </p>
          <h4 class="card-value">
            {{ conversionRate }}%
          </h4>
          <VBtn
            variant="text"
            size="small"
            to="/order-statistics"
            class="card-button"
          >
            查看详情
          </VBtn>
        </div>
        <div class="card-icon d-none d-md-block">
          <VIcon
            icon="ri-trophy-line"
            size="100"
            color="warning"
          />
        </div>
      </div>
    </VCardText>
  </VCard>
</template>

<style lang="scss" scoped>
.conversion-rate-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .card-content {
    padding: 1.5rem;
  }

  .card-text-content {
    .card-title {
      font-size: 1rem;
      font-weight: 500;
      line-height: 1.5rem;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      margin-block-end: 0.5rem;
    }

    .card-subtitle {
      font-size: 0.875rem;
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      margin-block-end: 0.5rem;
    }

    .card-value {
      font-size: 2rem;
      font-weight: 600;
      line-height: 2.5rem;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      margin-block-end: 1rem;
    }

    .card-button {
      font-size: 0.875rem;
      padding-inline: 0.75rem;
      padding-block: 0.5rem;
    }
  }

  .card-icon {
    opacity: 0.8;
  }
}
</style>
