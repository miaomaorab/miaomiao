/**
 * 访问控制相关API
 */

import http from '@/utils/http'

export interface Connection {
  id: number
  ip: string
  user_agent: string
  connected_at: string
  last_activity: string
  is_blacklisted?: boolean
}

export interface AccessControlSettings {
  ob_control: string
  backstage_entrance: string
  ac1: string
  ac2: string
  ac3: string
  ac4: string
  is_auto_ssl: string
  is_domain_check: string
  is_abuser: string
  is_attacker: string
  is_bogon: string
  is_cloud_provider: string
  is_proxy: string
  is_relay: string
  is_tor: string
  is_tor_exit: string
  is_vpn: string
  is_anonymous: string
  is_threat: string
}

/**
 * 获取在线连接列表
 */
export function getConnections() {
  return http.get<{ list: Connection[]; total: number }>('/access-control/connections')
}

/**
 * 获取连接详情
 */
export function getConnection(id: number) {
  return http.get<Connection>(`/access-control/connection/${id}`)
}

/**
 * 断开连接
 */
export function disconnectConnection(id: number) {
  return http.post(`/access-control/connection/${id}/disconnect`)
}

/**
 * 拉黑IP
 */
export function blacklistConnection(id: number, reason?: string) {
  return http.post(`/access-control/connection/${id}/blacklist`, { reason })
}

/**
 * 获取访问控制设置
 */
export function getAccessControlSettings() {
  return http.get<AccessControlSettings>('/access-control/settings')
}

/**
 * 更新访问控制设置
 */
export function updateAccessControlSettings(settings: Partial<AccessControlSettings>) {
  return http.put('/access-control/settings', settings)
}

/**
 * 获取白名单列表
 */
export function getWhitelist() {
  return http.get<{ list: Array<{ ip: string }>; total: number }>('/access-control/whitelist')
}

/**
 * 添加白名单IP
 */
export function addWhitelist(ip: string, reason?: string) {
  return http.post('/access-control/whitelist', { ip, reason })
}

/**
 * 移除白名单IP
 */
export function removeWhitelist(ip: string) {
  return http.delete(`/access-control/whitelist/${ip}`)
}

