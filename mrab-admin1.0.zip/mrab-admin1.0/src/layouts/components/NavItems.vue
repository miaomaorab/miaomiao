<script lang="ts" setup>
import VerticalNavSectionTitle from '@/@layouts/components/VerticalNavSectionTitle.vue'
import VerticalNavGroup from '@layouts/components/VerticalNavGroup.vue'
import VerticalNavLink from '@layouts/components/VerticalNavLink.vue'
</script>

<template>
  <!-- 👉 仪表板 -->
  <VerticalNavLink
    :item="{
      title: '仪表板',
      icon: 'ri-home-smile-line',
      to: '/',
    }"
  />

  <!-- 👉 Apps & Pages -->
  <VerticalNavSectionTitle
    :item="{
      heading: 'Apps & Pages',
    }"
  />
  <VerticalNavLink
    :item="{
      title: '访问控制',
      icon: 'ri-shield-line',
      to: '/access-control',
    }"
  />
  <VerticalNavLink
    :item="{
      title: '数据中心',
      icon: 'ri-database-line',
      to: '/apps/user/all',
    }"
  />
  <VerticalNavLink
    :item="{
      title: '订单统计',
      icon: 'ri-bar-chart-box-line',
      to: '/order',
    }"
  />

  <!-- 👉 Users & Log -->
  <VerticalNavSectionTitle
    :item="{
      heading: 'Users & Log',
    }"
  />
  <VerticalNavGroup
    :item="{
      title: '账号 & 角色',
      icon: 'ri-user-settings-line',
    }"
  >
    <VerticalNavLink
      :item="{
        title: '账号列表',
        to: '/apps/roles',
      }"
    />
    <VerticalNavLink
      :item="{
        title: '角色权限',
        to: '/apps/permissions',
      }"
    />
  </VerticalNavGroup>
  <VerticalNavGroup
    :item="{
      title: '监控管理',
      icon: 'ri-dashboard-line',
    }"
  >
    <VerticalNavLink
      :item="{
        title: '访问记录',
        to: '/record',
      }"
    />
    <VerticalNavLink
      :item="{
        title: '操作日志',
        to: '/log',
      }"
    />
    <VerticalNavLink
      :item="{
        title: 'IP黑名单',
        to: '/apps/user/blacklist',
      }"
    />
  </VerticalNavGroup>

  <!-- 👉 Others -->
  <VerticalNavSectionTitle
    :item="{
      heading: 'Others',
    }"
  />
  <VerticalNavLink
    :item="{
      title: '前台配置',
      icon: 'ri-settings-3-line',
      to: '/source/connection',
    }"
  />
  <VerticalNavGroup
    :item="{
      title: '激活 & 版本',
      icon: 'ri-key-line',
    }"
  >
    <VerticalNavLink
      :item="{
        title: '激活 & 续费',
        to: '/extensions/active',
      }"
    />
    <VerticalNavLink
      :item="{
        title: '版本更新说明',
        to: '/extensions/tour',
      }"
    />
  </VerticalNavGroup>
  <VerticalNavLink
    :item="{
      title: '系统配置',
      icon: 'ri-settings-line',
      to: '/setting/backstage',
    }"
  />
</template>
