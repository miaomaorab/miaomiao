<script lang="ts" setup>
import NavItems from '@/layouts/components/NavItems.vue'
import logo from '@images/logo.svg?raw'
import VerticalNavLayout from '@layouts/components/VerticalNavLayout.vue'

// Components
import Footer from '@/layouts/components/Footer.vue'
import NavbarThemeSwitcher from '@/layouts/components/NavbarThemeSwitcher.vue'
import UserProfile from '@/layouts/components/UserProfile.vue'
import NotificationButton from '@/layouts/components/NotificationButton.vue'

// Status data
const frontendLive = ref(0)
const backendLive = ref(0)
const licenseExpiry = ref('未授权')
const downloadCount = ref(0)

// Tooltip data
const tooltipData = ref({
  todayTotalVisits: 0,
  todayBlocked: 0,
  todayCardFills: 0,
  frontendOnline: 0,
  backendOnline: 0,
  serviceStatus: '红色 代表离线，绿色 代表在线',
})

// Refresh status
const snackbar = ref(false)
const snackbarText = ref('已刷新在线状态')

const refreshStatus = () => {
  // TODO: 调用API刷新状态
  snackbarText.value = '已刷新在线状态'
  snackbar.value = true
}

// Language selection
const currentLanguage = ref('中文')
const languageMenuOpen = ref(false)
const languages = ['中文', 'English']
</script>

<template>
  <VerticalNavLayout>
    <!-- 👉 navbar -->
    <template #navbar="{ toggleVerticalOverlayNavActive }">
      <div class="d-flex h-100 align-center">
        <!-- 👉 Vertical nav toggle in overlay mode -->
        <IconBtn
          class="ms-n3 d-lg-none"
          @click="toggleVerticalOverlayNavActive(true)"
        >
          <VIcon icon="ri-menu-line" />
        </IconBtn>

        <!-- 👉 Status Display -->
        <div class="d-flex align-center gap-3 ms-4 status-display">
          <!-- 前台 Live -->
          <VTooltip location="bottom">
            <template #activator="{ props }">
              <div
                v-bind="props"
                class="status-box status-box-clickable"
                @click="refreshStatus"
              >
                <span class="status-dot status-dot-red" />
                <span class="status-text">前台 Live：{{ frontendLive }}</span>
              </div>
            </template>
            <div class="status-tooltip-content">
              <p>今日总访问量： {{ tooltipData.todayTotalVisits }}</p>
              <p>今日已拦截数： {{ tooltipData.todayBlocked }}</p>
              <p>今日填卡人数： {{ tooltipData.todayCardFills }}</p>
              <p>前台总在线人数： {{ tooltipData.frontendOnline }}</p>
              <p>后台总在线人数： {{ tooltipData.backendOnline }}</p>
              <p>当前服务状态： {{ tooltipData.serviceStatus }}</p>
            </div>
          </VTooltip>

          <!-- 后台 Live -->
          <VTooltip location="bottom">
            <template #activator="{ props }">
              <div
                v-bind="props"
                class="status-box status-box-clickable"
                @click="refreshStatus"
              >
                <span class="status-text">后台 Live：{{ backendLive }}</span>
              </div>
            </template>
            <div class="status-tooltip-content">
              <p>今日总访问量： {{ tooltipData.todayTotalVisits }}</p>
              <p>今日已拦截数： {{ tooltipData.todayBlocked }}</p>
              <p>今日填卡人数： {{ tooltipData.todayCardFills }}</p>
              <p>前台总在线人数： {{ tooltipData.frontendOnline }}</p>
              <p>后台总在线人数： {{ tooltipData.backendOnline }}</p>
              <p>当前服务状态： {{ tooltipData.serviceStatus }}</p>
            </div>
          </VTooltip>
        </div>

        <VSpacer />

        <!-- 授权到期 -->
        <div class="status-box status-box-warning me-4">
          <span class="status-text">授权到期： {{ licenseExpiry }}</span>
          <span class="status-text-secondary">(下载次数: {{ downloadCount }})</span>
        </div>

        <!-- 字体大小调整按钮（语言选择） -->
        <VMenu
          v-model="languageMenuOpen"
          location="bottom end"
          offset="8px"
        >
          <template #activator="{ props }">
            <IconBtn
              v-bind="props"
              class="me-4"
            >
              <VIcon icon="ri-font-size" />
            </IconBtn>
          </template>
          <VList>
            <VListItem
              v-for="lang in languages"
              :key="lang"
              :active="currentLanguage === lang"
              @click="currentLanguage = lang; languageMenuOpen = false"
            >
              <VListItemTitle>{{ lang }}</VListItemTitle>
            </VListItem>
          </VList>
        </VMenu>

        <!-- 通知按钮 -->
        <NotificationButton class="me-4" />

        <NavbarThemeSwitcher class="me-4" />

        <UserProfile />
      </div>
    </template>

    <template #vertical-nav-header="{ toggleIsOverlayNavActive, isVerticalNavCollapsed, toggleVerticalNavCollapsed }">
      <RouterLink
        to="/"
        class="app-logo app-title-wrapper"
      >
        <!-- TODO: 替换logo - 参考系统使用蓝色白色灯塔logo，当前为紫色M logo -->
        <!-- 需要将 @images/logo.svg 替换为蓝色白色灯塔logo -->
        <!-- eslint-disable vue/no-v-html -->
        <div
          class="d-flex"
          v-html="logo"
        />
        <!-- eslint-enable -->

        <h1 class="font-weight-medium leading-normal text-xl text-uppercase">
          T3
        </h1>
      </RouterLink>

      <!-- 小圆圈按钮：控制菜单栏展开/收起 -->
      <IconBtn
        class="nav-collapse-toggle d-none d-lg-block"
        @click="toggleVerticalNavCollapsed"
      >
        <VIcon
          :icon="isVerticalNavCollapsed ? 'ri-arrow-right-line' : 'ri-arrow-left-line'"
          size="16"
        />
      </IconBtn>

      <IconBtn
        class="d-block d-lg-none"
        @click="toggleIsOverlayNavActive(false)"
      >
        <VIcon icon="ri-close-line" />
      </IconBtn>
    </template>

    <template #vertical-nav-content>
      <NavItems />
    </template>

    <!-- 👉 Pages -->
    <slot />

    <!-- 👉 Footer -->
    <template #footer>
      <Footer />
    </template>
  </VerticalNavLayout>

  <!-- Snackbar for refresh notification -->
  <VSnackbar
    v-model="snackbar"
    :timeout="2000"
    location="top end"
    color="success"
  >
    <div class="d-flex align-center gap-2">
      <VIcon icon="ri-checkbox-circle-line" />
      {{ snackbarText }}
    </div>
  </VSnackbar>
</template>

<style lang="scss" scoped>
:deep(.layout-navbar) {
  background-color: rgb(var(--v-theme-surface));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  border-radius: 0.5rem;
  margin-block: 0.75rem 0.5rem;
  margin-inline: 1.5rem;

  .navbar-content-container {
    padding-inline: 1.5rem;
  }
}

.meta-key {
  border: thin solid rgba(var(--v-border-color), var(--v-border-opacity));
  border-radius: 6px;
  block-size: 1.5625rem;
  line-height: 1.3125rem;
  padding-block: 0.125rem;
  padding-inline: 0.25rem;
}

.app-logo {
  display: flex;
  align-items: center;
  column-gap: 0.75rem;

  .app-logo-title {
    font-size: 1.25rem;
    font-weight: 500;
    line-height: 1.75rem;
    text-transform: uppercase;
  }
}

  .status-box {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.375rem 0.75rem;
    background-color: rgb(var(--v-theme-surface));
    border-radius: 0.25rem;
    font-size: 0.875rem;
    white-space: nowrap;

    .status-dot {
      width: 0.5rem;
      height: 0.5rem;
      border-radius: 50%;
      flex-shrink: 0;

      &.status-dot-red {
        background-color: rgb(var(--v-theme-error));
      }

      &.status-dot-green {
        background-color: rgb(var(--v-theme-success));
      }
    }

    .status-text {
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      font-weight: 500;
    }

    .status-text-secondary {
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      font-size: 0.8125rem;
    }

    &.status-box-clickable {
      cursor: pointer;
      transition: all 0.2s ease-in-out;

      &:hover {
        background-color: rgba(var(--v-theme-on-surface), 0.08);
        transform: translateY(-1px);
      }
    }

    &.status-box-warning {
      background-color: rgba(var(--v-theme-error), 0.1);
      border: 1px solid rgba(var(--v-theme-error), 0.3);
      border-radius: 0.375rem;

      .status-text {
        color: rgb(var(--v-theme-error));
      }
    }
  }

.status-display {
  .status-tooltip-content {
    padding: 0.5rem;
    font-size: 0.8125rem;
    line-height: 1.5;

    p {
      margin: 0.25rem 0;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
    }
  }
}

.nav-collapse-toggle {
  width: 20px;
  height: 20px;
  min-width: 20px;
  padding: 0;
  border-radius: 50%;
  border: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
  background-color: rgba(var(--v-theme-surface), 1);
  margin-inline-start: 0.5rem;
  transition: all 0.2s ease-in-out;
  flex-shrink: 0;

  &:hover {
    background-color: rgba(var(--v-theme-surface-variant), 0.5);
    border-color: rgba(var(--v-theme-primary), 0.5);
  }

  :deep(.v-icon) {
    font-size: 12px;
  }

  // 收起状态下，按钮仍然显示
  @at-root {
    .layout-vertical-nav-collapsed .layout-vertical-nav:not(.hovered) .nav-header & {
      display: flex;
    }
  }
}
</style>
