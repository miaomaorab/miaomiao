<script setup lang="ts">
const currentYear = new Date().getFullYear()
const systemVersion = '3.1.0'
</script>

<template>
  <div class="footer-content h-100 d-flex align-center justify-md-space-between justify-center">
    <!-- 👉 Footer: left content -->
    <span class="footer-left d-flex align-center">
      <span class="footer-text">
        &copy;
        {{ currentYear }}, made with
      </span>
      <VIcon
        icon="ri-heart-line"
        color="error"
        size="1rem"
        class="mx-1"
      />
      <span class="footer-text">by</span>
      <a
        href="javascript:;"
        class="footer-link ms-1"
      >T3</a>
    </span>
    <!-- 👉 Footer: right content -->
    <span class="footer-right d-md-flex align-center gap-2 d-none">
      <RouterLink
        to="/activation/version"
        class="footer-version-link d-flex align-center"
      >
        <span class="footer-version-text">后台版本: {{ systemVersion }}</span>
        <VIcon
          icon="ri-arrow-right-s-line"
          size="16"
          class="ms-1"
        />
        <span>系统更新</span>
      </RouterLink>
    </span>
  </div>
</template>

<style lang="scss" scoped>
.footer-content {
  padding-inline: 1.5rem;
  padding-block: 0.75rem;
}

.footer-left {
  .footer-text {
    font-size: 0.875rem;
    color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
  }

  .footer-link {
    font-size: 0.875rem;
    color: rgb(var(--v-theme-primary));
    text-decoration: none;
    transition: opacity 0.2s ease-in-out;

    &:hover {
      opacity: 0.8;
    }
  }
}

.footer-right {
  .footer-version-link {
    font-size: 0.875rem;
    color: rgb(var(--v-theme-primary));
    text-decoration: none;
    transition: opacity 0.2s ease-in-out;

    &:hover {
      opacity: 0.8;
    }

    .footer-version-text {
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
    }
  }
}
</style>
