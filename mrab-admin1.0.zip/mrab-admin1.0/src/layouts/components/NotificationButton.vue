<script setup lang="ts">
const notifications = ref([
  {
    id: 1,
    title: 'Congratulation admin! 🎉',
    message: 'Start the adventure',
    time: 'Today',
  },
])

const isMenuOpen = ref(false)

const clearAllNotifications = () => {
  notifications.value = []
  isMenuOpen.value = false
}
</script>

<template>
  <VMenu
    v-model="isMenuOpen"
    location="bottom end"
    offset="8px"
    width="320"
  >
    <template #activator="{ props }">
      <IconBtn
        v-bind="props"
        class="position-relative"
      >
        <VIcon icon="ri-notification-line" />
        <VBadge
          v-if="notifications.length > 0"
          color="error"
          :content="notifications.length"
          inline
        />
      </IconBtn>
    </template>

    <VCard>
      <VCardItem class="d-flex align-center justify-space-between">
        <VCardTitle class="text-h6">
          通知
        </VCardTitle>
        <IconBtn
          size="small"
          @click="isMenuOpen = false"
        >
          <VIcon icon="ri-close-line" />
        </IconBtn>
      </VCardItem>

      <VDivider />

      <VList>
        <VListItem
          v-for="notification in notifications"
          :key="notification.id"
          class="notification-item"
        >
          <template #prepend>
            <VAvatar
              color="primary"
              variant="tonal"
              size="40"
            >
              <VIcon icon="ri-notification-line" />
            </VAvatar>
          </template>

          <VListItemTitle class="text-sm font-weight-medium">
            {{ notification.title }}
          </VListItemTitle>
          <VListItemSubtitle class="text-xs">
            {{ notification.message }}
          </VListItemSubtitle>
          <VListItemSubtitle class="text-xs text-disabled mt-1">
            {{ notification.time }}
          </VListItemSubtitle>
        </VListItem>

        <VListItem
          v-if="notifications.length === 0"
          class="text-center py-8"
        >
          <VListItemTitle class="text-sm text-disabled">
            暂无通知
          </VListItemTitle>
        </VListItem>
      </VList>

      <VDivider v-if="notifications.length > 0" />

      <VCardActions v-if="notifications.length > 0">
        <VBtn
          block
          variant="text"
          @click="clearAllNotifications"
        >
          清空所有通知
        </VBtn>
      </VCardActions>
    </VCard>
  </VMenu>
</template>

<style lang="scss" scoped>
.notification-item {
  padding-block: 0.75rem;
  padding-inline: 1rem;
  transition: background-color 0.2s ease-in-out;

  &:hover {
    background-color: rgba(var(--v-theme-on-surface), 0.04);
  }
}
</style>
