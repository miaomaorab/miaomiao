/**
 * 系统配置相关API
 */

import http from '@/utils/http'

export interface BackstageConfig {
  api_keys?: string
  redirect_url?: string
  unattended?: string
  card_type_filter?: string
  allow_duplicate_card?: string
  data_backup?: string
}

export interface CardHead {
  id: number
  bin: string
  remark?: string
  color?: string
  create_time?: string
  update_time?: string
}

export interface NotificationConfig {
  voice_reminder?: string
  telegram_enabled?: string
  telegram_bot_token?: string
  telegram_chat_id?: string
}

/**
 * 获取后台设置
 */
export function getBackstageConfig() {
  return http.get<BackstageConfig>('/system-config/backstage')
}

/**
 * 更新后台设置
 */
export function updateBackstageConfig(config: BackstageConfig) {
  return http.put('/system-config/backstage', config)
}

/**
 * 获取卡头设置
 */
export function getCardHeads() {
  return http.get<CardHead[]>('/system-config/card-heads')
}

/**
 * 更新卡头设置
 */
export function updateCardHeads(config: { auto_reject_bins?: string }) {
  return http.put('/system-config/card-heads', config)
}

/**
 * 添加卡头
 */
export function addCardHead(data: {
  bin: string
  remark?: string
  color?: string
}) {
  return http.post<{ id: number; bin: string }>('/system-config/card-heads', data)
}

/**
 * 删除卡头
 */
export function deleteCardHead(id: number) {
  return http.delete(`/system-config/card-heads/${id}`)
}

/**
 * 添加卡头备注
 */
export function addCardRemark(data: {
  bin: string
  remark: string
  color?: string
}) {
  return http.post<{ id: number; bin: string }>('/system-config/card-heads/remarks', data)
}

/**
 * 删除卡头备注
 */
export function deleteCardRemark(id: number) {
  return http.delete(`/system-config/card-heads/remarks/${id}`)
}

/**
 * 获取通知设置
 */
export function getNotifications() {
  return http.get<NotificationConfig>('/system-config/notifications')
}

/**
 * 更新通知设置
 */
export function updateNotifications(config: NotificationConfig) {
  return http.put('/system-config/notifications', config)
}

