/**
 * 激活管理相关API
 */

import http from '@/utils/http'

export interface ActivationStatus {
  activated: boolean
  expire_time?: string
  code_type?: string
}

export interface ActivationLog {
  id: number
  auth_code: string
  action: string
  description: string
  ip: string
  created_at: string
}

/**
 * 获取激活状态
 */
export function getActivationStatus() {
  return http.get<ActivationStatus>('/activation/status')
}

/**
 * 激活系统
 */
export function activate(data: { auth_code: string }) {
  return http.post<{ expire_time: string }>('/activation/activate', data)
}

/**
 * 续费激活
 */
export function renew(data: { auth_code: string; days: number }) {
  return http.post<{ expire_time: string }>('/activation/renew', data)
}

/**
 * 获取激活日志
 */
export function getActivationLogs(params?: {
  page?: number
  limit?: number
  auth_code?: string
}) {
  return http.get<{
    list: ActivationLog[]
    total: number
    page: number
    limit: number
  }>('/activation/logs', { params })
}

