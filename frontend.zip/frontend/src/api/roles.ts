/**
 * 角色管理相关API
 */

import http from '@/utils/http'

export interface Role {
  id: number
  name: string
  permissions?: number[]
  created_at: string
}

export interface RoleListResponse {
  list: Role[]
  total: number
}

/**
 * 获取角色列表
 */
export function getRoleList() {
  return http.get<RoleListResponse>('/roles')
}

/**
 * 创建角色
 */
export function createRole(data: {
  name: string
  permissions?: number[]
}) {
  return http.post<{ id: number; name: string }>('/roles', data)
}

/**
 * 获取角色详情
 */
export function getRoleDetail(id: number) {
  return http.get<Role>(`/roles/${id}`)
}

/**
 * 更新角色
 */
export function updateRole(id: number, data: Partial<Role>) {
  return http.put(`/roles/${id}`, data)
}

/**
 * 删除角色
 */
export function deleteRole(id: number) {
  return http.delete(`/roles/${id}`)
}

/**
 * 分配权限
 */
export function assignPermissions(id: number, permissions: number[]) {
  return http.post(`/roles/${id}/permissions`, { permissions })
}

