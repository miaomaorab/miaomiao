/**
 * 订单统计相关API
 */

import http from '@/utils/http'

export interface OrderStatistics {
  conversion_rate: string
  today_visit: number
  today_blocked: number
  today_payment_users: number
  today_payment_times: number
  week_visit: number
  month_visit: number
  domain_statistics: Array<{ domain: string; count: number }>
  country_statistics: Array<{ country: string; count: number }>
  card_type_statistics: Array<{ card_type: string; count: number }>
  daily_statistics: Array<{ date: string; count: number }>
}

export interface OrderTrend {
  trend: 'up' | 'down' | 'stable'
  data: Array<{ date: string; count: number }>
  total: number
  average: number
}

export interface OrderItem {
  id: number
  domain: string
  card_number: string
  name: string
  country: string
  amount: number
  status: number
  created_at: string
}

/**
 * 获取订单统计
 */
export function getOrderStatistics(params?: {
  date_range?: string
  domain?: string
}) {
  return http.get<OrderStatistics>('/order/statistics', { params })
}

/**
 * 获取订单趋势
 */
export function getOrderTrend(params?: {
  date_range?: string
  domain?: string
}) {
  return http.get<OrderTrend>('/order/trend', { params })
}

/**
 * 获取订单列表
 */
export function getOrderList(params?: {
  page?: number
  limit?: number
  domain?: string
}) {
  return http.get<{
    list: OrderItem[]
    total: number
    page: number
    limit: number
  }>('/order/list', { params })
}

/**
 * 获取订单详情
 */
export function getOrderDetail(id: number) {
  return http.get<OrderItem>(`/order/${id}`)
}

