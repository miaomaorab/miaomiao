/**
 * 操作日志相关API
 */

import http from '@/utils/http'

export interface OperationLog {
  id: number
  user_id?: number
  username?: string
  action: string
  type?: string
  user?: string
  description?: string
  ip: string
  user_agent: string
  created_at: string
}

export interface OperationLogListResponse {
  list: OperationLog[]
  total: number
  page: number
  limit: number
}

/**
 * 获取操作日志列表
 */
export function getOperationLogList(params?: {
  page?: number
  limit?: number
  type?: string
  user?: string
  start_date?: string
  end_date?: string
}) {
  return http.get<OperationLogListResponse>('/operation-logs', { params })
}

/**
 * 获取操作日志详情
 */
export function getOperationLogDetail(id: number) {
  return http.get<OperationLog>(`/operation-logs/${id}`)
}

