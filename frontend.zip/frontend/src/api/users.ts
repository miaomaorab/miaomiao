/**
 * 用户管理相关API
 */

import http from '@/utils/http'

export interface User {
  id: number
  username: string
  name: string
  email: string
  status: number
  role_id: number
  last_login_at: string
  created_at: string
}

export interface UserListResponse {
  list: User[]
  total: number
  page: number
  limit: number
}

/**
 * 获取用户列表
 */
export function getUserList(params?: {
  page?: number
  limit?: number
  keyword?: string
}) {
  return http.get<UserListResponse>('/users', { params })
}

/**
 * 创建用户
 */
export function createUser(data: {
  username: string
  password: string
  name?: string
  email?: string
  status?: number
  role_id?: number
  remark?: string
}) {
  return http.post<{ id: number; username: string }>('/users', data)
}

/**
 * 获取用户详情
 */
export function getUserDetail(id: number) {
  return http.get<User>(`/users/${id}`)
}

/**
 * 更新用户
 */
export function updateUser(id: number, data: Partial<User>) {
  return http.put(`/users/${id}`, data)
}

/**
 * 删除用户
 */
export function deleteUser(id: number) {
  return http.delete(`/users/${id}`)
}

/**
 * 重置密码
 */
export function resetPassword(id: number, password: string) {
  return http.post(`/users/${id}/reset-password`, { password })
}

