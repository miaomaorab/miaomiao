/**
 * 源码管理相关API
 */

import http from '@/utils/http'

export interface SourceCode {
  id: number
  name: string
  type: string
  version: string
  logo?: string
  country?: string
  country_code?: string
  website?: string
  description?: string
  preview_image?: string
  update_time: string
}

export interface SourceListResponse {
  list: SourceCode[]
  total: number
  page: number
  limit: number
}

/**
 * 获取源码列表
 */
export function getSourceList(params?: {
  page?: number
  limit?: number
  keyword?: string
  type?: string
}) {
  return http.get<SourceListResponse>('/source/list', { params })
}

/**
 * 获取已下载源码列表
 */
export function getDownloadedSources(params?: {
  page?: number
  limit?: number
}) {
  return http.get<SourceListResponse>('/source/downloaded', { params })
}

/**
 * 下载源码
 */
export function downloadSource(data: {
  source_id: number
  auth_code?: string
}) {
  return http.post('/source/download', data, {
    responseType: 'blob',
  })
}

/**
 * 获取源码配置
 */
export function getSourceConfig(id: number) {
  return http.get<{
    config: Record<string, any>
    domains: Array<{
      id: number
      domain: string
      frontend_entry: string
    }>
  }>(`/source/${id}/config`)
}

/**
 * 更新源码配置
 */
export function updateSourceConfig(id: number, data: {
  config: Record<string, any>
  config_type?: string
}) {
  return http.put(`/source/${id}/config`, data)
}

/**
 * 添加域名
 */
export function addDomain(id: number, data: {
  domain: string
  frontend_entry?: string
}) {
  return http.post<{ id: number; domain: string }>(`/source/${id}/domains`, data)
}

/**
 * 删除域名
 */
export function deleteDomain(id: number, domainId: number) {
  return http.delete(`/source/${id}/domains/${domainId}`)
}

/**
 * 更新前台
 */
export function updateFrontend(id: number, data: {
  version?: string
  files?: any[]
}) {
  return http.post(`/source/${id}/update-frontend`, data)
}

