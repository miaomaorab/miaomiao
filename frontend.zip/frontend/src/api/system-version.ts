/**
 * 系统版本管理相关API
 */

import http from '@/utils/http'

export interface SystemVersion {
  id: number
  version: string
  title: string
  description?: string
  details?: any
  release_date: string
  is_current: number
  is_force_update: number
  created_at: string
}

/**
 * 获取当前版本
 */
export function getCurrentVersion() {
  return http.get<SystemVersion>('/system-version/current')
}

/**
 * 获取版本列表
 */
export function getVersionList(params?: {
  page?: number
  limit?: number
  keyword?: string
}) {
  return http.get<{
    list: SystemVersion[]
    total: number
    page: number
    limit: number
  }>('/system-version', { params })
}

/**
 * 创建版本
 */
export function createVersion(data: {
  version: string
  title: string
  description?: string
  details?: any
  release_date?: string
  is_current?: number
  is_force_update?: number
}) {
  return http.post<{ id: number; version: string }>('/system-version', data)
}

/**
 * 更新版本
 */
export function updateVersion(id: number, data: Partial<SystemVersion>) {
  return http.put(`/system-version/${id}`, data)
}

/**
 * 检查更新
 */
export function checkUpdate(currentVersion: string) {
  return http.get<{
    has_update: boolean
    latest_version?: string
    title?: string
    description?: string
    details?: any
    release_date?: string
    is_force_update?: number
    message?: string
  }>('/system-version/check-update', {
    params: { current_version: currentVersion },
  })
}

