/**
 * 数据中心相关API
 */

import http from '@/utils/http'

export interface DataCenterItem {
  id: number
  domain: string
  front_desk: string
  card_number: string
  card_type: string
  name: string
  country: string
  ip: string
  status: number
  remarks: string
  created_at: string
  updated_at: string
}

export interface DataCenterListRequest {
  page?: number
  limit?: number
  filters?: {
    domain?: string
    front_desk?: string
    card_number?: string
    created_at_start?: string
    created_at_end?: string
    status?: number
  }
}

export interface DataCenterListResponse {
  list: DataCenterItem[]
  total: number
  page: number
  limit: number
}

/**
 * 获取数据列表
 */
export function getDataList(params: DataCenterListRequest) {
  return http.post<DataCenterListResponse>('/data-center/list', params)
}

/**
 * 获取数据详情
 */
export function getDataDetail(id: number) {
  return http.get<DataCenterItem>(`/data-center/${id}`)
}

/**
 * 删除数据
 */
export function deleteData(id: number) {
  return http.delete(`/data-center/${id}`)
}

/**
 * 添加备注
 */
export function addNote(id: number, note: string) {
  return http.post(`/data-center/${id}/note`, { note })
}

/**
 * 导出数据
 */
export function exportData(params: {
  start_date?: string
  end_date?: string
  domain?: string
}) {
  return http.get('/data-center/export', {
    params,
    responseType: 'blob',
  })
}

