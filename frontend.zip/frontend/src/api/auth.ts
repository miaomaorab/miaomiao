/**
 * 认证相关API
 */

import http from '@/utils/http'

export interface LoginRequest {
  username: string
  password: string
  captcha?: string
}

export interface LoginResponse {
  token: string
  user: {
    id: number
    username: string
    name: string
    role_id: number
  }
}

export interface UserInfo {
  id: number
  username: string
  name: string
  role_id: number
  status: number
}

/**
 * 用户登录
 */
export function login(data: LoginRequest) {
  return http.post<LoginResponse>('/auth/login', data)
}

/**
 * 用户登出
 */
export function logout() {
  return http.post('/auth/logout')
}

/**
 * 获取当前用户信息
 */
export function getCurrentUser() {
  return http.get<UserInfo>('/auth/me')
}

/**
 * 刷新Token
 */
export function refreshToken(token: string) {
  return http.post<{ token: string }>('/auth/refresh', { token })
}

