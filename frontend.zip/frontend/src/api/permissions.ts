/**
 * 权限管理相关API
 */

import http from '@/utils/http'

export interface Permission {
  id: number
  name: string
  slug: string
  description?: string
  created_at: string
}

export interface PermissionListResponse {
  list: Permission[]
  total: number
  page: number
  limit: number
}

/**
 * 获取权限列表
 */
export function getPermissionList(params?: {
  page?: number
  limit?: number
  keyword?: string
}) {
  return http.get<PermissionListResponse>('/permissions', { params })
}

/**
 * 创建权限
 */
export function createPermission(data: {
  name: string
  slug: string
  description?: string
}) {
  return http.post<{ id: number; name: string; slug: string }>('/permissions', data)
}

/**
 * 获取权限详情
 */
export function getPermissionDetail(id: number) {
  return http.get<Permission>(`/permissions/${id}`)
}

/**
 * 更新权限
 */
export function updatePermission(id: number, data: Partial<Permission>) {
  return http.put(`/permissions/${id}`, data)
}

/**
 * 删除权限
 */
export function deletePermission(id: number) {
  return http.delete(`/permissions/${id}`)
}

