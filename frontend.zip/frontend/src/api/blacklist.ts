/**
 * 黑名单管理相关API
 */

import http from '@/utils/http'

export interface BlacklistItem {
  id: number
  ip: string
  domain?: string
  reason?: string
  user_id?: number
  is_active: boolean
  created_at: string
}

export interface BlacklistListResponse {
  list: BlacklistItem[]
  total: number
  page: number
  limit: number
}

/**
 * 获取黑名单列表
 */
export function getBlacklistList(params?: {
  page?: number
  limit?: number
  ip?: string
  domain?: string
}) {
  return http.get<BlacklistListResponse>('/blacklist', { params })
}

/**
 * 获取黑名单详情
 */
export function getBlacklistDetail(id: number) {
  return http.get<BlacklistItem>(`/blacklist/${id}`)
}

/**
 * 移除黑名单
 */
export function removeBlacklist(id: number) {
  return http.delete(`/blacklist/${id}`)
}

/**
 * 通过IP移除黑名单
 */
export function removeBlacklistByIp(ip: string) {
  return http.delete(`/blacklist/ip/${ip}`)
}

