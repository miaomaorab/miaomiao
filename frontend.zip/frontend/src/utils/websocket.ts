/**
 * WebSocket客户端封装
 */

import { WS_BASE_URL, TOKEN_KEY } from '@/config/api'

export interface WebSocketMessage {
  type: string
  data?: any
  timestamp?: number
}

export type WebSocketMessageHandler = (message: WebSocketMessage) => void

class WebSocketClient {
  private ws: WebSocket | null = null
  private url: string
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectDelay = 3000
  private messageHandlers: Map<string, WebSocketMessageHandler[]> = new Map()
  private isConnecting = false

  constructor(url?: string) {
    this.url = url || WS_BASE_URL
  }

  /**
   * 连接WebSocket
   */
  connect(token?: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        resolve()
        return
      }

      if (this.isConnecting) {
        reject(new Error('正在连接中'))
        return
      }

      this.isConnecting = true

      try {
        // 如果有token，添加到连接URL
        const connectUrl = token
          ? `${this.url}?token=${token}`
          : this.url

        this.ws = new WebSocket(connectUrl)

        this.ws.onopen = () => {
          this.isConnecting = false
          this.reconnectAttempts = 0
          console.log('WebSocket connected')
          
          // 如果连接时没有token，尝试发送认证消息
          if (!token) {
            const storedToken = localStorage.getItem(TOKEN_KEY)
            if (storedToken) {
              this.send({
                type: 'auth',
                token: storedToken,
              })
            }
          }
          
          resolve()
        }

        this.ws.onmessage = (event) => {
          try {
            const message: WebSocketMessage = JSON.parse(event.data)
            this.handleMessage(message)
          } catch (error) {
            console.error('Failed to parse WebSocket message:', error)
          }
        }

        this.ws.onerror = (error) => {
          this.isConnecting = false
          console.error('WebSocket error:', error)
          reject(error)
        }

        this.ws.onclose = () => {
          this.isConnecting = false
          console.log('WebSocket closed')
          this.attemptReconnect(token)
        }
      } catch (error) {
        this.isConnecting = false
        reject(error)
      }
    })
  }

  /**
   * 断开连接
   */
  disconnect() {
    if (this.ws) {
      this.ws.close()
      this.ws = null
    }
    this.reconnectAttempts = this.maxReconnectAttempts // 停止重连
  }

  /**
   * 发送消息
   */
  send(message: WebSocketMessage) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message))
    } else {
      console.warn('WebSocket is not connected')
    }
  }

  /**
   * 订阅消息
   */
  on(messageType: string, handler: WebSocketMessageHandler) {
    if (!this.messageHandlers.has(messageType)) {
      this.messageHandlers.set(messageType, [])
    }
    this.messageHandlers.get(messageType)!.push(handler)
  }

  /**
   * 取消订阅
   */
  off(messageType: string, handler?: WebSocketMessageHandler) {
    if (!handler) {
      this.messageHandlers.delete(messageType)
      return
    }

    const handlers = this.messageHandlers.get(messageType)
    if (handlers) {
      const index = handlers.indexOf(handler)
      if (index > -1) {
        handlers.splice(index, 1)
      }
    }
  }

  /**
   * 处理消息
   */
  private handleMessage(message: WebSocketMessage) {
    // 处理心跳
    if (message.type === 'ping') {
      this.send({ type: 'pong', timestamp: Date.now() })
      return
    }

    // 调用对应的处理器
    const handlers = this.messageHandlers.get(message.type)
    if (handlers) {
      handlers.forEach(handler => handler(message))
    }

    // 调用通用处理器
    const allHandlers = this.messageHandlers.get('*')
    if (allHandlers) {
      allHandlers.forEach(handler => handler(message))
    }
  }

  /**
   * 尝试重连
   */
  private attemptReconnect(token?: string) {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log('Max reconnect attempts reached')
      return
    }

    this.reconnectAttempts++
    console.log(`Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts})...`)

    setTimeout(() => {
      this.connect(token).catch(() => {
        // 重连失败，继续尝试
      })
    }, this.reconnectDelay)
  }

  /**
   * 获取连接状态
   */
  getState(): number {
    if (!this.ws) return WebSocket.CLOSED
    return this.ws.readyState
  }

  /**
   * 是否已连接
   */
  isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN
  }
}

// 创建单例
export const wsClient = new WebSocketClient()

export default wsClient

