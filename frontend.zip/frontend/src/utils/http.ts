/**
 * HTTP客户端封装
 */

import axios, { type AxiosInstance, type AxiosRequestConfig, type AxiosResponse } from 'axios'
import { API_BASE_URL, REQUEST_TIMEOUT, TOKEN_KEY } from '@/config/api'

// 创建axios实例
const http: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: REQUEST_TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
})

// 请求拦截器
http.interceptors.request.use(
  (config) => {
    // 从localStorage获取token
    const token = localStorage.getItem(TOKEN_KEY)
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器
http.interceptors.response.use(
  (response: AxiosResponse) => {
    const { data } = response
    
    // 统一处理响应格式
    // 后端返回格式：{ code: 200, message: '...', data: {...} }
    // 如果成功，返回整个data对象，前端通过 response.data 访问
    if (data && (data.code === 200 || data.code === 0)) {
      return data
    }
    
    // Token过期，尝试刷新
    if (data && data.code === 401) {
      localStorage.removeItem(TOKEN_KEY)
      if (window.location.pathname !== '/login' && !window.location.hash.includes('login')) {
        window.location.href = '/#/login'
      }
      return Promise.reject(new Error(data.message || '登录已过期，请重新登录'))
    }
    
    // 其他错误
    return Promise.reject(new Error(data?.message || '请求失败'))
  },
  (error) => {
    // 处理网络错误
    if (error.response) {
      const { status, data } = error.response
      
      if (status === 401) {
        localStorage.removeItem(TOKEN_KEY)
        // 使用 router 跳转，避免直接修改 location
        if (window.location.pathname !== '/login') {
          window.location.href = '/login'
        }
        return Promise.reject(new Error('登录已过期，请重新登录'))
      }
      
      return Promise.reject(new Error(data?.message || `请求失败: ${status}`))
    }
    
    if (error.request) {
      // 网络错误，可能是后端未启动或无法连接
      console.error('网络连接失败:', {
        message: error.message,
        code: error.code,
        config: error.config,
      })
      
      // 检查是否是网络连接错误
      if (error.code === 'ECONNREFUSED' || error.code === 'ERR_NETWORK') {
        return Promise.reject(new Error('无法连接到服务器，请检查后端服务是否启动（端口9501）'))
      }
      
      // 检查是否是超时错误
      if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
        return Promise.reject(new Error('请求超时，请检查网络连接'))
      }
      
      // 如果是CORS错误，提供更明确的错误信息
      if (error.message && (error.message.includes('CORS') || error.message.includes('cors'))) {
        return Promise.reject(new Error('CORS错误：请检查后端CORS配置'))
      }
      
      return Promise.reject(new Error('网络连接失败，请检查后端服务是否启动'))
    }
    
    return Promise.reject(error)
  }
)

export default http

