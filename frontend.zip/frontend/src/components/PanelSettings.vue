<script setup lang="ts">
import { useRouter } from 'vue-router'

interface PanelSettings {
  domainSecurityWarning: boolean
  dataReverseOrder: boolean
  hideTabs: boolean
  hideAddressBar: boolean
  hideBinBar: boolean
  hidePhoneBar: boolean
  hideBirthdayBar: boolean
  onlyShowCardData: boolean
  hideNoDataClients: boolean
  customVerificationCode: boolean
  unattended: boolean
  allowDuplicateCard: boolean
  cardTypeFilter: 'off' | 'c' | 'd'
  navType: 'sticky' | 'hidden'
  footerType: 'static' | 'hidden'
  collapseMenu: boolean
  semiDarkMenu: boolean
}

const settings = ref<PanelSettings>({
  domainSecurityWarning: false,
  dataReverseOrder: true,
  hideTabs: false,
  hideAddressBar: true,
  hideBinBar: false,
  hidePhoneBar: false,
  hideBirthdayBar: false,
  onlyShowCardData: false,
  hideNoDataClients: false,
  customVerificationCode: true,
  unattended: false,
  allowDuplicateCard: true,
  cardTypeFilter: 'off',
  navType: 'sticky',
  footerType: 'static',
  collapseMenu: false,
  semiDarkMenu: false,
})

const isOpen = defineModel<boolean>({ default: false })

const openAutoRejectBinsDialog = () => {
  // 打开自动拒绝的卡头配置对话框
  // 这里可以导航到系统配置页面的卡头设置标签页，或者打开一个对话框
  // 暂时使用路由跳转
  const router = useRouter()
  router.push('/setting/backstage?tab=cardHeader')
}
</script>

<template>
  <VNavigationDrawer
    v-model="isOpen"
    location="end"
    width="420"
    class="panel-settings-drawer"
  >
    <template #prepend>
      <VCardItem class="drawer-header">
        <VCardTitle class="drawer-title">
          面板设置
        </VCardTitle>
        <VCardSubtitle class="drawer-subtitle">
          实时自定义和预览
        </VCardSubtitle>
        <template #append>
          <IconBtn
            class="close-btn"
            @click="isOpen = false"
          >
            <VIcon
              icon="ri-close-line"
              size="20"
            />
          </IconBtn>
        </template>
      </VCardItem>
    </template>

    <VDivider class="drawer-divider" />

    <VList class="settings-list">
      <VListSubheader class="settings-subheader">
        数据展示
      </VListSubheader>
      <VListItem>
        <VListItemTitle>域名安全警告弹窗</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.domainSecurityWarning" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>数据倒序排列</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.dataReverseOrder" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>隐藏标签栏</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.hideTabs" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>隐藏地址栏</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.hideAddressBar" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>隐藏BIN栏</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.hideBinBar" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>隐藏电话栏</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.hidePhoneBar" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>隐藏生日栏</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.hideBirthdayBar" />
        </template>
      </VListItem>

      <VDivider class="settings-divider" />

      <VListSubheader class="settings-subheader">
        过滤设置
      </VListSubheader>
      <VListItem>
        <VListItemTitle>只显示填卡数据</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.onlyShowCardData" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>隐藏无数据客户端</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.hideNoDataClients" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>自定义验证码手机尾号</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.customVerificationCode" />
        </template>
      </VListItem>

      <VDivider class="settings-divider" />

      <VListSubheader class="settings-subheader">
        功能设置
      </VListSubheader>
      <VListItem>
        <VListItemTitle>无人值守</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.unattended" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>允许重复卡号提交</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.allowDuplicateCard" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>按卡类型筛选</VListItemTitle>
        <template #append>
          <VRadioGroup
            v-model="settings.cardTypeFilter"
            inline
          >
            <VRadio
              label="关闭"
              value="off"
            />
            <VRadio
              label="只要C卡"
              value="c"
            />
            <VRadio
              label="只要D卡"
              value="d"
            />
          </VRadioGroup>
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>自动拒绝的卡头</VListItemTitle>
        <template #append>
          <VBtn
            icon
            variant="text"
            size="small"
            @click="openAutoRejectBinsDialog"
          >
            <VIcon
              icon="ri-settings-3-line"
              size="20"
            />
          </VBtn>
        </template>
      </VListItem>

      <VDivider class="settings-divider" />

      <VListSubheader class="settings-subheader">
        LAYOUT
      </VListSubheader>
      <VListItem>
        <VListItemTitle>导航类型</VListItemTitle>
        <template #append>
          <VRadioGroup
            v-model="settings.navType"
            inline
          >
            <VRadio
              label="Sticky"
              value="sticky"
            />
            <VRadio
              label="Hidden"
              value="hidden"
            />
          </VRadioGroup>
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>页脚类型</VListItemTitle>
        <template #append>
          <VRadioGroup
            v-model="settings.footerType"
            inline
          >
            <VRadio
              label="Static"
              value="static"
            />
            <VRadio
              label="Hidden"
              value="hidden"
            />
          </VRadioGroup>
        </template>
      </VListItem>

      <VDivider class="settings-divider" />

      <VListSubheader class="settings-subheader">
        MENU
      </VListSubheader>
      <VListItem>
        <VListItemTitle>折叠菜单</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.collapseMenu" />
        </template>
      </VListItem>
      <VListItem>
        <VListItemTitle>半暗菜单</VListItemTitle>
        <template #append>
          <VSwitch v-model="settings.semiDarkMenu" />
        </template>
      </VListItem>
    </VList>
  </VNavigationDrawer>
</template>

<style lang="scss" scoped>
.panel-settings-drawer {
  :deep(.v-navigation-drawer__content) {
    background-color: rgb(var(--v-theme-surface));
  }

  .drawer-header {
    padding: 1.5rem 1.5rem 1rem;

    .drawer-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      margin-block-end: 0.25rem;
    }

    .drawer-subtitle {
      font-size: 0.875rem;
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
    }

    .close-btn {
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      transition: color 0.2s ease-in-out;

      &:hover {
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }
  }

  .drawer-divider {
    margin: 0;
  }

  .settings-list {
    padding: 0.5rem 0;

    .settings-subheader {
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      padding-inline: 1.5rem;
      padding-block: 1rem 0.75rem;
      margin-block-start: 0.5rem;
    }

    .settings-divider {
      margin-block: 0.5rem;
    }

    :deep(.v-list-item) {
      padding-inline: 1.5rem;
      padding-block: 0.875rem;
      min-height: 48px;

      .v-list-item-title {
        font-size: 0.875rem;
        font-weight: 400;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
        line-height: 1.5rem;
      }

      .v-list-item__append {
        .v-switch {
          margin-inline-start: 0.5rem;
        }

        .v-radio-group {
          margin-inline-start: 0.5rem;

          .v-radio {
            margin-inline-end: 1rem;

            :deep(.v-label) {
              font-size: 0.875rem;
            }
          }
        }
      }
    }
  }
}
</style>
