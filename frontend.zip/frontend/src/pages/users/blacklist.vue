<script setup lang="ts">
import { paginationMeta } from '@/utils/paginationMeta'
import { getBlacklistList, removeBlacklist } from '@/api/blacklist'
import type { BlacklistItem as ApiBlacklistItem } from '@/api/blacklist'

interface BlacklistItem {
  id: string | number
  ip: string
  remark: string
  operator: string
  createTime: string
}

const blacklist = ref<BlacklistItem[]>([])
const selectedItems = ref<string[]>([])
const isAddDialogOpen = ref(false)
const currentItem = ref<Partial<BlacklistItem>>({})
const filterForm = ref({
  ip: '',
})
const itemsPerPage = ref(10)
const page = ref(1)
const totalItems = ref(0)
const loading = ref(false)

// 转换后端数据格式到前端格式
const transformBlacklistItem = (item: ApiBlacklistItem): BlacklistItem => {
  return {
    id: item.id,
    ip: item.ip,
    remark: item.reason || '',
    operator: item.user_id?.toString() || 'system',
    createTime: item.created_at || '',
  }
}

// 加载黑名单列表
const loadBlacklist = async () => {
  try {
    loading.value = true
    const filters: any = {}
    
    if (filterForm.value.ip) {
      filters.ip = filterForm.value.ip
    }
    
    const response = await getBlacklistList({
      page: page.value,
      limit: itemsPerPage.value,
      ...filters,
    })
    
    if (response && response.data) {
      blacklist.value = (response.data.list || []).map(transformBlacklistItem)
      totalItems.value = response.data.total || 0
    }
  } catch (error) {
    console.error('加载黑名单列表失败:', error)
  } finally {
    loading.value = false
  }
}

// 页面加载时获取数据
onMounted(() => {
  loadBlacklist()
})

const headers = [
  { title: 'IP', key: 'ip' },
  { title: '备注', key: 'remark' },
  { title: '操作人', key: 'operator' },
  { title: '创建时间', key: 'createTime' },
  { title: '操作', key: 'actions', sortable: false },
]

const search = () => {
  page.value = 1
  loadBlacklist()
}

const reset = () => {
  filterForm.value = {
    ip: '',
  }
  page.value = 1
  loadBlacklist()
}

const openAddDialog = () => {
  currentItem.value = {
    ip: '',
    remark: '',
    operator: 'admin',
  }
  isAddDialogOpen.value = true
}

const saveItem = async () => {
  try {
    loading.value = true
    // TODO: 实现添加黑名单的API调用
    // 目前黑名单是通过访问控制页面添加的
    // await addBlacklist({ ip: currentItem.value.ip, reason: currentItem.value.remark })
    isAddDialogOpen.value = false
    await loadBlacklist()
  } catch (error) {
    console.error('保存黑名单失败:', error)
  } finally {
    loading.value = false
  }
}

const deleteItem = async (id: string | number) => {
  try {
    loading.value = true
    await removeBlacklist(Number(id))
    await loadBlacklist()
  } catch (error) {
    console.error('删除黑名单失败:', error)
  } finally {
    loading.value = false
  }
}

const clearAll = () => {
  blacklist.value = []
}
</script>

<template>
  <div>
    <!-- 筛选区域 -->
    <VCard class="filter-card mb-4">
      <VCardText class="filter-content">
        <VRow class="filter-row">
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.ip"
              label="IP"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="9"
            class="filter-actions"
          >
            <div class="d-flex gap-3">
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                class="filter-btn"
                @click="search"
              >
                <VIcon
                  icon="ri-search-line"
                  start
                  size="20"
                />
                查询
              </VBtn>
              <VBtn
                variant="outlined"
                size="default"
                class="filter-btn"
                @click="reset"
              >
                重置
              </VBtn>
            </div>
          </VCol>
        </VRow>
      </VCardText>
    </VCard>

    <!-- 操作栏 -->
    <VCard class="action-bar-card mb-4">
      <VCardText class="action-bar-content">
        <div class="d-flex align-center justify-space-between flex-wrap gap-4">
          <div class="d-flex align-center gap-2 action-left">
            <span class="action-label">每页显示</span>
            <VSelect
              v-model="itemsPerPage"
              :items="[10, 20, 50, 100]"
              variant="outlined"
              density="compact"
              hide-details
              class="items-per-page-select"
            />
          </div>
          <div class="d-flex align-center gap-3 action-right">
            <VBtn
              color="primary"
              variant="elevated"
              size="default"
              class="action-btn"
              @click="openAddDialog"
            >
              <VIcon
                icon="ri-add-line"
                start
                size="20"
              />
              添加黑名单
            </VBtn>
            <VBtn
              color="error"
              variant="outlined"
              size="default"
              class="action-btn"
              @click="clearAll"
            >
              <VIcon
                icon="ri-delete-bin-line"
                start
                size="20"
              />
              一键清空
            </VBtn>
          </div>
        </div>
      </VCardText>
    </VCard>

    <!-- IP黑名单列表 -->
    <VCard class="blacklist-table-card">
      <VDataTable
        v-model="selectedItems"
        :headers="headers"
        :items="blacklist"
        :items-per-page="itemsPerPage"
        :page="page"
        class="blacklist-table text-no-wrap"
      >
        <template #item.actions="{ item }">
          <div class="d-flex gap-2 action-buttons">
            <IconBtn
              size="small"
              color="error"
              class="action-icon-btn"
              @click="deleteItem(item.id)"
            >
              <VIcon
                icon="ri-delete-bin-line"
                size="20"
              />
            </IconBtn>
          </div>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-shield-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无数据
            </p>
          </div>
        </template>
        <template #bottom>
          <div class="table-footer">
            <div class="pagination-info">
              {{ paginationMeta({ page, itemsPerPage }, totalItems) }}
            </div>
            <VPagination
              v-model="page"
              :length="Math.ceil(totalItems / itemsPerPage)"
              :total-visible="5"
              density="comfortable"
            />
          </div>
        </template>
      </VDataTable>
    </VCard>

    <!-- 添加对话框 -->
    <VDialog
      v-model="isAddDialogOpen"
      max-width="500"
    >
      <VCard>
        <VCardTitle>添加黑名单</VCardTitle>
        <VCardText>
          <VTextField
            v-model="currentItem.ip"
            label="IP"
            placeholder="例如: 192.168.1.1"
            variant="outlined"
            class="mb-4"
          />
          <VTextarea
            v-model="currentItem.remark"
            label="备注"
            variant="outlined"
            rows="3"
          />
        </VCardText>
        <VCardActions>
          <VSpacer />
          <VBtn
            variant="outlined"
            @click="isAddDialogOpen = false"
          >
            取消
          </VBtn>
          <VBtn
            color="primary"
            @click="saveItem"
          >
            保存
          </VBtn>
        </VCardActions>
      </VCard>
    </VDialog>
  </div>
</template>

<style lang="scss" scoped>
.filter-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .filter-content {
    padding: 1.5rem;

    .filter-row {
      .filter-col {
        margin-block-end: 0.75rem;
      }

      .filter-input {
        :deep(.v-field) {
          font-size: 0.875rem;
        }

        :deep(.v-label) {
          font-size: 0.875rem;
        }
      }

      .filter-actions {
        margin-block-start: 0.5rem;
        padding-block-start: 0.5rem;

        .filter-btn {
          font-size: 0.875rem;
          font-weight: 500;
          padding-inline: 1.25rem;
          padding-block: 0.625rem;
          border-radius: 0.375rem;
          min-width: 100px;
          transition: all 0.2s ease-in-out;

          &:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
          }
        }
      }
    }
  }
}

.action-bar-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .action-bar-content {
    padding: 1rem 1.5rem;

    .action-left {
      .action-label {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }

      .items-per-page-select {
        width: 90px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }
      }
    }

    .action-right {
      .action-btn {
        font-size: 0.875rem;
        font-weight: 500;
        padding-inline: 1rem;
        padding-block: 0.625rem;
        border-radius: 0.375rem;
        min-width: auto;
        transition: all 0.2s ease-in-out;

        &:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
        }
      }
    }

    .action-right {
      .action-label {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }

      .items-per-page-select {
        width: 90px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }
      }
    }
  }
}

.blacklist-table-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;

  .blacklist-table {
    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 1rem;
          padding-inline: 1rem;
        }
      }
    }

    .action-buttons {
      .action-icon-btn {
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        transition: color 0.2s ease-in-out;

        &:hover {
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
        }
      }
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem 1.5rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .pagination-info {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }
    }
  }
}
</style>
