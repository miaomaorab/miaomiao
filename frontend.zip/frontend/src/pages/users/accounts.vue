<script setup lang="ts">
import { paginationMeta } from '@/utils/paginationMeta'
import { getUserList, createUser, updateUser, deleteUser, resetPassword } from '@/api/users'
import { getRoleList } from '@/api/roles'
import type { User } from '@/api/users'
import type { Role } from '@/api/roles'

interface Account {
  id: string | number
  username: string
  password?: string
  role: string
  role_id?: number
  nickname: string
  remark: string
  ip: string
  userAgent: string
  status: 'active' | 'inactive'
  createTime: string
  lastLogin: string
}

const accounts = ref<Account[]>([])
const roles = ref<Role[]>([])
const selectedAccounts = ref<string[]>([])
const isAddDialogOpen = ref(false)
const isEditDialogOpen = ref(false)
const currentAccount = ref<Partial<Account>>({})
const itemsPerPage = ref(10)
const page = ref(1)
const totalItems = ref(0)
const loading = ref(false)

const filterForm = ref({
  userStatus: 'all',
  account: '',
})

// 转换后端数据格式到前端格式
const transformUser = (user: User, roleMap: Map<number, string>): Account => {
  return {
    id: user.id,
    username: user.username,
    role: roleMap.get(user.role_id) || '未知角色',
    role_id: user.role_id,
    nickname: user.name,
    remark: '',
    ip: '',
    userAgent: '',
    status: user.status === 1 ? 'active' : 'inactive',
    createTime: user.created_at,
    lastLogin: user.last_login_at || '-',
  }
}

// 加载用户列表
const loadUsers = async () => {
  try {
    loading.value = true
    const [usersResponse, rolesResponse] = await Promise.all([
      getUserList({
        page: page.value,
        limit: itemsPerPage.value,
        keyword: filterForm.value.account || undefined,
      }),
      getRoleList(),
    ])
    
    // 创建角色映射
    const roleMap = new Map<number, string>()
    if (rolesResponse && rolesResponse.data && rolesResponse.data.list) {
      roles.value = rolesResponse.data.list
      rolesResponse.data.list.forEach((role: Role) => {
        roleMap.set(role.id, role.name)
      })
    }
    
    // 转换用户数据
    if (usersResponse && usersResponse.data && usersResponse.data.list) {
      accounts.value = usersResponse.data.list.map((user: User) => transformUser(user, roleMap))
      totalItems.value = usersResponse.data.total || 0
    }
  } catch (error) {
    console.error('加载用户列表失败:', error)
  } finally {
    loading.value = false
  }
}

// 页面加载时获取数据
onMounted(() => {
  loadUsers()
})

const handleSearch = () => {
  page.value = 1
  loadUsers()
}

const handleReset = () => {
  filterForm.value = {
    userStatus: 'all',
    account: '',
  }
  page.value = 1
  loadUsers()
}

const headers = [
  { title: '账号', key: 'username' },
  { title: '密码', key: 'password' },
  { title: '角色', key: 'role' },
  { title: '昵称', key: 'nickname' },
  { title: '备注', key: 'remark' },
  { title: 'IP', key: 'ip' },
  { title: 'User-Agent', key: 'userAgent' },
  { title: '上次登录时间', key: 'lastLogin' },
  { title: '创建时间', key: 'createTime' },
  { title: '状态', key: 'status' },
  { title: '操作', key: 'actions', sortable: false },
]

// 角色选项（从API获取）
const roleOptions = computed(() => roles.value.map(r => r.name))

const openAddDialog = () => {
  currentAccount.value = {
    username: '',
    password: '',
    role: '游客',
    nickname: '',
    remark: '',
    status: 'active',
  }
  isAddDialogOpen.value = true
}

const openEditDialog = (account: Account) => {
  currentAccount.value = { ...account }
  isEditDialogOpen.value = true
}

const saveAccount = async () => {
  try {
    loading.value = true
    if (isAddDialogOpen.value) {
      // 创建用户
      const roleId = roles.value.find(r => r.name === currentAccount.value.role)?.id
      await createUser({
        username: currentAccount.value.username || '',
        password: currentAccount.value.password || '',
        name: currentAccount.value.nickname || '',
        role_id: roleId,
        status: currentAccount.value.status === 'active' ? 1 : 0,
      })
      isAddDialogOpen.value = false
      await loadUsers()
    }
    else {
      // 更新用户
      const roleId = roles.value.find(r => r.name === currentAccount.value.role)?.id
      await updateUser(Number(currentAccount.value.id), {
        name: currentAccount.value.nickname || '',
        role_id: roleId,
        status: currentAccount.value.status === 'active' ? 1 : 0,
      })
      isEditDialogOpen.value = false
      await loadUsers()
    }
  } catch (error) {
    console.error('保存用户失败:', error)
  } finally {
    loading.value = false
  }
  
  // 旧代码保留作为参考
  /*
  if (isAddDialogOpen.value) {
    accounts.value.push({
      id: Date.now().toString(),
      username: currentAccount.value.username || '',
      password: currentAccount.value.password || '',
      role: currentAccount.value.role || '游客',
      nickname: currentAccount.value.nickname || '',
      remark: currentAccount.value.remark || '',
      ip: '',
      userAgent: '',
      status: currentAccount.value.status || 'active',
      createTime: new Date().toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      }).replace(/\//g, '-'),
      lastLogin: '-',
    })
    isAddDialogOpen.value = false
  }
  else {
    const index = accounts.value.findIndex(a => a.id === currentAccount.value.id)
    if (index !== -1) {
      accounts.value[index] = {
        ...accounts.value[index],
        password: currentAccount.value.password || accounts.value[index].password,
        role: currentAccount.value.role || accounts.value[index].role,
        nickname: currentAccount.value.nickname || accounts.value[index].nickname,
        remark: currentAccount.value.remark || accounts.value[index].remark,
        status: currentAccount.value.status || accounts.value[index].status,
      }
    }
    isEditDialogOpen.value = false
  }
}

const deleteAccount = async (id: string | number) => {
  try {
    loading.value = true
    await deleteUser(Number(id))
    await loadUsers()
  } catch (error) {
    console.error('删除用户失败:', error)
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div>
    <!-- 提示信息 -->
    <VCard class="info-card mb-4">
      <VCardText class="info-content">
        <div class="info-text">
          <p class="mb-2">
            您可以进入角色权限界面，设置相应的角色权限
          </p>
          <p class="mb-2">
            可前往系统设置打开和关闭分流
          </p>
          <p class="mb-0">
            注意：游客不分流，如需分流功能，请创建一个新的角色，再分配给对应账号
          </p>
        </div>
      </VCardText>
    </VCard>

    <!-- 查询筛选区域 -->
    <VCard class="filter-card mb-4">
      <VCardText class="filter-content">
        <VRow class="filter-row">
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VSelect
              v-model="filterForm.userStatus"
              :items="[{ title: '全部', value: 'all' }, { title: '启用', value: 'active' }, { title: '禁用', value: 'inactive' }]"
              label="用户状态"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.account"
              label="账号"
              placeholder="请输入账号"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="6"
            class="filter-actions"
          >
            <div class="d-flex gap-3">
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                class="filter-btn"
                @click="handleSearch"
              >
                <VIcon
                  icon="ri-search-line"
                  start
                  size="20"
                />
                查询
              </VBtn>
              <VBtn
                variant="outlined"
                size="default"
                class="filter-btn"
                @click="handleReset"
              >
                重置
              </VBtn>
            </div>
          </VCol>
        </VRow>
      </VCardText>
    </VCard>

    <!-- 操作栏 -->
    <VCard class="action-bar-card mb-4">
      <VCardText class="action-bar-content">
        <div class="d-flex align-center justify-space-between flex-wrap gap-4">
          <div class="d-flex align-center gap-2 action-right">
            <span class="action-label">每页显示</span>
            <VSelect
              v-model="itemsPerPage"
              :items="[10, 20, 50, 100]"
              variant="outlined"
              density="compact"
              hide-details
              class="items-per-page-select"
            />
          </div>
          <VBtn
            color="primary"
            variant="elevated"
            size="default"
            class="action-btn"
            @click="openAddDialog"
          >
            <VIcon
              icon="ri-add-line"
              start
              size="20"
            />
            新增用户
          </VBtn>
        </div>
      </VCardText>
    </VCard>

    <!-- 账号列表 -->
    <VCard class="accounts-table-card">
      <VDataTable
        v-model="selectedAccounts"
        :headers="headers"
        :items="accounts"
        :items-per-page="itemsPerPage"
        :page="page"
        show-select
        class="accounts-table text-no-wrap"
      >
        <template #item.role="{ item }">
          <VChip
            color="primary"
            size="small"
            class="role-chip"
          >
            {{ item.role }}
          </VChip>
        </template>
        <template #item.status="{ item }">
          <span class="status-text">{{ item.status === 'active' ? '启用' : '禁用' }}</span>
        </template>
        <template #item.actions="{ item }">
          <div class="d-flex gap-2 action-buttons">
            <IconBtn
              size="small"
              class="action-icon-btn"
              @click="openEditDialog(item)"
            >
              <VIcon
                icon="ri-edit-line"
                size="20"
              />
            </IconBtn>
            <IconBtn
              size="small"
              color="error"
              class="action-icon-btn"
              @click="deleteAccount(item.id)"
            >
              <VIcon
                icon="ri-delete-bin-line"
                size="20"
              />
            </IconBtn>
          </div>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-user-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无账号数据
            </p>
          </div>
        </template>
        <template #bottom>
          <div class="table-footer">
            <div class="pagination-info">
              {{ paginationMeta({ page, itemsPerPage }, totalItems) }}
            </div>
            <VPagination
              v-model="page"
              :length="Math.ceil(totalItems / itemsPerPage)"
              :total-visible="5"
              density="comfortable"
            />
          </div>
        </template>
      </VDataTable>
    </VCard>

    <!-- 新增用户对话框 -->
    <VDialog
      v-model="isAddDialogOpen"
      max-width="500"
    >
      <VCard>
        <VCardTitle>用户资料</VCardTitle>
        <VCardText>
          <VTextField
            v-model="currentAccount.username"
            label="账号"
            variant="outlined"
            class="mb-4"
            required
          />
          <VTextField
            v-model="currentAccount.password"
            label="密码"
            type="password"
            variant="outlined"
            class="mb-4"
            required
          />
          <VSelect
            v-model="currentAccount.role"
            :items="roleOptions"
            label="选择角色"
            variant="outlined"
            class="mb-4"
          />
          <VTextField
            v-model="currentAccount.nickname"
            label="昵称 (分流/操作时 访问控制显示的名字)"
            variant="outlined"
            class="mb-4"
          />
          <VSelect
            v-model="currentAccount.status"
            :items="[{ title: '启用', value: 'active' }, { title: '禁用', value: 'inactive' }]"
            label="用户状态"
            variant="outlined"
            class="mb-4"
          />
          <VTextarea
            v-model="currentAccount.remark"
            label="备注"
            variant="outlined"
            rows="2"
          />
        </VCardText>
        <VCardActions>
          <VSpacer />
          <VBtn
            variant="outlined"
            @click="isAddDialogOpen = false"
          >
            取消
          </VBtn>
          <VBtn
            color="primary"
            @click="saveAccount"
          >
            确认
          </VBtn>
        </VCardActions>
      </VCard>
    </VDialog>

    <!-- 编辑账号对话框 -->
    <VDialog
      v-model="isEditDialogOpen"
      max-width="500"
    >
      <VCard>
        <VCardTitle>用户资料</VCardTitle>
        <VCardText>
          <VTextField
            v-model="currentAccount.username"
            label="账号"
            variant="outlined"
            class="mb-4"
            disabled
          />
          <VTextField
            v-model="currentAccount.password"
            label="密码"
            type="password"
            variant="outlined"
            class="mb-4"
          />
          <VSelect
            v-model="currentAccount.role"
            :items="roleOptions"
            label="选择角色"
            variant="outlined"
            class="mb-4"
          />
          <VTextField
            v-model="currentAccount.nickname"
            label="昵称 (分流/操作时 访问控制显示的名字)"
            variant="outlined"
            class="mb-4"
          />
          <VSelect
            v-model="currentAccount.status"
            :items="[{ title: '启用', value: 'active' }, { title: '禁用', value: 'inactive' }]"
            label="用户状态"
            variant="outlined"
            class="mb-4"
          />
          <VTextarea
            v-model="currentAccount.remark"
            label="备注"
            variant="outlined"
            rows="2"
          />
        </VCardText>
        <VCardActions>
          <VSpacer />
          <VBtn
            variant="outlined"
            @click="isEditDialogOpen = false"
          >
            取消
          </VBtn>
          <VBtn
            color="primary"
            @click="saveAccount"
          >
            确认
          </VBtn>
        </VCardActions>
      </VCard>
    </VDialog>
  </div>
</template>

<style lang="scss" scoped>
.info-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .info-content {
    padding: 1rem 1.5rem;

    .info-text {
      font-size: 0.875rem;
      line-height: 1.75;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));

      p {
        margin: 0;
      }
    }
  }
}

.filter-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .filter-content {
    padding: 1.5rem;

    .filter-row {
      .filter-col {
        margin-block-end: 0.75rem;
      }

      .filter-input {
        :deep(.v-field) {
          font-size: 0.875rem;
        }

        :deep(.v-label) {
          font-size: 0.875rem;
        }
      }

      .filter-actions {
        margin-block-start: 0.5rem;
        padding-block-start: 0.5rem;

        .filter-btn {
          font-size: 0.875rem;
          font-weight: 500;
          padding-inline: 1.25rem;
          padding-block: 0.625rem;
          border-radius: 0.375rem;
          min-width: 100px;
          transition: all 0.2s ease-in-out;

          &:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
          }
        }
      }
    }
  }
}

.action-bar-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .action-bar-content {
    padding: 1rem 1.5rem;

    .action-btn {
      font-size: 0.875rem;
      font-weight: 500;
      padding-inline: 1rem;
      padding-block: 0.625rem;
      border-radius: 0.375rem;
      min-width: auto;
      transition: all 0.2s ease-in-out;

      &:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
      }
    }

    .action-right {
      .action-label {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }

      .items-per-page-select {
        width: 90px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }
      }
    }
  }
}

.accounts-table-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;

  .accounts-table {
    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 1rem;
          padding-inline: 1rem;
        }
      }
    }

    .role-chip {
      font-size: 0.8125rem;
      font-weight: 500;
    }

    .status-text {
      font-size: 0.875rem;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
    }

    .action-buttons {
      .action-icon-btn {
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        transition: color 0.2s ease-in-out;

        &:hover {
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
        }
      }
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem 1.5rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .pagination-info {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }
    }
  }
}
</style>
