<script setup lang="ts">
import { paginationMeta } from '@/utils/paginationMeta'
import { getRoleList, createRole, updateRole, deleteRole, assignPermissions, getRoleDetail } from '@/api/roles'
import type { Role } from '@/api/roles'

interface RoleItem {
  id: string | number
  name: string
  permissions?: string[]
  createTime: string
  updateTime: string
}

const roles = ref<RoleItem[]>([])
const selectedRoles = ref<string[]>([])
const isAddDialogOpen = ref(false)
const isEditDialogOpen = ref(false)
const currentRole = ref<Partial<RoleItem>>({})
const currentRolePermissions = ref<string[]>([])
const itemsPerPage = ref(10)
const page = ref(1)
const totalItems = ref(0)
const loading = ref(false)

// 转换后端数据格式到前端格式
const transformRole = (role: Role): RoleItem => {
  return {
    id: role.id,
    name: role.name,
    permissions: role.permissions?.map(String) || [],
    createTime: role.created_at || '',
    updateTime: role.created_at || '',
  }
}

// 加载角色列表
const loadRoles = async () => {
  try {
    loading.value = true
    const response = await getRoleList()
    
    if (response && response.data && response.data.list) {
      roles.value = response.data.list.map(transformRole)
      totalItems.value = response.data.total || 0
    }
  } catch (error) {
    console.error('加载角色列表失败:', error)
  } finally {
    loading.value = false
  }
}

// 页面加载时获取数据
onMounted(() => {
  loadRoles()
})

const headers = [
  { title: '角色', key: 'name' },
  { title: '创建时间', key: 'createTime' },
  { title: '更新时间', key: 'updateTime' },
  { title: '操作', key: 'actions', sortable: false },
]

// 权限列表（与参考系统一致）
const permissions = [
  { id: 'dashboard', name: '仪表板', isFunction: false },
  { id: 'access-control', name: '访问控制', isFunction: false },
  { id: 'frontend-domain', name: '前台域名/前台名称', isFunction: true },
  { id: 'product-name', name: '商品名称', isFunction: true },
  { id: 'product-price', name: '商品价格', isFunction: true },
  { id: 'sync-control', name: '同步控制', isFunction: true },
  { id: 'online-jump', name: '在线跳转', isFunction: true },
  { id: 'disconnect', name: '断开', isFunction: true },
  { id: 'blacklist', name: '拉黑', isFunction: true },
  { id: 'data-center', name: '数据中心', isFunction: false },
  { id: 'order-statistics', name: '订单统计', isFunction: false },
  { id: 'account-role', name: '账号 & 角色', isFunction: false },
  { id: 'monitor', name: '监控管理', isFunction: false },
  { id: 'frontend-config', name: '前台配置', isFunction: false },
  { id: 'activation-version', name: '激活 & 版本', isFunction: false },
  { id: 'system-config', name: '系统配置', isFunction: false },
]

const openAddDialog = () => {
  currentRole.value = {
    name: '',
  }
  currentRolePermissions.value = []
  isAddDialogOpen.value = true
}

const openEditDialog = (role: Role) => {
  currentRole.value = { ...role }
  currentRolePermissions.value = role.permissions ? [...role.permissions] : []
  isEditDialogOpen.value = true
}

const saveRole = async () => {
  try {
    loading.value = true
    if (isAddDialogOpen.value) {
      // 创建角色
      const response = await createRole({
        name: currentRole.value.name || '',
        permissions: currentRolePermissions.value.map(Number),
      })
      isAddDialogOpen.value = false
      await loadRoles()
    }
    else {
      // 更新角色
      await updateRole(Number(currentRole.value.id), {
        name: currentRole.value.name || '',
      })
      // 分配权限
      if (currentRolePermissions.value.length > 0) {
        await assignPermissions(Number(currentRole.value.id), currentRolePermissions.value.map(Number))
      }
      isEditDialogOpen.value = false
      await loadRoles()
    }
  } catch (error) {
    console.error('保存角色失败:', error)
  } finally {
    loading.value = false
  }
  
  // 旧代码已删除

const handleDeleteRole = async (id: string | number) => {
  try {
    loading.value = true
    await deleteRole(Number(id))
    await loadRoles()
  } catch (error) {
    console.error('删除角色失败:', error)
  } finally {
    loading.value = false
  }
}

const togglePermission = (permissionId: string) => {
  const index = currentRolePermissions.value.indexOf(permissionId)
  if (index > -1)
    currentRolePermissions.value.splice(index, 1)
  else
    currentRolePermissions.value.push(permissionId)
}

const isPermissionChecked = (permissionId: string) => {
  return currentRolePermissions.value.includes(permissionId)
}
</script>

<template>
  <div>
    <!-- 提示信息 -->
    <VCard class="info-card mb-4">
      <VCardText class="info-content">
        <div class="info-text">
          <p class="mb-0">
            如需分流，请自己创建一个角色，然后再分配给对应要分流的账号。
          </p>
        </div>
      </VCardText>
    </VCard>

    <!-- 操作栏 -->
    <VCard class="action-bar-card mb-4">
      <VCardText class="action-bar-content">
        <div class="d-flex align-center justify-space-between flex-wrap gap-4">
          <div class="d-flex align-center gap-2 action-right">
            <span class="action-label">每页显示</span>
            <VSelect
              v-model="itemsPerPage"
              :items="[10, 20, 50, 100]"
              variant="outlined"
              density="compact"
              hide-details
              class="items-per-page-select"
            />
          </div>
          <VBtn
            color="primary"
            variant="elevated"
            size="default"
            class="action-btn"
            @click="openAddDialog"
          >
            <VIcon
              icon="ri-add-line"
              start
              size="20"
            />
            添加角色
          </VBtn>
        </div>
      </VCardText>
    </VCard>

    <!-- 角色列表 -->
    <VCard class="roles-table-card">
      <VDataTable
        v-model="selectedRoles"
        :headers="headers"
        :items="roles"
        :items-per-page="itemsPerPage"
        :page="page"
        show-select
        class="roles-table text-no-wrap"
      >
        <template #item.actions="{ item }">
          <div class="d-flex gap-2 action-buttons">
            <IconBtn
              v-if="item.name !== '超级管理员'"
              size="small"
              class="action-icon-btn"
              @click="openEditDialog(item)"
            >
              <VIcon
                icon="ri-edit-line"
                size="20"
              />
            </IconBtn>
            <IconBtn
              v-if="item.name !== '超级管理员'"
              size="small"
              color="error"
              class="action-icon-btn"
              @click="handleDeleteRole(item.id)"
            >
              <VIcon
                icon="ri-delete-bin-line"
                size="20"
              />
            </IconBtn>
          </div>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-user-settings-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无角色数据
            </p>
          </div>
        </template>
        <template #bottom>
          <div class="table-footer">
            <div class="pagination-info">
              {{ paginationMeta({ page, itemsPerPage }, totalItems) }}
            </div>
            <VPagination
              v-model="page"
              :length="Math.ceil(totalItems / itemsPerPage)"
              :total-visible="5"
              density="comfortable"
            />
          </div>
        </template>
      </VDataTable>
    </VCard>

    <!-- 添加角色对话框 -->
    <VDialog
      v-model="isAddDialogOpen"
      max-width="700"
    >
      <VCard>
        <VCardTitle>添加新角色</VCardTitle>
        <VCardText>
          <p class="mb-4 text-body-2">
            设置角色权限时：有 (功能) 提示的为菜单内的功能，否则为菜单，如果未勾选菜单，界面将不展示；
          </p>
          <VTextField
            v-model="currentRole.name"
            label="角色名称"
            placeholder="不要输入纯数字"
            variant="outlined"
            class="mb-4"
            required
          />
          <div class="permissions-section">
            <h6 class="text-h6 mb-3">
              角色权限 (点击箭头展开)
            </h6>
            <VList class="permissions-list">
              <VListItem
                v-for="permission in permissions"
                :key="permission.id"
                class="permission-item"
              >
                <VListItemTitle>
                  {{ permission.name }}{{ permission.isFunction ? ' (功能)' : '' }}
                </VListItemTitle>
                <template #append>
                  <VSwitch
                    :model-value="isPermissionChecked(permission.id)"
                    @update:model-value="togglePermission(permission.id)"
                  />
                </template>
              </VListItem>
            </VList>
          </div>
        </VCardText>
        <VCardActions>
          <VSpacer />
          <VBtn
            variant="outlined"
            @click="isAddDialogOpen = false"
          >
            取消
          </VBtn>
          <VBtn
            color="primary"
            @click="saveRole"
          >
            确认
          </VBtn>
        </VCardActions>
      </VCard>
    </VDialog>

    <!-- 编辑角色对话框 -->
    <VDialog
      v-model="isEditDialogOpen"
      max-width="700"
    >
      <VCard>
        <VCardTitle>编辑角色</VCardTitle>
        <VCardText>
          <p class="mb-4 text-body-2">
            设置角色权限时：有 (功能) 提示的为菜单内的功能，否则为菜单，如果未勾选菜单，界面将不展示；
          </p>
          <VTextField
            v-model="currentRole.name"
            label="角色名称"
            placeholder="不要输入纯数字"
            variant="outlined"
            class="mb-4"
            required
          />
          <div class="permissions-section">
            <h6 class="text-h6 mb-3">
              角色权限 (点击箭头展开)
            </h6>
            <VList class="permissions-list">
              <VListItem
                v-for="permission in permissions"
                :key="permission.id"
                class="permission-item"
              >
                <VListItemTitle>
                  {{ permission.name }}{{ permission.isFunction ? ' (功能)' : '' }}
                </VListItemTitle>
                <template #append>
                  <VSwitch
                    :model-value="isPermissionChecked(permission.id)"
                    @update:model-value="togglePermission(permission.id)"
                  />
                </template>
              </VListItem>
            </VList>
          </div>
        </VCardText>
        <VCardActions>
          <VSpacer />
          <VBtn
            variant="outlined"
            @click="isEditDialogOpen = false"
          >
            取消
          </VBtn>
          <VBtn
            color="primary"
            @click="saveRole"
          >
            确认
          </VBtn>
        </VCardActions>
      </VCard>
    </VDialog>
  </div>
</template>

<style lang="scss" scoped>
.info-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .info-content {
    padding: 1rem 1.5rem;

    .info-text {
      font-size: 0.875rem;
      line-height: 1.75;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));

      p {
        margin: 0;
      }
    }
  }
}

.action-bar-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .action-bar-content {
    padding: 1rem 1.5rem;

    .action-btn {
      font-size: 0.875rem;
      font-weight: 500;
      padding-inline: 1rem;
      padding-block: 0.625rem;
      border-radius: 0.375rem;
      min-width: auto;
      transition: all 0.2s ease-in-out;

      &:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
      }
    }

    .action-right {
      .action-label {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }

      .items-per-page-select {
        width: 90px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }
      }
    }
  }
}

.roles-table-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;

  .roles-table {
    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 1rem;
          padding-inline: 1rem;
        }
      }
    }

    .action-buttons {
      .action-icon-btn {
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        transition: color 0.2s ease-in-out;

        &:hover {
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
        }
      }
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem 1.5rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .pagination-info {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }
    }
  }
}

.permissions-section {
  .permissions-list {
    padding: 0;

    .permission-item {
      padding-block: 0.75rem;
      padding-inline: 1rem;
      border-radius: 0.375rem;
      margin-block-end: 0.5rem;
      background-color: rgba(var(--v-theme-surface), 1);
      border: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
      transition: all 0.2s ease-in-out;

      &:hover {
        background-color: rgba(var(--v-theme-surface-variant), 0.5);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
      }

      :deep(.v-list-item-title) {
        font-size: 0.875rem;
        font-weight: 500;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }
  }
}
</style>
