<script setup lang="ts">
import { onMounted } from 'vue'
import { getOrderStatistics } from '@/api/order'

interface OrderStatItem {
  domain: string
  todayVisits: number
  todayPayers: number
  todayPayments: number
  todayConversionRate: number
  totalVisits: number
  totalPayers: number
  totalPayments: number
  totalConversionRate: number
}

const domainInput = ref('')
const orderStats = ref<OrderStatItem[]>([])
const isLoading = ref(false)

const headers = [
  { title: '域名', key: 'domain' },
  { title: '今日访问', key: 'todayVisits' },
  { title: '付款人数', key: 'todayPayers' },
  { title: '付款笔数', key: 'todayPayments' },
  { title: '今日转化率', key: 'todayConversionRate' },
  { title: '总访问', key: 'totalVisits' },
  { title: '总付款人数', key: 'totalPayers' },
  { title: '总付款笔数', key: 'totalPayments' },
  { title: '总转化率', key: 'totalConversionRate' },
]

const search = async () => {
  const domains = domainInput.value.split('\n').filter(d => d.trim())
  if (domains.length === 0) {
    // 查询所有域名的统计数据
    await loadAllStats()
    return
  }

  isLoading.value = true
  try {
    const stats: OrderStatItem[] = []
    for (const domain of domains) {
      try {
        const response = await getOrderStatistics({ domain })
        if (response.data) {
          const data = response.data.data
          stats.push({
            domain,
            todayVisits: data.today_visit || 0,
            todayPayers: data.today_payment_users || 0,
            todayPayments: data.today_payment_times || 0,
            todayConversionRate: parseFloat(data.conversion_rate || '0'),
            totalVisits: (data.week_visit || 0) + (data.month_visit || 0),
            totalPayers: 0, // 需要后端提供
            totalPayments: 0, // 需要后端提供
            totalConversionRate: 0, // 需要后端提供
          })
        }
      } catch (error) {
        console.error(`查询域名 ${domain} 失败:`, error)
      }
    }
    orderStats.value = stats
  } catch (error) {
    console.error('查询失败:', error)
  } finally {
    isLoading.value = false
  }
}

const loadAllStats = async () => {
  isLoading.value = true
  try {
    const response = await getOrderStatistics()
    if (response.data) {
      const data = response.data.data
      // 根据后端返回的数据结构处理
      orderStats.value = []
    }
  } catch (error) {
    console.error('加载统计数据失败:', error)
  } finally {
    isLoading.value = false
  }
}

const reset = () => {
  domainInput.value = ''
  orderStats.value = []
}

const clearAll = () => {
  orderStats.value = []
}

onMounted(() => {
  loadAllStats()
})
</script>

<template>
  <div class="order-statistics-page">
    <!-- 查询区域 -->
    <VCard class="query-card mb-4">
      <VCardText class="query-content">
        <VRow class="query-row">
          <VCol
            cols="12"
            class="query-col"
          >
            <VTextarea
              v-model="domainInput"
              placeholder="如有多个域名，一行一个"
              variant="outlined"
              density="comfortable"
              rows="4"
              hide-details
              class="domain-textarea"
            />
          </VCol>
          <VCol
            cols="12"
            class="query-actions"
          >
            <div class="d-flex align-center gap-3 flex-wrap">
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                class="query-btn"
                @click="search"
              >
                <VIcon
                  icon="ri-search-line"
                  start
                  size="20"
                />
                查询
              </VBtn>
              <VBtn
                variant="outlined"
                size="default"
                class="query-btn"
                @click="reset"
              >
                重置
              </VBtn>
              <VSpacer />
              <VBtn
                color="error"
                variant="outlined"
                size="default"
                class="query-btn"
                @click="clearAll"
              >
                <VIcon
                  icon="ri-delete-bin-line"
                  start
                  size="20"
                />
                一键清空
              </VBtn>
            </div>
          </VCol>
        </VRow>
      </VCardText>
    </VCard>

    <!-- 统计表格 -->
    <VCard class="stats-table-card">
      <VDataTable
        :headers="headers"
        :items="orderStats"
        :loading="isLoading"
        class="stats-table text-no-wrap"
      >
        <template #item.todayConversionRate="{ item }">
          {{ item.todayConversionRate.toFixed(2) }}%
        </template>
        <template #item.totalConversionRate="{ item }">
          {{ item.totalConversionRate.toFixed(2) }}%
        </template>
        <template #item.todayConversionRate="{ item }">
          <span class="conversion-rate">{{ item.todayConversionRate }}%</span>
        </template>
        <template #item.totalConversionRate="{ item }">
          <span class="conversion-rate">{{ item.totalConversionRate }}%</span>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-bar-chart-box-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无统计数据
            </p>
          </div>
        </template>
      </VDataTable>
    </VCard>
  </div>
</template>

<style lang="scss" scoped>
.order-statistics-page {
  padding-block-end: 0;
}

.query-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .query-content {
    padding: 1rem 1.5rem;

    .query-row {
      .query-col {
        margin-block-end: 0.75rem;

        .domain-textarea {
          :deep(.v-field) {
            font-size: 0.875rem;
          }

          :deep(textarea::placeholder) {
            font-size: 0.875rem;
            color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
          }
        }
      }

      .query-actions {
        padding-block-start: 0.25rem;

        .query-btn {
          font-size: 0.875rem;
          font-weight: 500;
          padding-inline: 1.25rem;
          padding-block: 0.625rem;
          border-radius: 0.375rem;
          min-width: 100px;
          transition: all 0.2s ease-in-out;

          &:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
          }
        }
      }
    }
  }
}

.stats-table-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  min-height: calc(100vh - 400px);
  display: flex;
  flex-direction: column;

  .stats-table {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;

    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 1rem;
          padding-inline: 1rem;
        }
      }
    }

    .conversion-rate {
      font-weight: 500;
      color: rgba(var(--v-theme-primary), 1);
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }
  }
}
</style>
