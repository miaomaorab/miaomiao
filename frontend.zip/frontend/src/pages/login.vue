<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { VForm, VTextField, VBtn } from 'vuetify/components'
import { login } from '@/api/auth'
import { saveToken } from '@/utils/auth'

const router = useRouter()

const form = ref({
  account: '',
  password: '',
})

const isPasswordVisible = ref(false)
const isLoading = ref(false)
const errorMessage = ref('')

const handleLogin = async () => {
  if (!form.value.account || !form.value.password) {
    errorMessage.value = '请输入账号和密码'
    return
  }

  isLoading.value = true
  errorMessage.value = ''

  try {
    const response = await login({
      username: form.value.account,
      password: form.value.password,
    })

    // http.ts 的响应拦截器返回的是 data 对象，即 { code, message, data: { token, user } }
    // 所以应该访问 response.data.token
    if (response && response.data && response.data.token) {
      // 保存Token
      saveToken(response.data.token)
      
      // 跳转到首页
      router.push('/')
    } else {
      errorMessage.value = response?.message || '登录失败，请检查账号密码'
    }
  } catch (error: any) {
    console.error('登录错误:', error)
    const errorMsg = error?.message || '网络连接失败，请检查后端服务是否启动'
    errorMessage.value = errorMsg
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div class="auth-wrapper d-flex align-center justify-center pa-4">
    <div class="position-relative my-sm-16">
      <!-- 背景装饰 -->
      <div class="text-primary auth-v1-top-shape d-none d-sm-block">
        <svg width="239" height="234" viewBox="0 0 239 234" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="88.5605" y="0.700195" width="149" height="149" rx="19.5" stroke="currentColor" stroke-opacity="0.16"></rect>
          <rect x="0.621094" y="33.761" width="200" height="200" rx="10" fill="currentColor" fill-opacity="0.08"></rect>
        </svg>
      </div>
      <div class="text-primary auth-v1-bottom-shape d-none d-sm-block">
        <svg width="238" height="238" viewBox="0 0 181 181" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="1.30469" y="1.44312" width="178" height="178" rx="19" stroke="currentColor" stroke-opacity="0.16" stroke-width="2" stroke-dasharray="8 8"></rect>
          <rect x="22.8047" y="22.9431" width="135" height="135" rx="10" fill="currentColor" fill-opacity="0.08"></rect>
        </svg>
      </div>
      
      <!-- 登录卡片 -->
      <div class="v-card v-theme--dark v-card--density-default v-card--variant-elevated auth-card pa-4" style="width: 388px;">
        <!-- 标题 -->
        <div class="v-card-item justify-center">
          <div class="v-card-item__content">
            <div class="v-card-title font-weight-bold text-capitalize text-h4 py-1">Welcome Back! </div>
          </div>
        </div>
        
        <!-- 登录表单 -->
        <div class="v-card-text">
          <VForm @submit.prevent="handleLogin" novalidate="">
            <div class="v-row">
              <!-- 账号输入 -->
              <div class="v-col v-col-12">
                <div class="app-text-field flex-grow-1">
                  <label class="v-label mb-1 text-body-2 text-high-emphasis" for="app-text-field-Account">Account</label>
                  <VTextField
                    v-model="form.account"
                    id="app-text-field-Account"
                    variant="outlined"
                    density="compact"
                    hide-details
                    class="form-input"
                    autocomplete="username"
                    v-theme="dark"
                  />
                </div>
              </div>

              <!-- 密码输入 -->
              <div class="v-col v-col-12">
                <div class="app-text-field flex-grow-1">
                  <label class="v-label mb-1 text-body-2 text-high-emphasis" for="app-text-field-Password">Password</label>
                  <VTextField
                    v-model="form.password"
                    id="app-text-field-Password"
                    variant="outlined"
                    density="compact"
                    :type="isPasswordVisible ? 'text' : 'password'"
                    hide-details
                    class="form-input"
                    autocomplete="current-password"
                    :append-inner-icon="isPasswordVisible ? 'ri-eye-off-line' : 'ri-eye-line'"
                    @click:append-inner="isPasswordVisible = !isPasswordVisible"
                    v-theme="dark"
                  />
                </div>
              </div>

              <!-- 错误提示 -->
              <div v-if="errorMessage" class="v-col v-col-12 error-message">
                {{ errorMessage }}
              </div>

              <!-- 登录按钮 -->
              <div class="v-col v-col-12">
                <VBtn
                  block
                  type="submit"
                  color="primary"
                  size="default"
                  class="login-btn"
                  :loading="isLoading"
                  :disabled="isLoading"
                  variant="elevated"
                  v-theme="dark"
                >
                  Login
                </VBtn>
              </div>
            </div>
          </VForm>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.auth-wrapper {
  min-height: 100vh;
  background: linear-gradient(135deg, #1e1e2e 0%, #313244 100%);
  position: relative;
  overflow: hidden;
}

.auth-v1-top-shape {
  position: absolute;
  top: 0;
  right: 0;
  transform: translate(30%, -30%);
  z-index: 0;
}

.auth-v1-bottom-shape {
  position: absolute;
  bottom: 0;
  left: 0;
  transform: translate(-30%, 30%);
  z-index: 0;
}

.auth-card {
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
  position: relative;
  z-index: 1;
  background: rgba(30, 30, 46, 0.95);
}

.form-input {
  :deep(.v-field) {
    border-radius: 8px;
    margin-top: 8px;
    background: rgba(49, 50, 68, 0.5);
  }
  
  :deep(.v-field__outline) {
    color: rgba(255, 255, 255, 0.2);
  }
  
  :deep(.v-field__input) {
    color: rgba(255, 255, 255, 0.9);
  }
}

.error-message {
  padding: 12px;
  background: rgba(220, 38, 38, 0.1);
  color: #f87171;
  border-radius: 6px;
  font-size: 14px;
  margin-top: 16px;
  text-align: center;
}

.login-btn {
  margin-top: 16px;
  height: 48px;
  font-size: 16px;
  font-weight: 500;
  border-radius: 8px;
  text-transform: none;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
  
  &:hover {
    box-shadow: 0 6px 16px rgba(102, 126, 234, 0.6);
  }
}
</style>
