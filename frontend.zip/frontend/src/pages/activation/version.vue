<script setup lang="ts">
interface UpdateRecord {
  version: string
  date: string
  description: string
  details: string[]
}

const updateRecords = ref<UpdateRecord[]>([
  {
    version: 'v3.0.9',
    date: '2025-11-24 20:35',
    description: '更新后台界面',
    details: [
      '如果你v3.0.2没重装，需要重装',
      '1. 更新后台界面',
    ],
  },
  {
    version: 'v3.0.8',
    date: '2025-11-24 17:35',
    description: '修复已知Bug',
    details: [
      '如果你v3.0.2没重装，需要重装',
      '1. 数据中心新增订单备注',
      '2. 访问控制界面拒绝样式调整和卡头备注显示C/D卡',
      '3. 记录访问后台被拉黑的问题',
    ],
  },
  {
    version: 'v3.0.7',
    date: '2025-11-23 1:45',
    description: '修复已知Bug',
    details: [
      '如果你v3.0.2没重装，需要重装',
      '1. 修复一键清空数据的Bug',
      '2. 修复域名状态检查的Bug',
      '3. 修复访问后台地址被拉黑的Bug',
    ],
  },
  {
    version: 'v3.0.6',
    date: '2025-11-22 22:44',
    description: '修复一键清空数据的Bug，v3.0.2以下需重装',
    details: [
      '如果你v3.0.2没重装，需要重装',
      '1. 修复一键清空数据的Bug，v3.0.2以下需重装',
    ],
  },
  {
    version: 'v3.0.5',
    date: '2025-11-22 20:08',
    description: '修复一键清空数据的Bug，v3.0.2以下需重装',
    details: [
      '如果你v3.0.2没重装，需要重装',
      '1. 修复重大前几个版本重大Bug，为了不影响使用，请及时更新',
    ],
  },
  {
    version: 'v3.0.4',
    date: '2025-11-22 16:00',
    description: '修复重大Bug，v3.0.2以下需重装',
    details: [
      '1. 修复重大前几个版本重大Bug，为了不影响使用，请及时更新',
    ],
  },
  {
    version: 'v3.0.3',
    date: '2025-11-22 2:11',
    description: '修复已知Bug，v3.0.2以下需重装',
    details: [
      '1. 修复已知Bug，为了不影响使用，请及时更新',
    ],
  },
  {
    version: 'v3.0.2',
    date: '2025-11-21 3:38',
    description: '修复已知Bug，需重装',
    details: [
      '1. 修复已知Bug，为了不影响使用，请及时更新',
    ],
  },
  {
    version: 'v3.0.01',
    date: '2025-11-20 23:38',
    description: '修复已知Bug',
    details: [
      '1. 修复已知Bug，为了不影响使用，请及时更新',
    ],
  },
])
</script>

<template>
  <div>
    <VCard class="update-records-card">
      <VCardItem class="card-header">
        <VCardTitle class="card-title">
          后台更新记录
        </VCardTitle>
      </VCardItem>
      <VCardText class="card-content">
        <div class="update-records-list">
          <div
            v-for="(record, index) in updateRecords"
            :key="index"
            class="update-record-item"
          >
            <div class="record-header">
              <span class="record-version">{{ record.version }}</span>
              <span class="record-date">{{ record.date }}</span>
            </div>
            <p class="record-description">
              {{ record.description }}
            </p>
            <VDivider class="record-divider" />
            <div class="record-details">
              <div
                v-for="(detail, detailIndex) in record.details"
                :key="detailIndex"
                class="detail-item"
              >
                {{ detail }}
              </div>
            </div>
          </div>
        </div>
      </VCardText>
    </VCard>
  </div>
</template>

<style lang="scss" scoped>
.update-records-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .card-header {
    padding: 1.25rem 1.25rem 0.75rem;

    .card-title {
      font-size: 1.125rem;
      font-weight: 500;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
    }
  }

  .card-content {
    padding: 1rem 1.25rem;

    .update-records-list {
      .update-record-item {
        padding-block: 1rem;
        border-block-end: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

        &:last-child {
          border-block-end: none;
        }

        .record-header {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-block-end: 0.5rem;

          .record-version {
            font-size: 0.875rem;
            font-weight: 500;
            color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          }

          .record-date {
            font-size: 0.875rem;
            color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
          }
        }

        .record-description {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          margin-block-end: 0.5rem;
        }

        .record-divider {
          margin-block: 0.75rem;
        }

        .record-details {
          .detail-item {
            font-size: 0.875rem;
            color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
            margin-block-end: 0.25rem;

            &:last-child {
              margin-block-end: 0;
            }
          }
        }
      }
    }
  }
}
</style>
