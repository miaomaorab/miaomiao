<script setup lang="ts">
import { onMounted } from 'vue'
import { paginationMeta } from '@/utils/paginationMeta'
import { getDataList, deleteData, exportData as exportDataApi, addNote } from '@/api/data-center'
import type { DataCenterItem } from '@/api/data-center'

interface DataItem {
  id: number
  domain: string
  front_desk: string
  card_number: string
  card_type: string
  name: string
  country: string
  ip: string
  status: number
  remarks: string
  created_at: string
  updated_at: string
}

const filterForm = ref({
  cardFilter: '全部',
  domain: '',
  frontend: '',
  cardNumber: '',
  createTimeStart: '',
  createTimeEnd: '',
  updateTimeStart: '',
  updateTimeEnd: '',
})

const createTimeMenu = ref(false)
const updateTimeMenu = ref(false)
const createTimeRange = ref<string[]>([])
const updateTimeRange = ref<string[]>([])

const itemsPerPage = ref(10)
const page = ref(1)
const totalItems = ref(0)
const dataList = ref<DataItem[]>([])
const selectedItems = ref<number[]>([])
const searchId = ref('')
const isLoading = ref(false)

const headers = [
  { title: '域名', key: 'domain' },
  { title: '前台', key: 'front_desk' },
  { title: '卡号', key: 'card_number' },
  { title: '卡类型', key: 'card_type' },
  { title: '姓名', key: 'name' },
  { title: '国家', key: 'country' },
  { title: 'IP', key: 'ip' },
  { title: '状态', key: 'status' },
  { title: '创建时间', key: 'created_at' },
  { title: '操作', key: 'actions', sortable: false },
]

// 加载数据
const loadData = async () => {
  isLoading.value = true
  try {
    const filters: any = {}
    
    if (filterForm.value.domain) {
      filters.domain = filterForm.value.domain
    }
    if (filterForm.value.frontend) {
      filters.front_desk = filterForm.value.frontend
    }
    if (filterForm.value.cardNumber) {
      filters.card_number = filterForm.value.cardNumber
    }
    if (filterForm.value.createTimeStart) {
      filters.created_at_start = filterForm.value.createTimeStart
    }
    if (filterForm.value.createTimeEnd) {
      filters.created_at_end = filterForm.value.createTimeEnd
    }
    if (filterForm.value.cardFilter === '已填卡') {
      filters.status = 1
    } else if (filterForm.value.cardFilter === '未填卡') {
      filters.status = 0
    }

    const response = await getDataList({
      page: page.value,
      limit: itemsPerPage.value,
      filters,
    })

    if (response && response.data) {
      dataList.value = response.data.list || []
      totalItems.value = response.data.total || 0
    }
  } catch (error) {
    console.error('加载数据失败:', error)
  } finally {
    isLoading.value = false
  }
}

const search = () => {
  page.value = 1
  loadData()
}

const reset = () => {
  filterForm.value = {
    cardFilter: '全部',
    domain: '',
    frontend: '',
    cardNumber: '',
    createTimeStart: '',
    createTimeEnd: '',
    updateTimeStart: '',
    updateTimeEnd: '',
  }
  createTimeRange.value = []
  updateTimeRange.value = []
  page.value = 1
  loadData()
}

const exportData = async () => {
  try {
    const params: any = {}
    if (filterForm.value.createTimeStart) {
      params.start_date = filterForm.value.createTimeStart
    }
    if (filterForm.value.createTimeEnd) {
      params.end_date = filterForm.value.createTimeEnd
    }
    if (filterForm.value.domain) {
      params.domain = filterForm.value.domain
    }

    const response = await exportDataApi(params)
    
    // 创建下载链接
    const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `数据导出_${new Date().toISOString().split('T')[0]}.xlsx`
    link.click()
    window.URL.revokeObjectURL(url)
  } catch (error) {
    console.error('导出失败:', error)
  }
}

const clearAll = async () => {
  if (selectedItems.value.length === 0) {
    return
  }
  
  if (!confirm('确定要删除选中的数据吗？')) {
    return
  }

  try {
    await Promise.all(selectedItems.value.map(id => deleteData(id)))
    selectedItems.value = []
    await loadData()
  } catch (error) {
    console.error('删除失败:', error)
  }
}

const handleDelete = async (id: number) => {
  if (!confirm('确定要删除这条数据吗？')) {
    return
  }

  try {
    await deleteData(id)
    await loadData()
  } catch (error) {
    console.error('删除失败:', error)
  }
}

onMounted(() => {
  loadData()
})
</script>

<template>
  <div class="data-center-page">
    <!-- 筛选区域 -->
    <VCard class="filter-card mb-4">
      <VCardText class="filter-content">
        <VRow class="filter-row">
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VSelect
              v-model="filterForm.cardFilter"
              :items="['全部', '已填卡', '未填卡']"
              label="填卡筛选"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.domain"
              label="域名"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.frontend"
              label="前台"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.cardNumber"
              label="卡号"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="6"
            class="filter-col"
          >
            <VMenu
              v-model="createTimeMenu"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template #activator="{ props }">
                <VTextField
                  v-bind="props"
                  :model-value="createTimeRange.length > 0 ? `${createTimeRange[0]} ~ ${createTimeRange[1] || createTimeRange[0]}` : ''"
                  label="创建时间"
                  placeholder="选择日期范围"
                  variant="outlined"
                  density="compact"
                  readonly
                  hide-details
                  class="filter-input"
                  clearable
                  @click:clear="createTimeRange = []"
                />
              </template>
              <VDatePicker
                v-model="createTimeRange"
                range
                @update:model-value="(val) => {
                  if (val && Array.isArray(val) && val.length === 2) {
                    filterForm.createTimeStart = val[0]
                    filterForm.createTimeEnd = val[1]
                  }
                }"
              />
            </VMenu>
          </VCol>
          <VCol
            cols="12"
            md="6"
            class="filter-col"
          >
            <VMenu
              v-model="updateTimeMenu"
              :close-on-content-click="false"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template #activator="{ props }">
                <VTextField
                  v-bind="props"
                  :model-value="updateTimeRange.length > 0 ? `${updateTimeRange[0]} ~ ${updateTimeRange[1] || updateTimeRange[0]}` : ''"
                  label="更新时间"
                  placeholder="选择日期范围"
                  variant="outlined"
                  density="compact"
                  readonly
                  hide-details
                  class="filter-input"
                  clearable
                  @click:clear="updateTimeRange = []"
                />
              </template>
              <VDatePicker
                v-model="updateTimeRange"
                range
                @update:model-value="(val) => {
                  if (val && Array.isArray(val) && val.length === 2) {
                    filterForm.updateTimeStart = val[0]
                    filterForm.updateTimeEnd = val[1]
                  }
                }"
              />
            </VMenu>
          </VCol>
          <VCol
            cols="12"
            class="filter-actions"
          >
            <div class="d-flex gap-3">
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                class="filter-btn"
                @click="search"
              >
                <VIcon
                  icon="ri-search-line"
                  start
                  size="20"
                />
                查询
              </VBtn>
              <VBtn
                variant="outlined"
                size="default"
                class="filter-btn"
                @click="reset"
              >
                重置
              </VBtn>
            </div>
          </VCol>
        </VRow>
      </VCardText>
    </VCard>

    <!-- 数据表格（包含操作栏） -->
    <VCard class="data-table-card">
      <VDataTable
        v-model="selectedItems"
        :headers="headers"
        :items="dataList"
        :items-per-page="itemsPerPage"
        :page="page"
        show-select
        class="data-table text-no-wrap"
      >
        <template #top>
          <div class="action-bar-content">
            <div class="d-flex align-center justify-space-between flex-wrap gap-4">
              <div class="d-flex align-center gap-3 action-left">
                <span class="action-label">每页显示</span>
                <VSelect
                  v-model="itemsPerPage"
                  :items="[10, 20, 50, 100]"
                  variant="outlined"
                  density="compact"
                  hide-details
                  class="items-per-page-select"
                />
              </div>
              <div class="d-flex align-center gap-3 action-right">
                <VTextField
                  v-model="searchId"
                  placeholder="输入编号"
                  variant="outlined"
                  density="compact"
                  hide-details
                  class="search-id-input"
                />
                <VBtn
                  variant="outlined"
                  size="default"
                  class="action-btn"
                  @click="exportData"
                >
                  <VIcon
                    icon="ri-download-line"
                    start
                    size="20"
                  />
                  导出查询结果
                </VBtn>
                <VBtn
                  color="error"
                  variant="outlined"
                  size="default"
                  class="action-btn"
                  @click="clearAll"
                >
                  <VIcon
                    icon="ri-delete-bin-line"
                    start
                    size="20"
                  />
                  一键清空
                </VBtn>
              </div>
            </div>
          </div>
        </template>
        <template #item.actions="{ item }">
          <VBtn
            size="small"
            variant="text"
            color="error"
            @click="handleDelete(item.id)"
          >
            删除
          </VBtn>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-database-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无数据
            </p>
          </div>
        </template>
        <template #bottom>
          <div class="table-footer">
            <div class="pagination-info">
              {{ paginationMeta({ page, itemsPerPage }, totalItems) }}
            </div>
            <VPagination
              v-model="page"
              :length="Math.ceil(totalItems / itemsPerPage)"
              :total-visible="5"
              density="comfortable"
            />
          </div>
        </template>
      </VDataTable>
    </VCard>
  </div>
</template>

<style lang="scss" scoped>
.data-center-page {
  padding-block-end: 0;
}

.filter-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .filter-content {
    padding: 0.75rem 1.5rem;

    .filter-row {
      .filter-col {
        margin-block-end: 0.375rem;
      }

      .filter-input {
        :deep(.v-field) {
          font-size: 0.875rem;
        }

        :deep(.v-label) {
          font-size: 0.875rem;
        }
      }

      .filter-actions {
        margin-block-start: 0.125rem;
        padding-block-start: 0.125rem;

        .filter-btn {
          font-size: 0.875rem;
          font-weight: 500;
          padding-inline: 1.25rem;
          padding-block: 0.625rem;
          border-radius: 0.375rem;
          min-width: 100px;
          transition: all 0.2s ease-in-out;

          &:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
          }
        }
      }
    }
  }
}

.data-table-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  min-height: calc(100vh - 400px);
  display: flex;
  flex-direction: column;

  .action-bar-content {
    padding: 0.75rem 1.5rem 0.5rem;
    border-block-end: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

    .action-left {
      .action-label {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }

      .items-per-page-select {
        width: 90px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }
      }
    }

    .action-right {
      .search-id-input {
        width: 160px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }

        :deep(input::placeholder) {
          font-size: 0.875rem;
        }
      }

      .action-btn {
        font-size: 0.875rem;
        font-weight: 500;
        padding-inline: 1rem;
        padding-block: 0.625rem;
        border-radius: 0.375rem;
        min-width: auto;
        transition: all 0.2s ease-in-out;

        &:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
        }
      }
    }
  }

  .data-table {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;

    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }

      .v-data-table__tr {
        .v-data-table-header__th {
          padding-block: 0.5rem;
        }
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 0.75rem;
          padding-inline: 1rem;
        }
      }
    }

    .action-icon-btn {
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      transition: color 0.2s ease-in-out;

      &:hover {
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.5rem 1.5rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .pagination-info {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }
    }
  }
}
</style>
