<script setup lang="ts">
const form = ref({
  currentPassword: '',
  newPassword: '',
  confirmPassword: '',
})

const isCurrentPasswordVisible = ref(false)
const isNewPasswordVisible = ref(false)
const isConfirmPasswordVisible = ref(false)
const isSubmitting = ref(false)

const rules = {
  currentPassword: [
    (v: string) => !!v || '请输入当前密码',
  ],
  newPassword: [
    (v: string) => !!v || '请输入新密码',
    (v: string) => (v && v.length >= 6) || '密码长度至少6位',
  ],
  confirmPassword: [
    (v: string) => !!v || '请确认新密码',
    (v: string) => v === form.value.newPassword || '两次输入的密码不一致',
  ],
}

const handleSubmit = async () => {
  isSubmitting.value = true
  try {
    // TODO: 调用API修改密码
    await new Promise(resolve => setTimeout(resolve, 1000))

    // 成功后跳转或显示成功消息
    console.log('密码修改成功')
  }
  catch (error) {
    console.error('密码修改失败', error)
  }
  finally {
    isSubmitting.value = false
  }
}
</script>

<template>
  <div>
    <VCard>
      <VCardTitle class="text-h5 mb-4">
        修改密码
      </VCardTitle>
      <VCardText>
        <VForm @submit.prevent="handleSubmit">
          <VRow>
            <!-- 当前密码 -->
            <VCol cols="12">
              <VTextField
                v-model="form.currentPassword"
                :rules="rules.currentPassword"
                label="当前密码"
                placeholder="请输入当前密码"
                variant="outlined"
                density="default"
                :type="isCurrentPasswordVisible ? 'text' : 'password'"
                :append-inner-icon="isCurrentPasswordVisible ? 'ri-eye-off-line' : 'ri-eye-line'"
                @click:append-inner="isCurrentPasswordVisible = !isCurrentPasswordVisible"
              />
            </VCol>

            <!-- 新密码 -->
            <VCol cols="12">
              <VTextField
                v-model="form.newPassword"
                :rules="rules.newPassword"
                label="新密码"
                placeholder="请输入新密码（至少6位）"
                variant="outlined"
                density="default"
                :type="isNewPasswordVisible ? 'text' : 'password'"
                :append-inner-icon="isNewPasswordVisible ? 'ri-eye-off-line' : 'ri-eye-line'"
                @click:append-inner="isNewPasswordVisible = !isNewPasswordVisible"
              />
            </VCol>

            <!-- 确认新密码 -->
            <VCol cols="12">
              <VTextField
                v-model="form.confirmPassword"
                :rules="rules.confirmPassword"
                label="确认新密码"
                placeholder="请再次输入新密码"
                variant="outlined"
                density="default"
                :type="isConfirmPasswordVisible ? 'text' : 'password'"
                :append-inner-icon="isConfirmPasswordVisible ? 'ri-eye-off-line' : 'ri-eye-line'"
                @click:append-inner="isConfirmPasswordVisible = !isConfirmPasswordVisible"
              />
            </VCol>

            <!-- 提交按钮 -->
            <VCol cols="12">
              <div class="d-flex gap-3 justify-end">
                <VBtn
                  variant="outlined"
                  @click="$router.back()"
                >
                  取消
                </VBtn>
                <VBtn
                  type="submit"
                  color="primary"
                  :loading="isSubmitting"
                >
                  保存
                </VBtn>
              </div>
            </VCol>
          </VRow>
        </VForm>
      </VCardText>
    </VCard>
  </div>
</template>

<style lang="scss" scoped>
:deep(.v-card) {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}
</style>
