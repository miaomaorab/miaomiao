<script setup lang="ts">
import VueApexCharts from 'vue3-apexcharts'
import { useTheme } from 'vuetify'
import { hexToRgb } from '@layouts/utils'

const vuetifyTheme = useTheme()

const cpuCores = ref(2)
const cpuUsage = ref(55.78)
const networkSpeed = ref(125.5)
const networkUnit = ref('KB/s')
const memoryTotal = ref(3913)
const memoryUsed = ref(1064)
const memoryAvailable = ref(2672)
const memoryBuffer = ref(56)
const memoryCache = ref(757)
const diskTotal = ref(500)
const diskUsed = ref(250)
const diskAvailable = ref(250)

const memoryUsagePercent = computed(() => Math.round((memoryUsed.value / memoryTotal.value) * 100))
const diskUsagePercent = computed(() => Math.round((diskUsed.value / diskTotal.value) * 100))

// Helper function to get RGB string from color (currently unused, reserved for future use)
// const getRgbString = (color: string | undefined): string => {
//   if (!color)
//     return '0, 0, 0'
//   const colorStr = String(color)
//   if (colorStr.includes(','))
//     return colorStr.replace(/^rgb\(|\)$/g, '').trim()
//   const rgb = hexToRgb(colorStr)
//   return rgb || '0, 0, 0'
// }

const cpuChartOptions = computed(() => {
  const currentTheme = vuetifyTheme.current.value.colors

  return {
    chart: {
      type: 'area',
      sparkline: { enabled: true },
      fontFamily: 'inherit',
    },
    stroke: {
      curve: 'smooth',
      width: 2.5,
    },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.7,
        opacityTo: 0.3,
        stops: [0, 90, 100],
      },
    },
    colors: [currentTheme.primary],
    tooltip: {
      theme: vuetifyTheme.current.value.dark ? 'dark' : 'light',
    },
  }
})

const memoryChartOptions = computed(() => {
  const currentTheme = vuetifyTheme.current.value.colors

  return {
    chart: {
      type: 'area',
      sparkline: { enabled: true },
      fontFamily: 'inherit',
    },
    stroke: {
      curve: 'smooth',
      width: 2.5,
    },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.7,
        opacityTo: 0.3,
        stops: [0, 90, 100],
      },
    },
    colors: [currentTheme.success],
    tooltip: {
      theme: vuetifyTheme.current.value.dark ? 'dark' : 'light',
    },
  }
})

const diskChartOptions = computed(() => {
  const currentTheme = vuetifyTheme.current.value.colors

  return {
    chart: {
      type: 'area',
      sparkline: { enabled: true },
      fontFamily: 'inherit',
    },
    stroke: {
      curve: 'smooth',
      width: 2.5,
    },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.7,
        opacityTo: 0.3,
        stops: [0, 90, 100],
      },
    },
    colors: [currentTheme.info],
    tooltip: {
      theme: vuetifyTheme.current.value.dark ? 'dark' : 'light',
    },
  }
})

const cpuSeries = ref([{
  name: 'CPU使用率',
  data: [45, 52, 48, 61, 55, 58, 56],
}])

const memorySeries = ref([{
  name: '内存使用率',
  data: [20, 25, 22, 28, 27, 26, 25],
}])

const diskSeries = ref([{
  name: '磁盘使用率',
  data: [40, 45, 42, 48, 47, 46, 45],
}])
</script>

<template>
  <VRow class="system-monitor-row">
    <!-- CPU监控 -->
    <VCol
      cols="12"
      md="6"
      class="monitor-col"
    >
      <VCard class="monitor-card">
        <VCardItem class="card-header">
          <VCardTitle class="card-title">
            CPU监控
          </VCardTitle>
        </VCardItem>
        <VCardText class="card-content">
          <div class="d-flex align-center justify-space-between mb-4">
            <div class="monitor-info">
              <h4 class="monitor-value">
                {{ cpuCores }} 核心
              </h4>
              <div class="monitor-label">
                当前使用率: {{ cpuUsage }}%
              </div>
            </div>
            <VueApexCharts
              type="area"
              height="100"
              width="200"
              :options="cpuChartOptions"
              :series="cpuSeries"
            />
          </div>
          <VProgressLinear
            :model-value="cpuUsage"
            color="primary"
            height="10"
            rounded
            class="monitor-progress"
          />
        </VCardText>
      </VCard>
    </VCol>

    <!-- 内存监控 -->
    <VCol
      cols="12"
      md="6"
      class="monitor-col"
    >
      <VCard class="monitor-card">
        <VCardItem class="card-header">
          <VCardTitle class="card-title">
            内存监控
          </VCardTitle>
        </VCardItem>
        <VCardText class="card-content">
          <div class="d-flex align-center justify-space-between mb-4">
            <div class="monitor-info">
              <h4 class="monitor-value">
                {{ memoryTotal }} MB
              </h4>
              <div class="monitor-label">
                已使用: {{ memoryUsed }} MB ({{ memoryUsagePercent }}%)
              </div>
            </div>
            <VueApexCharts
              type="area"
              height="100"
              width="200"
              :options="memoryChartOptions"
              :series="memorySeries"
            />
          </div>
          <VProgressLinear
            :model-value="memoryUsagePercent"
            color="success"
            height="10"
            rounded
            class="monitor-progress mb-3"
          />
          <div class="monitor-details">
            <div class="detail-item">
              可用: <span class="detail-value">{{ memoryAvailable }} MB</span>
            </div>
            <div class="detail-item">
              缓冲: <span class="detail-value">{{ memoryBuffer }} MB</span>
            </div>
            <div class="detail-item">
              缓存: <span class="detail-value">{{ memoryCache }} MB</span>
            </div>
          </div>
        </VCardText>
      </VCard>
    </VCol>

    <!-- 磁盘监控 -->
    <VCol
      cols="12"
      md="6"
      class="monitor-col"
    >
      <VCard class="monitor-card">
        <VCardItem class="card-header">
          <VCardTitle class="card-title">
            磁盘监控
          </VCardTitle>
        </VCardItem>
        <VCardText class="card-content">
          <div class="d-flex align-center justify-space-between mb-4">
            <div class="monitor-info">
              <h4 class="monitor-value">
                {{ diskTotal }} GB
              </h4>
              <div class="monitor-label">
                已使用: {{ diskUsed }} GB ({{ diskUsagePercent }}%)
              </div>
            </div>
            <VueApexCharts
              type="area"
              height="100"
              width="200"
              :options="diskChartOptions"
              :series="diskSeries"
            />
          </div>
          <VProgressLinear
            :model-value="diskUsagePercent"
            color="info"
            height="10"
            rounded
            class="monitor-progress mb-3"
          />
          <div class="monitor-details">
            <div class="detail-item">
              可用: <span class="detail-value">{{ diskAvailable }} GB</span>
            </div>
          </div>
        </VCardText>
      </VCard>
    </VCol>

    <!-- 网络监控 -->
    <VCol
      cols="12"
      md="6"
      class="monitor-col"
    >
      <VCard class="monitor-card">
        <VCardItem class="card-header">
          <VCardTitle class="card-title">
            网络监控
          </VCardTitle>
        </VCardItem>
        <VCardText class="card-content">
          <div class="d-flex align-center justify-space-between">
            <div class="monitor-info">
              <h4 class="monitor-value">
                流量
              </h4>
              <div class="monitor-label">
                {{ networkSpeed }} {{ networkUnit }}
              </div>
            </div>
            <VIcon
              icon="ri-wifi-line"
              size="64"
              color="primary"
              class="monitor-icon"
            />
          </div>
        </VCardText>
      </VCard>
    </VCol>
  </VRow>
</template>

<style lang="scss" scoped>
.system-monitor-row {
  .monitor-col {
    margin-block-end: 1.5rem;
  }

  .monitor-card {
    border-radius: 0.5rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    height: 100%;

    .card-header {
      padding: 1.5rem 1.5rem 0.75rem;

      .card-title {
        font-size: 1.125rem;
        font-weight: 500;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    .card-content {
      padding: 1.5rem;

      .monitor-info {
        flex: 1;
        min-width: 0;

        .monitor-value {
          font-size: 1.5rem;
          font-weight: 600;
          line-height: 2rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          margin-block-end: 0.5rem;
        }

        .monitor-label {
          font-size: 0.875rem;
          line-height: 1.25rem;
          color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        }
      }

      .monitor-progress {
        margin-block-start: 0.5rem;
      }

      .monitor-details {
        margin-block-start: 0.75rem;

        .detail-item {
          font-size: 0.875rem;
          line-height: 1.75rem;
          color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));

          .detail-value {
            font-weight: 500;
            color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
            margin-inline-start: 0.5rem;
          }
        }
      }

      .monitor-icon {
        opacity: 0.7;
      }
    }
  }
}
</style>
