<script setup lang="ts">
import { paginationMeta } from '@/utils/paginationMeta'

interface AccessRecord {
  id: string
  requestUrl: string
  browserPlatform: string
  browserInfo: string
  type: '成功' | '拦截'
  detail: string
  ip: string
  country: string
  createTime: string
}

const records = ref<AccessRecord[]>([])
const selectedRecords = ref<string[]>([])
const isViewDialogOpen = ref(false)
const currentRecord = ref<AccessRecord | null>(null)

const filterForm = ref({
  type: '全部',
  dateRange: '',
})

const itemsPerPage = ref(10)
const page = ref(1)
const totalItems = ref(0)

const headers = [
  { title: 'ID', key: 'id' },
  { title: '请求地址', key: 'requestUrl' },
  { title: '浏览器/平台', key: 'browserPlatform' },
  { title: '浏览器信息', key: 'browserInfo' },
  { title: '类型', key: 'type' },
  { title: '详情', key: 'detail' },
  { title: 'IP', key: 'ip' },
  { title: '国家', key: 'country' },
  { title: '创建时间', key: 'createTime' },
  { title: '操作', key: 'actions', sortable: false },
]

const typeOptions = [
  { title: '全部', value: '全部' },
  { title: '成功', value: '成功' },
  { title: '拦截', value: '拦截' },
]

const getTypeColor = (type: string) => {
  return type === '成功' ? 'success' : 'error'
}

const search = () => {
  // 查询逻辑
}

const reset = () => {
  filterForm.value = {
    type: '全部',
    dateRange: '',
  }
}

const clearAll = () => {
  records.value = []
}

const viewRecord = (record: AccessRecord) => {
  currentRecord.value = record
  isViewDialogOpen.value = true
}
</script>

<template>
  <div>
    <!-- 筛选区域 -->
    <VCard class="filter-card mb-4">
      <VCardText class="filter-content">
        <VRow class="filter-row">
          <VCol
            cols="12"
            md="3"
            class="filter-col"
          >
            <VSelect
              v-model="filterForm.type"
              :items="typeOptions"
              label="类型"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
            />
          </VCol>
          <VCol
            cols="12"
            md="6"
            class="filter-col"
          >
            <VTextField
              v-model="filterForm.dateRange"
              label="日期范围"
              variant="outlined"
              density="compact"
              hide-details
              class="filter-input"
              readonly
            />
          </VCol>
          <VCol
            cols="12"
            md="3"
            class="filter-actions"
          >
            <div class="d-flex gap-3">
              <VBtn
                color="primary"
                variant="elevated"
                size="default"
                class="filter-btn"
                @click="search"
              >
                <VIcon
                  icon="ri-search-line"
                  start
                  size="20"
                />
                查询
              </VBtn>
              <VBtn
                variant="outlined"
                size="default"
                class="filter-btn"
                @click="reset"
              >
                重置
              </VBtn>
            </div>
          </VCol>
        </VRow>
      </VCardText>
    </VCard>

    <!-- 操作栏 -->
    <VCard class="action-bar-card mb-4">
      <VCardText class="action-bar-content">
        <div class="d-flex align-center justify-space-between flex-wrap gap-4">
          <div class="d-flex align-center gap-2 action-left">
            <span class="action-label">每页显示</span>
            <VSelect
              v-model="itemsPerPage"
              :items="[10, 20, 50, 100]"
              variant="outlined"
              density="compact"
              hide-details
              class="items-per-page-select"
            />
          </div>
          <VBtn
            color="error"
            variant="outlined"
            size="default"
            class="action-btn"
            @click="clearAll"
          >
            <VIcon
              icon="ri-delete-bin-line"
              start
              size="20"
            />
            一键清空
          </VBtn>
        </div>
      </VCardText>
    </VCard>

    <!-- 访问记录列表 -->
    <VCard class="records-table-card">
      <VDataTable
        v-model="selectedRecords"
        :headers="headers"
        :items="records"
        :items-per-page="itemsPerPage"
        :page="page"
        show-select
        class="records-table text-no-wrap"
      >
        <template #item.requestUrl="{ item }">
          <div class="request-url-cell">
            <span class="url-text">{{ item.requestUrl }}</span>
          </div>
        </template>
        <template #item.browserInfo="{ item }">
          <span class="browser-info-text text-truncate d-inline-block">
            {{ item.browserInfo }}
          </span>
        </template>
        <template #item.type="{ item }">
          <VChip
            :color="getTypeColor(item.type)"
            size="small"
            class="type-chip"
          >
            {{ item.type }}
          </VChip>
        </template>
        <template #item.detail="{ item }">
          <span class="detail-text text-truncate d-inline-block">
            {{ item.detail }}
          </span>
        </template>
        <template #item.actions="{ item }">
          <IconBtn
            size="small"
            class="action-icon-btn"
            @click="viewRecord(item)"
          >
            <VIcon
              icon="ri-eye-line"
              size="20"
            />
          </IconBtn>
        </template>
        <template #no-data>
          <div class="empty-state">
            <VIcon
              icon="ri-file-list-line"
              size="64"
              color="disabled"
              class="mb-4"
            />
            <p class="empty-text">
              暂无访问记录
            </p>
          </div>
        </template>
        <template #bottom>
          <div class="table-footer">
            <div class="pagination-info">
              {{ paginationMeta({ page, itemsPerPage }, totalItems) }}
            </div>
            <VPagination
              v-model="page"
              :length="Math.ceil(totalItems / itemsPerPage)"
              :total-visible="5"
              density="comfortable"
            />
          </div>
        </template>
      </VDataTable>
    </VCard>

    <!-- 查看详情对话框 -->
    <VDialog
      v-model="isViewDialogOpen"
      max-width="600"
    >
      <VCard v-if="currentRecord">
        <VCardTitle>访问记录详情</VCardTitle>
        <VCardText>
          <VList>
            <VListItem>
              <VListItemTitle>ID</VListItemTitle>
              <VListItemSubtitle>{{ currentRecord.id }}</VListItemSubtitle>
            </VListItem>
            <VListItem>
              <VListItemTitle>请求地址</VListItemTitle>
              <VListItemSubtitle>{{ currentRecord.requestUrl }}</VListItemSubtitle>
            </VListItem>
            <VListItem>
              <VListItemTitle>浏览器/平台</VListItemTitle>
              <VListItemSubtitle>{{ currentRecord.browserPlatform || '-' }}</VListItemSubtitle>
            </VListItem>
            <VListItem>
              <VListItemTitle>浏览器信息</VListItemTitle>
              <VListItemSubtitle>{{ currentRecord.browserInfo || '-' }}</VListItemSubtitle>
            </VListItem>
            <VListItem>
              <VListItemTitle>类型</VListItemTitle>
              <VListItemSubtitle>
                <VChip
                  :color="getTypeColor(currentRecord.type)"
                  size="small"
                >
                  {{ currentRecord.type }}
                </VChip>
              </VListItemSubtitle>
            </VListItem>
            <VListItem>
              <VListItemTitle>详情</VListItemTitle>
              <VListItemSubtitle>{{ currentRecord.detail }}</VListItemSubtitle>
            </VListItem>
            <VListItem>
              <VListItemTitle>IP</VListItemTitle>
              <VListItemSubtitle>{{ currentRecord.ip }}</VListItemSubtitle>
            </VListItem>
            <VListItem>
              <VListItemTitle>国家</VListItemTitle>
              <VListItemSubtitle>{{ currentRecord.country }}</VListItemSubtitle>
            </VListItem>
            <VListItem>
              <VListItemTitle>创建时间</VListItemTitle>
              <VListItemSubtitle>{{ currentRecord.createTime }}</VListItemSubtitle>
            </VListItem>
          </VList>
        </VCardText>
        <VCardActions>
          <VSpacer />
          <VBtn @click="isViewDialogOpen = false">
            关闭
          </VBtn>
        </VCardActions>
      </VCard>
    </VDialog>
  </div>
</template>

<style lang="scss" scoped>
.filter-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .filter-content {
    padding: 1.5rem;

    .filter-row {
      .filter-col {
        margin-block-end: 0.75rem;
      }

      .filter-input {
        :deep(.v-field) {
          font-size: 0.875rem;
        }

        :deep(.v-label) {
          font-size: 0.875rem;
        }
      }

      .filter-actions {
        margin-block-start: 0.5rem;
        padding-block-start: 0.5rem;

        .filter-btn {
          font-size: 0.875rem;
          font-weight: 500;
          padding-inline: 1.25rem;
          padding-block: 0.625rem;
          border-radius: 0.375rem;
          min-width: 100px;
          transition: all 0.2s ease-in-out;

          &:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
          }
        }
      }
    }
  }
}

.action-bar-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .action-bar-content {
    padding: 1rem 1.5rem;

    .action-left {
      .action-label {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        white-space: nowrap;
      }

      .items-per-page-select {
        width: 90px;

        :deep(.v-field) {
          font-size: 0.875rem;
        }
      }
    }

    .action-btn {
      font-size: 0.875rem;
      font-weight: 500;
      padding-inline: 1rem;
      padding-block: 0.625rem;
      border-radius: 0.375rem;
      min-width: auto;
      transition: all 0.2s ease-in-out;

      &:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
      }
    }
  }
}

.records-table-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  overflow: hidden;

  .records-table {
    :deep(.v-data-table__thead) {
      .v-data-table-header__content {
        font-size: 0.875rem;
        font-weight: 600;
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    :deep(.v-data-table__tbody) {
      .v-data-table__tr {
        .v-data-table__td {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          padding-block: 1rem;
          padding-inline: 1rem;
        }
      }
    }

    .request-url-cell {
      .url-text {
        font-size: 0.875rem;
        word-break: break-all;
      }
    }

    .browser-info-text {
      max-width: 300px;
      font-size: 0.875rem;
    }

    .type-chip {
      font-size: 0.8125rem;
      font-weight: 500;
    }

    .detail-text {
      max-width: 200px;
      font-size: 0.875rem;
    }

    .action-icon-btn {
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      transition: color 0.2s ease-in-out;

      &:hover {
        color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      }
    }

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding-block: 4rem;
      text-align: center;

      .empty-text {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        margin: 0;
      }
    }

    .table-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 1rem 1.5rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .pagination-info {
        font-size: 0.875rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      }
    }
  }
}
</style>

