<script setup lang="ts">
import ConversionRateCard from '@/views/dashboard/ConversionRateCard.vue'
import StatsCards from '@/views/dashboard/StatsCards.vue'
import SystemMonitor from '@/views/dashboard/SystemMonitor.vue'
import DomainStatsChart from '@/views/dashboard/DomainStatsChart.vue'

const dateRange = ref('今日')
</script>

<template>
  <VRow class="match-height">
    <!-- 转化率卡片 -->
    <VCol
      cols="12"
      md="8"
    >
      <ConversionRateCard />
    </VCol>

    <!-- 数据显示选择 -->
    <VCol
      cols="12"
      md="4"
    >
      <VCard>
        <VCardText>
          <div class="d-flex align-center justify-space-between">
            <div class="text-body-2">
              数据显示
            </div>
            <VSelect
              v-model="dateRange"
              :items="['今日', '本周', '本月']"
              variant="outlined"
              density="compact"
              style="max-width: 120px;"
            />
          </div>
        </VCardText>
      </VCard>
    </VCol>

    <!-- 数据统计卡片 -->
    <VCol cols="12">
      <StatsCards />
    </VCol>

    <!-- 系统监控 -->
    <VCol cols="12">
      <SystemMonitor />
    </VCol>

    <!-- 域名访问统计 -->
    <VCol cols="12">
      <DomainStatsChart />
    </VCol>
  </VRow>
</template>
