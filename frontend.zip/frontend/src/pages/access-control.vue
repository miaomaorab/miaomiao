<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue'
import PanelSettings from '@/components/PanelSettings.vue'
import wsClient from '@/utils/websocket'
import { getConnections, disconnectConnection, blacklistConnection } from '@/api/access-control'
import { getToken } from '@/utils/auth'
import type { Connection } from '@/api/access-control'

const panelSettingsOpen = ref(false)
const operationMenuMode = ref<'hover' | 'click'>('hover')

const openPanelSettings = () => {
  panelSettingsOpen.value = true
}

const visitors = ref<Connection[]>([])
const hasVisitors = computed(() => visitors.value.length > 0)
const isLoading = ref(false)

// 刷新在线数据
const refreshOnline = async () => {
  isLoading.value = true
  try {
    const response = await getConnections()
    if (response && response.data) {
      visitors.value = response.data.list || []
    }
  } catch (error) {
    console.error('获取连接列表失败:', error)
  } finally {
    isLoading.value = false
  }
}

// 断开连接
const handleDisconnect = async (id: number) => {
  try {
    await disconnectConnection(id)
    await refreshOnline()
  } catch (error) {
    console.error('断开连接失败:', error)
  }
}

// 拉黑IP
const handleBlacklist = async (id: number, reason?: string) => {
  try {
    await blacklistConnection(id, reason)
    await refreshOnline()
  } catch (error) {
    console.error('拉黑失败:', error)
  }
}

// WebSocket消息处理
const handleWebSocketMessage = (message: any) => {
  if (message.type === 'connection_update') {
    // 更新连接列表
    refreshOnline()
  } else if (message.type === 'new_connection') {
    // 新连接
    if (message.data) {
      visitors.value.unshift(message.data)
    }
  } else if (message.type === 'connection_closed') {
    // 连接关闭
    if (message.data?.id) {
      const index = visitors.value.findIndex(v => v.id === message.data.id)
      if (index > -1) {
        visitors.value.splice(index, 1)
      }
    }
  }
}

// 初始化WebSocket连接
onMounted(async () => {
  // 先获取一次数据
  await refreshOnline()
  
  // 连接WebSocket
  const token = getToken()
  if (token) {
    try {
      await wsClient.connect(token)
      
      // 订阅连接更新消息
      wsClient.on('connection_update', handleWebSocketMessage)
      wsClient.on('new_connection', handleWebSocketMessage)
      wsClient.on('connection_closed', handleWebSocketMessage)
    } catch (error) {
      console.error('WebSocket连接失败:', error)
    }
  }
})

// 清理
onUnmounted(() => {
  wsClient.off('connection_update', handleWebSocketMessage)
  wsClient.off('new_connection', handleWebSocketMessage)
  wsClient.off('connection_closed', handleWebSocketMessage)
})
</script>

<template>
  <div class="access-control-page">
    <!-- 访问控制卡片（包含按钮和实时访客监控） -->
    <VCard class="access-control-card">
      <!-- 操作按钮栏（右上角） -->
      <VCardText class="action-bar-content">
        <div class="d-flex align-center justify-end gap-3">
          <VBtn
            color="primary"
            variant="elevated"
            size="default"
            class="action-btn"
            :loading="isLoading"
            :disabled="isLoading"
            @click="refreshOnline"
          >
            <VIcon
              icon="ri-refresh-line"
              start
              size="20"
            />
            刷新在线
          </VBtn>
          <VBtn
            variant="outlined"
            size="default"
            class="action-btn"
            @click="operationMenuMode = operationMenuMode === 'hover' ? 'click' : 'hover'"
          >
            <VIcon
              icon="ri-menu-line"
              start
              size="20"
            />
            操作菜单方式 ({{ operationMenuMode === 'hover' ? '悬停显示' : '点击显示' }})
          </VBtn>
          <VBtn
            variant="outlined"
            size="default"
            class="action-btn"
            @click="openPanelSettings"
          >
            <VIcon
              icon="ri-settings-3-line"
              start
              size="20"
            />
            面板设置
          </VBtn>
        </div>
        <VDivider class="action-divider" />
      </VCardText>

      <!-- 实时访客监控面板 -->
      <VCardText class="card-content">
        <div
          v-if="!hasVisitors"
          class="empty-state"
        >
          <VIcon
            icon="ri-inbox-line"
            size="64"
            color="disabled"
            class="empty-icon mb-4"
          />
          <p class="empty-text">
            暂无前台访客信息，如果没有显示请检查您的面板设置的过滤设置
          </p>
        </div>
        <div
          v-else
          class="visitor-list"
        >
          <!-- 访客列表 -->
          <VList class="visitor-list-content">
            <VListItem
              v-for="visitor in visitors"
              :key="visitor.id"
              class="visitor-item"
            >
              <VListItemTitle class="visitor-title">
                <div class="d-flex align-center justify-space-between">
                  <div>
                    <div class="text-body-1 font-weight-medium">
                      IP: {{ visitor.ip }}
                    </div>
                    <div class="text-caption text-medium-emphasis mt-1">
                      User-Agent: {{ visitor.user_agent }}
                    </div>
                    <div class="text-caption text-medium-emphasis mt-1">
                      连接时间: {{ new Date(visitor.connected_at).toLocaleString('zh-CN') }}
                    </div>
                    <div class="text-caption text-medium-emphasis">
                      最后活动: {{ new Date(visitor.last_activity).toLocaleString('zh-CN') }}
                    </div>
                  </div>
                  <div class="d-flex gap-2">
                    <VBtn
                      size="small"
                      variant="outlined"
                      color="error"
                      @click="handleDisconnect(visitor.id)"
                    >
                      断开
                    </VBtn>
                    <VBtn
                      size="small"
                      variant="outlined"
                      color="warning"
                      @click="handleBlacklist(visitor.id)"
                    >
                      拉黑
                    </VBtn>
                  </div>
                </div>
              </VListItemTitle>
            </VListItem>
          </VList>
        </div>
      </VCardText>
    </VCard>

    <!-- 面板设置侧边栏 -->
    <PanelSettings v-model="panelSettingsOpen" />
  </div>
</template>

<style lang="scss" scoped>
.access-control-page {
  padding-block-end: 0.5rem;
}

.access-control-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  width: 100%;
  min-height: calc(100vh - 200px);
  display: flex;
  flex-direction: column;

  .action-bar-content {
    padding: 1rem 1.5rem 0;
    flex-shrink: 0;

    .action-btn {
      font-size: 0.875rem;
      font-weight: 500;
      letter-spacing: 0.025em;
      min-width: auto;
      padding-inline: 1rem;
      padding-block: 0.625rem;
      border-radius: 0.375rem;
      transition: all 0.2s ease-in-out;

      &:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.12);
      }
    }

    .action-divider {
      margin-block-start: 1rem;
      margin-inline: 0;
    }
  }

  .card-content {
    padding: 0.5rem 1.5rem 1rem;
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;

    .empty-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      flex: 1;
      padding-block: 6rem;
      text-align: center;

      .empty-icon {
        opacity: 0.5;
      }

      .empty-text {
        font-size: 0.875rem;
        line-height: 1.5rem;
        color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        max-width: 500px;
        margin: 0;
      }
    }

    .visitor-list {
      flex: 1;
      overflow-y: auto;
      min-height: 0;

      .visitor-list-content {
        padding: 0;

        .visitor-item {
          padding-block: 0.875rem;
          padding-inline: 1rem;
          border-radius: 0.375rem;
          margin-block-end: 0.5rem;
          background-color: rgba(var(--v-theme-surface), 1);
          border: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));
          transition: all 0.2s ease-in-out;

          &:hover {
            background-color: rgba(var(--v-theme-surface-variant), 0.5);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
          }

          .visitor-title {
            font-size: 0.875rem;
            font-weight: 500;
            color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          }
        }
      }
    }
  }
}
</style>
