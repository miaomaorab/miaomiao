<script setup lang="ts">
import { useTheme } from 'vuetify'
import { hexToRgb } from '@layouts/utils'

const vuetifyTheme = useTheme()

const dateRange = ref('today')
const selectedDomain = ref('全部域名')
const totalVisits = ref(0)
const totalConversionRate = ref(0)

const chartOptions = computed(() => {
  const currentTheme = vuetifyTheme.current.value.colors
  const variableTheme = vuetifyTheme.current.value.variables

  // Helper function to get RGB string from color
  const getRgbString = (color: string | undefined): string => {
    if (!color)
      return '0, 0, 0'
    const colorStr = String(color)

    // If already in rgb format (e.g., "rgb(140, 87, 255)" or "140, 87, 255")
    if (colorStr.includes(','))
      return colorStr.replace(/^rgb\(|\)$/g, '').trim()

    // If hex format, convert it
    const rgb = hexToRgb(colorStr)

    return rgb || '0, 0, 0'
  }

  const onSurfaceColor = currentTheme?.['on-surface'] || currentTheme?.onSurface || '#000000'
  const onSurfaceRgb = getRgbString(onSurfaceColor)
  const borderColorValue = variableTheme?.['border-color'] || currentTheme?.['border-color'] || '#E0E0E0'
  const borderColorRgb = getRgbString(borderColorValue)

  return {
    chart: {
      type: 'line',
      toolbar: { show: false },
      sparkline: { enabled: false },
      fontFamily: 'inherit',
    },
    stroke: {
      width: [2.5, 2.5],
      curve: 'smooth',
    },
    xaxis: {
      categories: ['11/19', '11/20', '11/21', '11/22', '11/23', '11/24', '11/25'],
      labels: {
        style: {
          fontSize: '12px',
          colors: `rgba(${onSurfaceRgb},${variableTheme['medium-emphasis-opacity'] || 0.6})`,
        },
      },
      axisBorder: {
        color: `rgba(${borderColorRgb},${variableTheme['border-opacity'] || 0.12})`,
      },
      axisTicks: {
        color: `rgba(${borderColorRgb},${variableTheme['border-opacity'] || 0.12})`,
      },
    },
    yaxis: {
      labels: {
        style: {
          fontSize: '12px',
          colors: `rgba(${onSurfaceRgb},${variableTheme['medium-emphasis-opacity'] || 0.6})`,
        },
        formatter: (val: number) => val.toString(),
      },
    },
    colors: [currentTheme.primary, currentTheme.success],
    legend: {
      show: true,
      position: 'top',
      horizontalAlign: 'right',
      fontSize: '13px',
      fontFamily: 'inherit',
      labels: {
        colors: `rgba(${onSurfaceRgb},${variableTheme['high-emphasis-opacity'] || 0.87})`,
      },
      markers: {
        width: 8,
        height: 8,
        radius: 4,
      },
    },
    tooltip: {
      shared: true,
      intersect: false,
      theme: vuetifyTheme.current.value.dark ? 'dark' : 'light',
    },
    grid: {
      borderColor: `rgba(${borderColorRgb},${variableTheme['border-opacity'] || 0.12})`,
      strokeDashArray: 4,
    },
  }
})

const chartSeries = ref([
  {
    name: '访问',
    data: [0, 0, 0, 0, 0, 0, 0],
  },
  {
    name: '已支付',
    data: [0, 0, 0, 0, 0, 0, 0],
  },
])

const domainOptions = ['全部域名']
</script>

<template>
  <VCard class="domain-stats-card">
    <VCardItem class="card-header">
      <VCardTitle class="card-title">
        域名访问统计
      </VCardTitle>
      <template #append>
        <VSelect
          v-model="selectedDomain"
          :items="domainOptions"
          variant="outlined"
          density="compact"
          class="domain-select"
          hide-details
        />
      </template>
    </VCardItem>
    <VCardText class="card-content">
      <div class="d-flex align-center justify-space-between mb-4">
        <VSelect
          v-model="dateRange"
          :items="[
            { title: '今日', value: 'today' },
            { title: '本周', value: 'week' },
            { title: '本月', value: 'month' },
          ]"
          variant="outlined"
          density="compact"
          class="date-select"
          hide-details
        />
      </div>
      <div class="chart-container">
        <VueApexCharts
          type="line"
          height="320"
          :options="chartOptions"
          :series="chartSeries"
        />
      </div>
      <div class="d-flex align-center justify-space-between mt-4 stats-summary">
        <div class="stats-detail">
          <div class="stats-date mb-2">
            11/19
          </div>
          <div class="stats-item">
            <span class="stats-label">访问:</span>
            <span class="stats-value">{{ chartSeries[0]?.data[0] || 0 }}</span>
          </div>
          <div class="stats-item">
            <span class="stats-label">已支付:</span>
            <span class="stats-value">{{ chartSeries[1]?.data[0] || 0 }}</span>
          </div>
        </div>
        <div class="stats-total text-center">
          <h3 class="stats-conversion-rate">
            {{ totalConversionRate }}%
          </h3>
          <div class="stats-total-label">
            总访问: {{ totalVisits }}
          </div>
        </div>
      </div>
    </VCardText>
  </VCard>
</template>

<style lang="scss" scoped>
.domain-stats-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);

  .card-header {
    padding: 1.5rem 1.5rem 0.75rem;

    .card-title {
      font-size: 1.125rem;
      font-weight: 500;
    }

    .domain-select {
      max-width: 150px;
    }
  }

  .card-content {
    padding: 1.5rem;

    .date-select {
      max-width: 120px;
    }

    .chart-container {
      margin-block: 1rem;
    }

    .stats-summary {
      padding-block-start: 1rem;
      border-block-start: 1px solid rgba(var(--v-border-color), var(--v-border-opacity));

      .stats-detail {
        .stats-date {
          font-size: 0.875rem;
          font-weight: 500;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
        }

        .stats-item {
          font-size: 0.875rem;
          line-height: 1.5rem;
          color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));

          .stats-label {
            margin-inline-end: 0.5rem;
          }

          .stats-value {
            font-weight: 500;
            color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          }
        }
      }

      .stats-total {
        .stats-conversion-rate {
          font-size: 2rem;
          font-weight: 600;
          line-height: 2.5rem;
          color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
          margin-block-end: 0.5rem;
        }

        .stats-total-label {
          font-size: 0.875rem;
          color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
        }
      }
    }
  }
}
</style>
