<script setup lang="ts">
interface StatItem {
  title: string
  value: number
  icon: string
  color: string
}

const stats = ref<StatItem[]>([
  {
    title: '今日访问',
    value: 0,
    icon: 'ri-eye-line',
    color: 'primary',
  },
  {
    title: '已拦截',
    value: 0,
    icon: 'ri-shield-cross-line',
    color: 'error',
  },
  {
    title: '付款人数',
    value: 0,
    icon: 'ri-user-line',
    color: 'success',
  },
  {
    title: '付款笔数',
    value: 0,
    icon: 'ri-file-list-line',
    color: 'info',
  },
])
</script>

<template>
  <VRow class="stats-cards-row">
    <VCol
      v-for="stat in stats"
      :key="stat.title"
      cols="12"
      sm="6"
      md="3"
    >
      <VCard class="stats-card">
        <VCardText class="stats-card-content">
          <div class="d-flex align-center gap-3">
            <VAvatar
              :color="stat.color"
              size="44"
              variant="tonal"
              rounded
              class="stats-icon"
            >
              <VIcon
                :icon="stat.icon"
                size="22"
              />
            </VAvatar>
            <div class="stats-info">
              <div class="stats-title">
                {{ stat.title }}
              </div>
              <h5 class="stats-value">
                {{ stat.value }}
              </h5>
            </div>
          </div>
        </VCardText>
      </VCard>
    </VCol>
  </VRow>
</template>

<style lang="scss" scoped>
.stats-cards-row {
  margin-block-end: 1.5rem;
}

.stats-card {
  border-radius: 0.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: box-shadow 0.2s ease-in-out, transform 0.2s ease-in-out;

  &:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
    transform: translateY(-2px);
  }

  .stats-card-content {
    padding: 1.25rem;
  }

  .stats-icon {
    flex-shrink: 0;
  }

  .stats-info {
    flex: 1;
    min-width: 0;

    .stats-title {
      font-size: 0.875rem;
      line-height: 1.25rem;
      color: rgba(var(--v-theme-on-surface), var(--v-medium-emphasis-opacity));
      margin-block-end: 0.5rem;
    }

    .stats-value {
      font-size: 1.5rem;
      font-weight: 600;
      line-height: 2rem;
      color: rgba(var(--v-theme-on-surface), var(--v-high-emphasis-opacity));
      margin: 0;
    }
  }
}
</style>
