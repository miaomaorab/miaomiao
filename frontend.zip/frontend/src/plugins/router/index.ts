import type { App } from 'vue'
import { createRouter, createWebHashHistory } from 'vue-router'
import { routes } from './routes'
import { isAuthenticated } from '@/utils/auth'

const router = createRouter({
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes,
})

// 路由守卫（在router创建后注册）
// 启用登录验证，需要登录才能访问系统
router.beforeEach((to, from, next) => {
  // 检查是否需要认证
  const requiresAuth = !['/login', '/register'].includes(to.path)
  const isAuth = isAuthenticated()

  if (requiresAuth && !isAuth) {
    // 需要认证但未登录，跳转到登录页
    console.log('未登录，跳转到登录页')
    next({
      path: '/login',
      query: { redirect: to.fullPath },
    })
  } else if (to.path === '/login' && isAuth) {
    // 已登录，访问登录页，跳转到首页
    next('/')
  } else {
    next()
  }
})

export default function (app: App) {
  app.use(router)
}

export { router }
