export const routes = [
  // 重定向旧路径
  {
    path: '/dashboard',
    redirect: '/',
  },

  // Default layout routes (main app pages) - 放在前面，优先匹配
  {
    path: '/',
    component: () => import('@/layouts/default.vue'),
    children: [
      {
        path: '',
        component: () => import('@/pages/dashboard.vue'),
      },
      {
        path: 'access-control',
        component: () => import('@/pages/access-control.vue'),
      },
      {
        path: 'apps/user/all',
        component: () => import('@/pages/data-center.vue'),
      },
      {
        path: 'order',
        component: () => import('@/pages/order-statistics.vue'),
      },
      {
        path: 'apps/roles',
        component: () => import('@/pages/users/accounts.vue'),
      },
      {
        path: 'apps/permissions',
        component: () => import('@/pages/users/roles.vue'),
      },
      {
        path: 'record',
        component: () => import('@/pages/monitor/record.vue'),
      },
      {
        path: 'monitor/system',
        component: () => import('@/pages/monitor/system.vue'),
      },
      {
        path: 'log',
        component: () => import('@/pages/monitor/logs.vue'),
      },
      {
        path: 'apps/user/blacklist',
        component: () => import('@/pages/users/blacklist.vue'),
      },
      {
        path: 'source/connection',
        component: () => import('@/pages/frontend-config.vue'),
      },
      {
        path: 'extensions/active',
        component: () => import('@/pages/activation/manage.vue'),
      },
      {
        path: 'extensions/tour',
        component: () => import('@/pages/activation/version.vue'),
      },
      {
        path: 'setting/backstage',
        component: () => import('@/pages/system-config.vue'),
      },
      {
        path: 'security',
        component: () => import('@/pages/security.vue'),
      },
    ],
  },

  // Blank layout routes (login, register, error pages) - 放在后面
  {
    path: '/',
    component: () => import('@/layouts/blank.vue'),
    children: [
      {
        path: 'login',
        component: () => import('@/pages/login.vue'),
      },
      {
        path: 'register',
        component: () => import('@/pages/register.vue'),
      },
      {
        path: '/:pathMatch(.*)*',
        component: () => import('@/pages/[...error].vue'),
      },
    ],
  },
]
